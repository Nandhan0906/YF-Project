# LoanFlow AI: Intelligent Loan Origination, Affordability & Decision Management System

LoanFlow AI is an enterprise-grade loan origination and automated credit decisioning platform. It covers the complete loan lifecycle: applicant onboarding, employment and income verification, credit facility tracking, loan application submission, deterministic reducing-balance affordability calculation, automated rule-based decisioning, document review, amortized repayment scheduling with penny reconciliation, exception management, and immutable compliance audit logging.

---

## 🌟 Key Features

1. **Modern Banking Dashboard & UX**:
   - Deep navy-blue sidebar navigation with 12 distinct functional modules.
   - 8 dynamic KPI cards (Total Applicants, Total Applications, Approved, Rejected, Manual Review, Loan Volume Requested, Approved Capital, Average DTI).
   - 6 interactive Chart.js visualizations (Status Distribution, Product Breakdown, Monthly Application Trends, Approval vs Rejection, Applicant Income Distribution, Affordability Risk Distribution).
   - Integrated AI Regulatory & Underwriting Search modal with grounded source citations.

2. **12 Relational Data Entities**:
   - `Applicant`, `Employment`, `IncomeRecord`, `CreditFacility`, `LoanProduct`, `LoanApplication`, `Document`, `AffordabilityCheck`, `Decision`, `RepaymentSchedule`, `LoanEvent`, `IssueRecord`.

3. **Deterministic Financial Math Engine**:
   - **Reducing-Balance Monthly Installment (EMI)**:
     $$EMI = P \times r \times \frac{(1+r)^n}{(1+r)^n - 1}$$
   - **Debt-to-Income (DTI)** ratio computation.
   - **Net Disposable Income** calculation with stress-testing limits.
   - **Amortization Schedule** with principal/interest split and final penny reconciliation to $0.00 ending balance.

4. **Explainable Deterministic Decision Engine**:
   - Evaluates applicant income, employment stability, DTI caps, product limits, and document completeness.
   - Outputs `APPROVED`, `REJECTED`, or `MANUAL_REVIEW` with granular Adverse Action rule reason codes.
   - Supports Underwriter Manual Overrides with mandatory compliance rationale notes.

5. **Dual Architecture (Web + Python Backend)**:
   - **Frontend**: React, TypeScript, Tailwind CSS, shadcn/ui, Chart.js, Lucide icons, in-memory/localStorage reactive relational store.
   - **Backend**: Python 3, FastAPI, SQLAlchemy ORM, SQLite (`loanflow.db`), Pydantic validation schemas, and automated unittest/pytest suites.

---

## 🚀 Quick Start Guide

### Frontend Development Server
```bash
# Install dependencies
pnpm install

# Start Vite dev server
pnpm run dev

# Run linter and typecheck
pnpm run lint
```

### Python FastAPI Backend & SQLite
```bash
# 1. Navigate to backend directory
cd backend

# 2. Set up virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt

# 3. Seed synthetic data (configurable random seed)
python3 -m services.synthetic_generator --seed 42 --applicants 1000 --applications 600

# 4. Start FastAPI server
uvicorn main:app --reload --port 8000

# 5. Run automated test suite
python3 tests/test_suite_unittest.py
```

---

## 📚 Project Structure

```
.
├── backend/                        # Python FastAPI backend
│   ├── database.py                 # SQLite engine & session factory
│   ├── models.py                   # SQLAlchemy 12 entity models
│   ├── schemas.py                  # Pydantic request/response models
│   ├── main.py                     # FastAPI REST API endpoints
│   ├── requirements.txt            # Python dependencies
│   ├── services/
│   │   ├── affordability.py        # Deterministic EMI & DTI formulas
│   │   ├── decision_engine.py      # Rule-based decisioning & reason codes
│   │   ├── repayment.py            # Reducing-balance amortization generator
│   │   └── synthetic_generator.py  # Seedable dataset generator
│   └── tests/
│       ├── test_loanflow.py        # Pytest test suite
│       └── test_suite_unittest.py  # Standard library unittest suite
├── docs/                           # Technical documentation
│   ├── architecture.md             # System architecture & component design
│   ├── data_dictionary.md          # Database schema & entity attributes
│   ├── assumptions.md              # Underwriting & regulatory assumptions
│   ├── DESIGN.md                   # Visual design system specifications
│   └── prompt-history.md           # Engineering prompt log
└── src/                            # React + TypeScript frontend
    ├── components/
    │   ├── applicants/             # Applicant profile & registration modals
    │   ├── applications/           # Application detail & wizard modals
    │   ├── common/                 # AI Search & observer components
    │   └── layout/                 # Collapsible navy sidebar & top nav
    ├── pages/                      # 12 functional application pages
    ├── services/
    │   └── dbStore.ts              # Reactive client store & calculation engine
    └── types/
        └── loanflow.ts             # Domain TypeScript interfaces
```

---

## 🔒 Security & Compliance

- **No Real PII**: Synthetic data generator creates synthetic names, tax IDs, and employers.
- **Explainability**: Every decision snapshot is stored with the rule engine version, inputs, and reason codes.
- **Audit Trails**: All status transitions, overrides, and verifications are recorded in an append-only event log.
