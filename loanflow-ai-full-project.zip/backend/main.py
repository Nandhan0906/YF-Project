"""
LoanFlow AI - FastAPI Backend Application
Production RESTful API for Loan Origination, Affordability & Decision Management System.
"""

import os
import json
import uuid
import datetime
from typing import Optional, List, Dict, Any
from fastapi import FastAPI, Depends, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import func, desc

from .database import engine, get_db, Base
from .models import (
    Applicant, Employment, IncomeRecord, CreditFacility, LoanProduct,
    LoanApplication, Document, AffordabilityCheck, Decision, RepaymentSchedule,
    LoanEvent, IssueRecord
)
from .schemas import (
    ApplicantCreate, ApplicantUpdate, ApplicantResponse,
    LoanProductCreate, LoanProductUpdate, LoanProductResponse,
    LoanApplicationCreate, LoanApplicationResponse,
    AffordabilityCalculationRequest, AffordabilityCalculationResponse,
    DecisionResponse, DecisionOverrideRequest,
    RepaymentScheduleSummary, DocumentCreate, DocumentStatusUpdate, DocumentResponse,
    IssueRecordResponse, IssueResolveRequest, LoanEventResponse
)
from .services.affordability import calculate_affordability
from .services.decision_engine import evaluate_loan_decision
from .services.repayment import generate_repayment_schedule
from .services.synthetic_generator import seed_database

# Create DB tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="LoanFlow AI - Intelligent Loan Decision Platform",
    description="End-to-End Loan Origination, Affordability, and Deterministic Decisioning API",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health", tags=["System"])
def health_check():
    return {
        "status": "healthy",
        "service": "LoanFlow AI Core API",
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "version": "1.0.0"
    }

# ==================== DASHBOARD SUMMARY ====================
@app.get("/api/dashboard/summary", tags=["Dashboard"])
def get_dashboard_summary(db: Session = Depends(get_db)):
    total_applicants = db.query(Applicant).count()
    total_applications = db.query(LoanApplication).count()

    approved_count = db.query(LoanApplication).filter(LoanApplication.status.in_(["APPROVED", "DISBURSED"])).count()
    rejected_count = db.query(LoanApplication).filter(LoanApplication.status == "REJECTED").count()
    manual_review_count = db.query(LoanApplication).filter(LoanApplication.status == "MANUAL_REVIEW").count()

    requested_sum = db.query(func.sum(LoanApplication.requested_principal)).scalar() or 0.0
    approved_sum = db.query(func.sum(LoanApplication.requested_principal))\
        .filter(LoanApplication.status.in_(["APPROVED", "DISBURSED"])).scalar() or 0.0

    avg_dti = db.query(func.avg(AffordabilityCheck.dti_ratio)).scalar() or 34.5

    # Status distribution
    status_counts = db.query(LoanApplication.status, func.count(LoanApplication.id))\
        .group_by(LoanApplication.status).all()
    status_distribution = {s: count for s, count in status_counts}

    # Product distribution
    product_counts = db.query(LoanProduct.name, func.count(LoanApplication.id))\
        .join(LoanApplication, LoanProduct.id == LoanApplication.product_id)\
        .group_by(LoanProduct.name).all()
    product_distribution = {name: count for name, count in product_counts}

    # Risk band distribution
    risk_counts = db.query(Applicant.risk_band, func.count(Applicant.id))\
        .group_by(Applicant.risk_band).all()
    risk_distribution = {band: count for band, count in risk_counts}

    # Recent applications
    recent_apps = db.query(LoanApplication).order_by(desc(LoanApplication.created_at)).limit(10).all()
    recent_applications_data = []
    for app in recent_apps:
        recent_applications_data.append({
            "id": app.id,
            "application_number": app.application_number,
            "applicant_name": f"{app.applicant.first_name} {app.applicant.last_name}" if app.applicant else "Unknown",
            "product_name": app.product.name if app.product else "Unknown",
            "principal": app.requested_principal,
            "status": app.status,
            "created_at": app.created_at.isoformat() if app.created_at else None
        })

    # Recent decisions
    recent_decs = db.query(Decision).order_by(desc(Decision.created_at)).limit(8).all()
    recent_decisions_data = []
    for d in recent_decs:
        recent_decisions_data.append({
            "id": d.id,
            "application_id": d.application_id,
            "outcome": d.outcome,
            "explanation": d.explanation[:120] + "..." if len(d.explanation) > 120 else d.explanation,
            "decided_by": d.decided_by,
            "created_at": d.created_at.isoformat() if d.created_at else None
        })

    # Pending verification count
    pending_docs = db.query(Document).filter(Document.status == "PENDING").count()
    open_exceptions = db.query(IssueRecord).filter(IssueRecord.resolution_status == "OPEN").count()

    return {
        "total_applicants": total_applicants,
        "total_loan_applications": total_applications,
        "approved_applications": approved_count,
        "rejected_applications": rejected_count,
        "manual_review_applications": manual_review_count,
        "total_loan_amount_requested": round(requested_sum, 2),
        "total_approved_loan_amount": round(approved_sum, 2),
        "average_dti_ratio": round(avg_dti, 2),
        "pending_document_verifications": pending_docs,
        "open_exceptions_count": open_exceptions,
        "status_distribution": status_distribution,
        "product_distribution": product_distribution,
        "risk_distribution": risk_distribution,
        "recent_applications": recent_applications_data,
        "recent_decisions": recent_decisions_data
    }

# ==================== APPLICANTS ====================
@app.get("/api/applicants", tags=["Applicants"])
def get_applicants(
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    search: Optional[str] = None,
    risk_band: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Applicant)
    if search:
        query = query.filter(
            (Applicant.first_name.ilike(f"%{search}%")) |
            (Applicant.last_name.ilike(f"%{search}%")) |
            (Applicant.national_id.ilike(f"%{search}%")) |
            (Applicant.email.ilike(f"%{search}%"))
        )
    if risk_band:
        query = query.filter(Applicant.risk_band == risk_band)

    total = query.count()
    applicants = query.order_by(desc(Applicant.created_at)).offset((page - 1) * limit).limit(limit).all()

    return {
        "total": total,
        "page": page,
        "limit": limit,
        "items": [
            {
                "id": a.id,
                "first_name": a.first_name,
                "last_name": a.last_name,
                "national_id": a.national_id,
                "email": a.email,
                "phone": a.phone,
                "city": a.city,
                "credit_score": a.credit_score,
                "risk_band": a.risk_band,
                "created_at": a.created_at.isoformat() if a.created_at else None
            }
            for a in applicants
        ]
    }

@app.get("/api/applicants/{applicant_id}", tags=["Applicants"])
def get_applicant_detail(applicant_id: str, db: Session = Depends(get_db)):
    applicant = db.query(Applicant).filter(Applicant.id == applicant_id).first()
    if not applicant:
        raise HTTPException(status_code=404, detail="Applicant not found")

    return {
        "id": applicant.id,
        "first_name": applicant.first_name,
        "last_name": applicant.last_name,
        "national_id": applicant.national_id,
        "email": applicant.email,
        "phone": applicant.phone,
        "date_of_birth": applicant.date_of_birth,
        "address": applicant.address,
        "city": applicant.city,
        "credit_score": applicant.credit_score,
        "risk_band": applicant.risk_band,
        "created_at": applicant.created_at.isoformat() if applicant.created_at else None,
        "employments": [
            {
                "id": e.id,
                "employer_name": e.employer_name,
                "job_title": e.job_title,
                "employment_type": e.employment_type,
                "tenure_months": e.tenure_months,
                "is_current": e.is_current,
                "verified": e.verified
            } for e in applicant.employments
        ],
        "incomes": [
            {
                "id": i.id,
                "income_source": i.income_source,
                "monthly_amount": i.monthly_amount,
                "frequency": i.frequency,
                "verification_status": i.verification_status
            } for i in applicant.incomes
        ],
        "credit_facilities": [
            {
                "id": c.id,
                "lender_name": c.lender_name,
                "facility_type": c.facility_type,
                "credit_limit": c.credit_limit,
                "outstanding_balance": c.outstanding_balance,
                "monthly_installment": c.monthly_installment,
                "status": c.status
            } for c in applicant.credit_facilities
        ],
        "applications": [
            {
                "id": app.id,
                "application_number": app.application_number,
                "product_name": app.product.name if app.product else "N/A",
                "requested_principal": app.requested_principal,
                "requested_tenure_months": app.requested_tenure_months,
                "status": app.status,
                "created_at": app.created_at.isoformat() if app.created_at else None
            } for app in applicant.applications
        ]
    }

@app.post("/api/applicants", tags=["Applicants"], status_code=status.HTTP_201_CREATED)
def create_applicant(payload: ApplicantCreate, db: Session = Depends(get_db)):
    existing = db.query(Applicant).filter(
        (Applicant.national_id == payload.national_id) | (Applicant.email == payload.email)
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Applicant with this national ID or email already exists.")

    new_id = f"app-{uuid.uuid4().hex[:8]}"
    applicant = Applicant(
        id=new_id,
        first_name=payload.first_name,
        last_name=payload.last_name,
        national_id=payload.national_id,
        email=payload.email,
        phone=payload.phone,
        date_of_birth=payload.date_of_birth,
        address=payload.address,
        city=payload.city,
        credit_score=payload.credit_score,
        risk_band=payload.risk_band
    )
    db.add(applicant)

    # Log audit event
    event = LoanEvent(
        id=f"evt-{uuid.uuid4().hex[:8]}",
        entity_type="APPLICANT",
        entity_id=new_id,
        event_type="CREATED",
        new_state="ACTIVE",
        actor="UNDERWRITER",
        description=f"Applicant {payload.first_name} {payload.last_name} registered."
    )
    db.add(event)
    db.commit()
    db.refresh(applicant)

    return {"message": "Applicant registered successfully", "id": applicant.id}

@app.put("/api/applicants/{applicant_id}", tags=["Applicants"])
def update_applicant(applicant_id: str, payload: ApplicantUpdate, db: Session = Depends(get_db)):
    applicant = db.query(Applicant).filter(Applicant.id == applicant_id).first()
    if not applicant:
        raise HTTPException(status_code=404, detail="Applicant not found")

    update_data = payload.dict(exclude_unset=True)
    for k, v in update_data.items():
        setattr(applicant, k, v)

    event = LoanEvent(
        id=f"evt-{uuid.uuid4().hex[:8]}",
        entity_type="APPLICANT",
        entity_id=applicant.id,
        event_type="UPDATED",
        actor="UNDERWRITER",
        description=f"Applicant {applicant.first_name} {applicant.last_name} updated fields: {', '.join(update_data.keys())}."
    )
    db.add(event)
    db.commit()
    db.refresh(applicant)

    return {"message": "Applicant updated successfully", "id": applicant.id}

# ==================== LOAN PRODUCTS ====================
@app.get("/api/loan-products", tags=["Loan Products"])
def get_loan_products(db: Session = Depends(get_db)):
    products = db.query(LoanProduct).all()
    return products

@app.post("/api/loan-products", tags=["Loan Products"], status_code=status.HTTP_201_CREATED)
def create_loan_product(payload: LoanProductCreate, db: Session = Depends(get_db)):
    existing = db.query(LoanProduct).filter(LoanProduct.code == payload.code).first()
    if existing:
        raise HTTPException(status_code=400, detail="Loan product with this code already exists.")

    new_id = f"prod-{uuid.uuid4().hex[:8]}"
    product = LoanProduct(
        id=new_id,
        code=payload.code,
        name=payload.name,
        description=payload.description,
        min_principal=payload.min_principal,
        max_principal=payload.max_principal,
        min_tenure_months=payload.min_tenure_months,
        max_tenure_months=payload.max_tenure_months,
        annual_interest_rate=payload.annual_interest_rate,
        min_income_requirement=payload.min_income_requirement,
        max_dti_ratio=payload.max_dti_ratio,
        required_employment_status=payload.required_employment_status,
        status=payload.status
    )
    db.add(product)
    db.commit()
    db.refresh(product)
    return product

@app.put("/api/loan-products/{product_id}", tags=["Loan Products"])
def update_loan_product(product_id: str, payload: LoanProductUpdate, db: Session = Depends(get_db)):
    prod = db.query(LoanProduct).filter(LoanProduct.id == product_id).first()
    if not prod:
        raise HTTPException(status_code=404, detail="Loan product not found")

    update_data = payload.dict(exclude_unset=True)
    for k, v in update_data.items():
        setattr(prod, k, v)
    db.commit()
    db.refresh(prod)
    return prod

# ==================== LOAN APPLICATIONS ====================
@app.get("/api/applications", tags=["Applications"])
def get_applications(
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    status: Optional[str] = None,
    product_id: Optional[str] = None,
    search: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(LoanApplication).join(Applicant)
    if status:
        query = query.filter(LoanApplication.status == status)
    if product_id:
        query = query.filter(LoanApplication.product_id == product_id)
    if search:
        query = query.filter(
            (LoanApplication.application_number.ilike(f"%{search}%")) |
            (Applicant.first_name.ilike(f"%{search}%")) |
            (Applicant.last_name.ilike(f"%{search}%"))
        )

    total = query.count()
    apps = query.order_by(desc(LoanApplication.created_at)).offset((page - 1) * limit).limit(limit).all()

    return {
        "total": total,
        "page": page,
        "limit": limit,
        "items": [
            {
                "id": a.id,
                "application_number": a.application_number,
                "applicant_id": a.applicant_id,
                "applicant_name": f"{a.applicant.first_name} {a.applicant.last_name}" if a.applicant else "Unknown",
                "product_name": a.product.name if a.product else "Unknown",
                "requested_principal": a.requested_principal,
                "requested_tenure_months": a.requested_tenure_months,
                "purpose": a.purpose,
                "status": a.status,
                "created_at": a.created_at.isoformat() if a.created_at else None
            } for a in apps
        ]
    }

@app.get("/api/applications/{application_id}", tags=["Applications"])
def get_application_detail(application_id: str, db: Session = Depends(get_db)):
    app_obj = db.query(LoanApplication).filter(LoanApplication.id == application_id).first()
    if not app_obj:
        raise HTTPException(status_code=404, detail="Loan application not found")

    # Latest affordability
    afford = db.query(AffordabilityCheck).filter(AffordabilityCheck.application_id == application_id)\
        .order_by(desc(AffordabilityCheck.created_at)).first()

    # Latest decision
    dec = db.query(Decision).filter(Decision.application_id == application_id)\
        .order_by(desc(Decision.created_at)).first()

    return {
        "id": app_obj.id,
        "application_number": app_obj.application_number,
        "applicant": {
            "id": app_obj.applicant.id,
            "name": f"{app_obj.applicant.first_name} {app_obj.applicant.last_name}",
            "national_id": app_obj.applicant.national_id,
            "email": app_obj.applicant.email,
            "credit_score": app_obj.applicant.credit_score,
            "risk_band": app_obj.applicant.risk_band
        } if app_obj.applicant else None,
        "product": {
            "id": app_obj.product.id,
            "code": app_obj.product.code,
            "name": app_obj.product.name,
            "annual_interest_rate": app_obj.product.annual_interest_rate,
            "min_principal": app_obj.product.min_principal,
            "max_principal": app_obj.product.max_principal,
            "min_tenure_months": app_obj.product.min_tenure_months,
            "max_tenure_months": app_obj.product.max_tenure_months,
            "max_dti_ratio": app_obj.product.max_dti_ratio
        } if app_obj.product else None,
        "requested_principal": app_obj.requested_principal,
        "requested_tenure_months": app_obj.requested_tenure_months,
        "purpose": app_obj.purpose,
        "status": app_obj.status,
        "submitted_at": app_obj.submitted_at.isoformat() if app_obj.submitted_at else None,
        "decided_at": app_obj.decided_at.isoformat() if app_obj.decided_at else None,
        "disbursed_at": app_obj.disbursed_at.isoformat() if app_obj.disbursed_at else None,
        "created_at": app_obj.created_at.isoformat() if app_obj.created_at else None,
        "affordability": {
            "monthly_income": afford.monthly_income,
            "existing_monthly_debt": afford.existing_monthly_debt,
            "proposed_emi": afford.proposed_emi,
            "dti_ratio": afford.dti_ratio,
            "disposable_income": afford.disposable_income,
            "is_affordable": afford.is_affordable,
            "notes": afford.notes
        } if afford else None,
        "decision": {
            "id": dec.id,
            "outcome": dec.outcome,
            "rule_version": dec.rule_version,
            "reason_codes": json.loads(dec.reason_codes) if dec.reason_codes else [],
            "explanation": dec.explanation,
            "decided_by": dec.decided_by,
            "underwriter_override": dec.underwriter_override,
            "override_reason": dec.override_reason,
            "created_at": dec.created_at.isoformat() if dec.created_at else None
        } if dec else None,
        "documents": [
            {
                "id": d.id,
                "document_type": d.document_type,
                "document_name": d.document_name,
                "status": d.status,
                "rejection_reason": d.rejection_reason,
                "verified_by": d.verified_by,
                "created_at": d.created_at.isoformat() if d.created_at else None
            } for d in app_obj.documents
        ]
    }

@app.post("/api/applications", tags=["Applications"], status_code=status.HTTP_201_CREATED)
def create_application(payload: LoanApplicationCreate, db: Session = Depends(get_db)):
    applicant = db.query(Applicant).filter(Applicant.id == payload.applicant_id).first()
    if not applicant:
        raise HTTPException(status_code=404, detail="Applicant not found")

    product = db.query(LoanProduct).filter(LoanProduct.id == payload.product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Loan product not found")

    new_id = f"loan-{uuid.uuid4().hex[:8]}"
    count = db.query(LoanApplication).count() + 1
    app_num = f"LN-2026-{count:06d}"

    app_obj = LoanApplication(
        id=new_id,
        application_number=app_num,
        applicant_id=payload.applicant_id,
        product_id=payload.product_id,
        requested_principal=payload.requested_principal,
        requested_tenure_months=payload.requested_tenure_months,
        purpose=payload.purpose,
        status="DRAFT"
    )
    db.add(app_obj)

    # Automatically attach mandatory document placeholders
    doc_types = ["IDENTITY_PROOF", "INCOME_PROOF", "BANK_STATEMENTS", "EMPLOYMENT_PROOF"]
    for dt in doc_types:
        doc = Document(
            id=f"doc-{uuid.uuid4().hex[:8]}",
            application_id=new_id,
            document_type=dt,
            document_name=f"{dt.replace('_', ' ').title()} - {applicant.last_name}",
            file_path=f"/uploads/{new_id}/{dt.lower()}.pdf",
            status="PENDING"
        )
        db.add(doc)

    event = LoanEvent(
        id=f"evt-{uuid.uuid4().hex[:8]}",
        application_id=new_id,
        entity_type="APPLICATION",
        entity_id=new_id,
        event_type="CREATED",
        new_state="DRAFT",
        actor="ORIGINATION_AGENT",
        description=f"Application {app_num} drafted for {product.name}."
    )
    db.add(event)
    db.commit()
    db.refresh(app_obj)

    return {"message": "Application created in DRAFT status", "id": app_obj.id, "application_number": app_num}

@app.post("/api/applications/{application_id}/submit", tags=["Applications"])
def submit_application(application_id: str, db: Session = Depends(get_db)):
    app_obj = db.query(LoanApplication).filter(LoanApplication.id == application_id).first()
    if not app_obj:
        raise HTTPException(status_code=404, detail="Loan application not found")

    if app_obj.status != "DRAFT":
        raise HTTPException(status_code=400, detail=f"Cannot submit application from status {app_obj.status}. Must be DRAFT.")

    app_obj.status = "SUBMITTED"
    app_obj.submitted_at = datetime.datetime.utcnow()

    event = LoanEvent(
        id=f"evt-{uuid.uuid4().hex[:8]}",
        application_id=app_obj.id,
        entity_type="APPLICATION",
        entity_id=app_obj.id,
        event_type="SUBMITTED",
        previous_state="DRAFT",
        new_state="SUBMITTED",
        actor="ORIGINATION_AGENT",
        description="Application submitted for underwriting review."
    )
    db.add(event)
    db.commit()
    db.refresh(app_obj)

    return {"message": "Application submitted successfully", "status": app_obj.status}

# ==================== AFFORDABILITY ENGINE ====================
@app.post("/api/affordability/calculate", tags=["Affordability"])
def calculate_affordability_endpoint(payload: AffordabilityCalculationRequest):
    res = calculate_affordability(
        monthly_income=payload.monthly_income,
        existing_monthly_debt=payload.existing_monthly_debt,
        principal=payload.principal,
        annual_rate_pct=payload.annual_interest_rate,
        tenure_months=payload.tenure_months
    )
    return res

@app.post("/api/applications/{application_id}/affordability", tags=["Affordability"])
def run_application_affordability(application_id: str, db: Session = Depends(get_db)):
    app_obj = db.query(LoanApplication).filter(LoanApplication.id == application_id).first()
    if not app_obj:
        raise HTTPException(status_code=404, detail="Application not found")

    # Aggregate verified monthly income from applicant
    incomes = db.query(IncomeRecord).filter(IncomeRecord.applicant_id == app_obj.applicant_id).all()
    monthly_income = sum(inc.monthly_amount for inc in incomes) or 0.0

    # Aggregate existing monthly debt from credit facilities
    facilities = db.query(CreditFacility).filter(CreditFacility.applicant_id == app_obj.applicant_id).all()
    existing_debt = sum(fac.monthly_installment for fac in facilities if fac.status == "ACTIVE") or 0.0

    product = app_obj.product
    afford_res = calculate_affordability(
        monthly_income=monthly_income,
        existing_monthly_debt=existing_debt,
        principal=app_obj.requested_principal,
        annual_rate_pct=product.annual_interest_rate,
        tenure_months=app_obj.requested_tenure_months,
        max_dti_pct=product.max_dti_ratio
    )

    aff_obj = AffordabilityCheck(
        id=f"aff-{uuid.uuid4().hex[:8]}",
        application_id=app_obj.id,
        monthly_income=afford_res["monthly_income"],
        existing_monthly_debt=afford_res["existing_monthly_debt"],
        proposed_emi=afford_res["proposed_emi"],
        dti_ratio=afford_res["dti_ratio"],
        disposable_income=afford_res["disposable_income"],
        interest_rate_used=product.annual_interest_rate,
        tenure_months_used=app_obj.requested_tenure_months,
        principal_used=app_obj.requested_principal,
        is_affordable=afford_res["is_affordable"],
        notes=afford_res["formula_explanation"]
    )
    db.add(aff_obj)

    event = LoanEvent(
        id=f"evt-{uuid.uuid4().hex[:8]}",
        application_id=app_obj.id,
        entity_type="AFFORDABILITY",
        entity_id=aff_obj.id,
        event_type="CALCULATED",
        actor="AFFORDABILITY_ENGINE",
        description=f"Calculated DTI: {afford_res['dti_ratio']}%, Proposed EMI: ${afford_res['proposed_emi']}."
    )
    db.add(event)
    db.commit()
    db.refresh(aff_obj)

    return afford_res

# ==================== DECISION ENGINE ====================
@app.post("/api/applications/{application_id}/decision", tags=["Decisions"])
def run_application_decision(application_id: str, db: Session = Depends(get_db)):
    app_obj = db.query(LoanApplication).filter(LoanApplication.id == application_id).first()
    if not app_obj:
        raise HTTPException(status_code=404, detail="Application not found")

    # Get latest affordability check
    afford = db.query(AffordabilityCheck).filter(AffordabilityCheck.application_id == application_id)\
        .order_by(desc(AffordabilityCheck.created_at)).first()
    if not afford:
        # Compute affordability if not already stored
        run_application_affordability(application_id, db)
        afford = db.query(AffordabilityCheck).filter(AffordabilityCheck.application_id == application_id)\
            .order_by(desc(AffordabilityCheck.created_at)).first()

    docs = db.query(Document).filter(Document.application_id == application_id).all()
    issues = db.query(IssueRecord).filter(IssueRecord.application_id == application_id).all()

    applicant_data = {
        "id": app_obj.applicant.id,
        "credit_score": app_obj.applicant.credit_score,
        "employments": [
            {
                "is_current": e.is_current,
                "tenure_months": e.tenure_months,
                "employment_type": e.employment_type
            } for e in app_obj.applicant.employments
        ]
    }
    product_data = {
        "code": app_obj.product.code,
        "min_principal": app_obj.product.min_principal,
        "max_principal": app_obj.product.max_principal,
        "min_tenure_months": app_obj.product.min_tenure_months,
        "max_tenure_months": app_obj.product.max_tenure_months,
        "min_income_requirement": app_obj.product.min_income_requirement,
        "max_dti_ratio": app_obj.product.max_dti_ratio,
        "required_employment_status": app_obj.product.required_employment_status
    }
    app_data = {
        "requested_principal": app_obj.requested_principal,
        "requested_tenure_months": app_obj.requested_tenure_months
    }
    afford_data = {
        "monthly_income": afford.monthly_income,
        "existing_monthly_debt": afford.existing_monthly_debt,
        "proposed_emi": afford.proposed_emi,
        "dti_ratio": afford.dti_ratio,
        "disposable_income": afford.disposable_income
    }
    docs_data = [{"document_type": d.document_type, "status": d.status} for d in docs]
    issues_data = [{"issue_type": i.issue_type} for i in issues]

    dec_result = evaluate_loan_decision(
        applicant_data=applicant_data,
        product_data=product_data,
        application_data=app_data,
        affordability_data=afford_data,
        documents_data=docs_data,
        issues_data=issues_data
    )

    dec_obj = Decision(
        id=f"dec-{uuid.uuid4().hex[:8]}",
        application_id=app_obj.id,
        outcome=dec_result["outcome"],
        rule_version=dec_result["rule_version"],
        reason_codes=json.dumps(dec_result["reason_codes"]),
        explanation=dec_result["explanation"],
        input_snapshot=json.dumps(dec_result["input_snapshot"]),
        decided_by="AUTOMATED_RULE_ENGINE"
    )
    db.add(dec_obj)

    # Update application status
    old_status = app_obj.status
    app_obj.status = dec_result["outcome"]
    app_obj.decided_at = datetime.datetime.utcnow()

    event = LoanEvent(
        id=f"evt-{uuid.uuid4().hex[:8]}",
        application_id=app_obj.id,
        entity_type="DECISION",
        entity_id=dec_obj.id,
        event_type="DECIDED",
        previous_state=old_status,
        new_state=dec_result["outcome"],
        actor="RULE_ENGINE",
        description=f"Automated evaluation produced {dec_result['outcome']}."
    )
    db.add(event)
    db.commit()
    db.refresh(dec_obj)

    return dec_result

@app.post("/api/applications/{application_id}/override-decision", tags=["Decisions"])
def override_application_decision(application_id: str, payload: DecisionOverrideRequest, db: Session = Depends(get_db)):
    app_obj = db.query(LoanApplication).filter(LoanApplication.id == application_id).first()
    if not app_obj:
        raise HTTPException(status_code=404, detail="Application not found")

    dec = db.query(Decision).filter(Decision.application_id == application_id).order_by(desc(Decision.created_at)).first()
    if not dec:
        raise HTTPException(status_code=400, detail="No prior decision exists to override.")

    old_outcome = dec.outcome
    dec.outcome = payload.outcome
    dec.underwriter_override = True
    dec.override_reason = payload.reason
    dec.decided_by = "UNDERWRITER_OVERRIDE"

    app_obj.status = payload.outcome

    event = LoanEvent(
        id=f"evt-{uuid.uuid4().hex[:8]}",
        application_id=app_obj.id,
        entity_type="DECISION",
        entity_id=dec.id,
        event_type="OVERRIDDEN",
        previous_state=old_outcome,
        new_state=payload.outcome,
        actor="SENIOR_UNDERWRITER",
        description=f"Underwriter manual override from {old_outcome} to {payload.outcome}. Reason: {payload.reason}"
    )
    db.add(event)
    db.commit()

    return {"message": "Decision overridden successfully", "new_outcome": payload.outcome}

# ==================== REPAYMENT SCHEDULE ====================
@app.get("/api/repayments/{application_id}", tags=["Repayments"])
def get_repayment_schedule(application_id: str, db: Session = Depends(get_db)):
    app_obj = db.query(LoanApplication).filter(LoanApplication.id == application_id).first()
    if not app_obj:
        raise HTTPException(status_code=404, detail="Application not found")

    if app_obj.status not in ["APPROVED", "DISBURSED"]:
        raise HTTPException(status_code=400, detail="Repayment schedule can only be generated for APPROVED or DISBURSED applications.")

    schedules = db.query(RepaymentSchedule).filter(RepaymentSchedule.application_id == application_id)\
        .order_by(RepaymentSchedule.installment_number).all()

    if not schedules:
        # Generate and save schedule
        sched_res = generate_repayment_schedule(
            application_id=application_id,
            principal=app_obj.requested_principal,
            annual_interest_rate=app_obj.product.annual_interest_rate,
            tenure_months=app_obj.requested_tenure_months
        )
        for inst in sched_res["installments"]:
            obj = RepaymentSchedule(
                id=f"rep-{application_id}-{inst['installment_number']:03d}",
                application_id=application_id,
                installment_number=inst["installment_number"],
                due_date=inst["due_date"],
                principal_component=inst["principal_component"],
                interest_component=inst["interest_component"],
                total_installment=inst["total_installment"],
                outstanding_principal=inst["outstanding_principal"],
                payment_status="PENDING"
            )
            db.add(obj)
        db.commit()
        schedules = db.query(RepaymentSchedule).filter(RepaymentSchedule.application_id == application_id)\
            .order_by(RepaymentSchedule.installment_number).all()

    total_principal = round(sum(s.principal_component for s in schedules), 2)
    total_interest = round(sum(s.interest_component for s in schedules), 2)
    total_repayment = round(total_principal + total_interest, 2)
    diff = abs(total_principal - app_obj.requested_principal)

    return {
        "application_id": application_id,
        "total_principal": total_principal,
        "total_interest": total_interest,
        "total_repayment": total_repayment,
        "reconciliation_status": "RECONCILED" if diff < 0.02 else "RECONCILIATION_FAILED",
        "installments": [
            {
                "id": s.id,
                "installment_number": s.installment_number,
                "due_date": s.due_date,
                "principal_component": s.principal_component,
                "interest_component": s.interest_component,
                "total_installment": s.total_installment,
                "outstanding_principal": s.outstanding_principal,
                "payment_status": s.payment_status
            } for s in schedules
        ]
    }

# ==================== DOCUMENTS ====================
@app.get("/api/documents", tags=["Documents"])
def get_documents(
    application_id: Optional[str] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Document)
    if application_id:
        query = query.filter(Document.application_id == application_id)
    if status:
        query = query.filter(Document.status == status)

    docs = query.order_by(desc(Document.created_at)).limit(100).all()
    return docs

@app.put("/api/documents/{document_id}/status", tags=["Documents"])
def update_document_status(document_id: str, payload: DocumentStatusUpdate, db: Session = Depends(get_db)):
    doc = db.query(Document).filter(Document.id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    old_status = doc.status
    doc.status = payload.status
    doc.rejection_reason = payload.rejection_reason
    doc.verified_by = payload.verified_by
    if payload.status == "VERIFIED":
        doc.verified_at = datetime.datetime.utcnow()

    event = LoanEvent(
        id=f"evt-{uuid.uuid4().hex[:8]}",
        application_id=doc.application_id,
        entity_type="DOCUMENT",
        entity_id=doc.id,
        event_type="VERIFIED" if payload.status == "VERIFIED" else "STATUS_CHANGED",
        previous_state=old_status,
        new_state=payload.status,
        actor=payload.verified_by or "UNDERWRITER",
        description=f"Document {doc.document_name} updated to {payload.status}."
    )
    db.add(event)
    db.commit()
    db.refresh(doc)
    return doc

# ==================== EXCEPTIONS & ISSUES ====================
@app.get("/api/exceptions", tags=["Exceptions"])
def get_exceptions(
    severity: Optional[str] = None,
    resolution_status: Optional[str] = None,
    issue_type: Optional[str] = None,
    page: int = Query(1, ge=1),
    limit: int = Query(25, ge=1, le=100),
    db: Session = Depends(get_db)
):
    query = db.query(IssueRecord)
    if severity:
        query = query.filter(IssueRecord.severity == severity)
    if resolution_status:
        query = query.filter(IssueRecord.resolution_status == resolution_status)
    if issue_type:
        query = query.filter(IssueRecord.issue_type == issue_type)

    total = query.count()
    issues = query.order_by(desc(IssueRecord.created_at)).offset((page - 1) * limit).limit(limit).all()

    return {
        "total": total,
        "page": page,
        "limit": limit,
        "items": issues
    }

@app.put("/api/exceptions/{issue_id}/resolve", tags=["Exceptions"])
def resolve_exception(issue_id: str, payload: IssueResolveRequest, db: Session = Depends(get_db)):
    issue = db.query(IssueRecord).filter(IssueRecord.id == issue_id).first()
    if not issue:
        raise HTTPException(status_code=404, detail="Exception issue record not found")

    issue.resolution_status = payload.resolution_status
    issue.resolution_notes = payload.resolution_notes
    issue.resolved_by = payload.resolved_by
    issue.resolved_at = datetime.datetime.utcnow()

    event = LoanEvent(
        id=f"evt-{uuid.uuid4().hex[:8]}",
        application_id=issue.application_id,
        entity_type="EXCEPTION",
        entity_id=issue.id,
        event_type="RESOLVED",
        previous_state="OPEN",
        new_state=payload.resolution_status,
        actor=payload.resolved_by,
        description=f"Exception {issue.issue_type} resolved as {payload.resolution_status}. Notes: {payload.resolution_notes}"
    )
    db.add(event)
    db.commit()
    db.refresh(issue)

    return {"message": "Exception issue updated successfully", "id": issue.id}

# ==================== AUDIT LOGS ====================
@app.get("/api/audit-logs", tags=["Audit"])
def get_audit_logs(
    entity_type: Optional[str] = None,
    event_type: Optional[str] = None,
    actor: Optional[str] = None,
    page: int = Query(1, ge=1),
    limit: int = Query(30, ge=1, le=100),
    db: Session = Depends(get_db)
):
    query = db.query(LoanEvent)
    if entity_type:
        query = query.filter(LoanEvent.entity_type == entity_type)
    if event_type:
        query = query.filter(LoanEvent.event_type == event_type)
    if actor:
        query = query.filter(LoanEvent.actor == actor)

    total = query.count()
    events = query.order_by(desc(LoanEvent.created_at)).offset((page - 1) * limit).limit(limit).all()

    return {
        "total": total,
        "page": page,
        "limit": limit,
        "items": events
    }

# ==================== REPORTS & EXPORTS ====================
@app.get("/api/reports/applications", tags=["Reports"])
def get_applications_report(
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    product_id: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(LoanApplication)
    if product_id:
        query = query.filter(LoanApplication.product_id == product_id)

    total = query.count()
    status_summary = dict(query.with_entities(LoanApplication.status, func.count(LoanApplication.id)).group_by(LoanApplication.status).all())

    return {
        "report_type": "APPLICATIONS_SUMMARY",
        "generated_at": datetime.datetime.utcnow().isoformat(),
        "total_applications": total,
        "status_breakdown": status_summary
    }

# ==================== SYNTHETIC DATA SEED ====================
@app.post("/api/seed", tags=["System"])
def seed_data(
    seed: int = Query(42),
    applicants: int = Query(10000),
    applications: int = Query(6000),
    db: Session = Depends(get_db)
):
    result = seed_database(db, random_seed=seed, applicant_target=applicants, application_target=applications)
    return result
