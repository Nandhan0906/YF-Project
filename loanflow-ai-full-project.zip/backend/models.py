import datetime
from sqlalchemy import (
    Column, String, Integer, Float, Boolean, DateTime, Text, ForeignKey, Index, Enum
)
from sqlalchemy.orm import relationship
from .database import Base

class Applicant(Base):
    __tablename__ = "applicants"

    id = Column(String(36), primary_key=True, index=True)
    first_name = Column(String(50), nullable=False)
    last_name = Column(String(50), nullable=False)
    national_id = Column(String(20), unique=True, nullable=False, index=True)
    email = Column(String(100), unique=True, nullable=False, index=True)
    phone = Column(String(20), nullable=False)
    date_of_birth = Column(String(10), nullable=False)
    address = Column(String(200), nullable=False)
    city = Column(String(50), nullable=False)
    credit_score = Column(Integer, nullable=False, default=650)
    risk_band = Column(String(10), nullable=False, default="MEDIUM") # LOW, MEDIUM, HIGH, VERY_HIGH
    created_at = Column(DateTime, default=datetime.datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    employments = relationship("Employment", back_populates="applicant", cascade="all, delete-orphan")
    incomes = relationship("IncomeRecord", back_populates="applicant", cascade="all, delete-orphan")
    credit_facilities = relationship("CreditFacility", back_populates="applicant", cascade="all, delete-orphan")
    applications = relationship("LoanApplication", back_populates="applicant", cascade="all, delete-orphan")


class Employment(Base):
    __tablename__ = "employments"

    id = Column(String(36), primary_key=True, index=True)
    applicant_id = Column(String(36), ForeignKey("applicants.id", ondelete="CASCADE"), nullable=False, index=True)
    employer_name = Column(String(100), nullable=False)
    job_title = Column(String(100), nullable=False)
    employment_type = Column(String(50), nullable=False) # PERMANENT, CONTRACT, SELF_EMPLOYED, UNEMPLOYED
    tenure_months = Column(Integer, nullable=False, default=12)
    is_current = Column(Boolean, nullable=False, default=True)
    verified = Column(Boolean, nullable=False, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    applicant = relationship("Applicant", back_populates="employments")


class IncomeRecord(Base):
    __tablename__ = "income_records"

    id = Column(String(36), primary_key=True, index=True)
    applicant_id = Column(String(36), ForeignKey("applicants.id", ondelete="CASCADE"), nullable=False, index=True)
    income_source = Column(String(50), nullable=False) # PRIMARY_SALARY, SECONDARY_JOB, INVESTMENT, BUSINESS, RENTAL
    monthly_amount = Column(Float, nullable=False)
    frequency = Column(String(20), nullable=False, default="MONTHLY")
    verification_status = Column(String(20), nullable=False, default="PENDING") # PENDING, VERIFIED, REJECTED, CONFLICT
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    applicant = relationship("Applicant", back_populates="incomes")


class CreditFacility(Base):
    __tablename__ = "credit_facilities"

    id = Column(String(36), primary_key=True, index=True)
    applicant_id = Column(String(36), ForeignKey("applicants.id", ondelete="CASCADE"), nullable=False, index=True)
    lender_name = Column(String(100), nullable=False)
    facility_type = Column(String(50), nullable=False) # CREDIT_CARD, MORTGAGE, AUTO_LOAN, PERSONAL_LOAN
    credit_limit = Column(Float, nullable=False, default=0.0)
    outstanding_balance = Column(Float, nullable=False, default=0.0)
    monthly_installment = Column(Float, nullable=False, default=0.0)
    status = Column(String(20), nullable=False, default="ACTIVE") # ACTIVE, CLOSED, DEFAULTED
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    applicant = relationship("Applicant", back_populates="credit_facilities")


class LoanProduct(Base):
    __tablename__ = "loan_products"

    id = Column(String(36), primary_key=True, index=True)
    code = Column(String(20), unique=True, nullable=False, index=True)
    name = Column(String(100), nullable=False)
    description = Column(Text, nullable=True)
    min_principal = Column(Float, nullable=False)
    max_principal = Column(Float, nullable=False)
    min_tenure_months = Column(Integer, nullable=False)
    max_tenure_months = Column(Integer, nullable=False)
    annual_interest_rate = Column(Float, nullable=False) # e.g. 8.5 for 8.5%
    min_income_requirement = Column(Float, nullable=False, default=2000.0)
    max_dti_ratio = Column(Float, nullable=False, default=50.0) # 50% max DTI
    required_employment_status = Column(String(50), nullable=False, default="PERMANENT")
    status = Column(String(20), nullable=False, default="ACTIVE") # ACTIVE, INACTIVE
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    applications = relationship("LoanApplication", back_populates="product")


class LoanApplication(Base):
    __tablename__ = "loan_applications"

    id = Column(String(36), primary_key=True, index=True)
    application_number = Column(String(30), unique=True, nullable=False, index=True)
    applicant_id = Column(String(36), ForeignKey("applicants.id", ondelete="RESTRICT"), nullable=False, index=True)
    product_id = Column(String(36), ForeignKey("loan_products.id", ondelete="RESTRICT"), nullable=False, index=True)
    requested_principal = Column(Float, nullable=False)
    requested_tenure_months = Column(Integer, nullable=False)
    purpose = Column(String(100), nullable=True)
    status = Column(String(30), nullable=False, default="DRAFT", index=True)
    # Lifecycle: DRAFT, SUBMITTED, UNDER_REVIEW, APPROVED, REJECTED, MANUAL_REVIEW, DISBURSED, CLOSED
    submitted_at = Column(DateTime, nullable=True)
    decided_at = Column(DateTime, nullable=True)
    disbursed_at = Column(DateTime, nullable=True)
    closed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    applicant = relationship("Applicant", back_populates="applications")
    product = relationship("LoanProduct", back_populates="applications")
    documents = relationship("Document", back_populates="application", cascade="all, delete-orphan")
    affordability_checks = relationship("AffordabilityCheck", back_populates="application", cascade="all, delete-orphan")
    decisions = relationship("Decision", back_populates="application", cascade="all, delete-orphan")
    repayment_schedules = relationship("RepaymentSchedule", back_populates="application", cascade="all, delete-orphan")
    events = relationship("LoanEvent", back_populates="application", cascade="all, delete-orphan")
    issues = relationship("IssueRecord", back_populates="application", cascade="all, delete-orphan")


class Document(Base):
    __tablename__ = "documents"

    id = Column(String(36), primary_key=True, index=True)
    application_id = Column(String(36), ForeignKey("loan_applications.id", ondelete="CASCADE"), nullable=False, index=True)
    document_type = Column(String(50), nullable=False) # IDENTITY_PROOF, ADDRESS_PROOF, INCOME_PROOF, EMPLOYMENT_PROOF, BANK_STATEMENTS
    document_name = Column(String(150), nullable=False)
    file_path = Column(String(250), nullable=True)
    status = Column(String(20), nullable=False, default="PENDING") # PENDING, VERIFIED, REJECTED, MISSING
    rejection_reason = Column(Text, nullable=True)
    verified_by = Column(String(50), nullable=True)
    verified_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    application = relationship("LoanApplication", back_populates="documents")


class AffordabilityCheck(Base):
    __tablename__ = "affordability_checks"

    id = Column(String(36), primary_key=True, index=True)
    application_id = Column(String(36), ForeignKey("loan_applications.id", ondelete="CASCADE"), nullable=False, index=True)
    monthly_income = Column(Float, nullable=False)
    existing_monthly_debt = Column(Float, nullable=False)
    proposed_emi = Column(Float, nullable=False)
    dti_ratio = Column(Float, nullable=False)
    disposable_income = Column(Float, nullable=False)
    interest_rate_used = Column(Float, nullable=False)
    tenure_months_used = Column(Integer, nullable=False)
    principal_used = Column(Float, nullable=False)
    is_affordable = Column(Boolean, nullable=False)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow, index=True)

    application = relationship("LoanApplication", back_populates="affordability_checks")


class Decision(Base):
    __tablename__ = "decisions"

    id = Column(String(36), primary_key=True, index=True)
    application_id = Column(String(36), ForeignKey("loan_applications.id", ondelete="CASCADE"), nullable=False, index=True)
    outcome = Column(String(20), nullable=False) # APPROVED, REJECTED, MANUAL_REVIEW
    rule_version = Column(String(20), nullable=False, default="1.0.0")
    reason_codes = Column(Text, nullable=False) # JSON or comma-separated string
    explanation = Column(Text, nullable=False)
    input_snapshot = Column(Text, nullable=False) # JSON string of inputs
    underwriter_override = Column(Boolean, default=False)
    override_reason = Column(Text, nullable=True)
    decided_by = Column(String(50), default="AUTOMATED_RULE_ENGINE")
    created_at = Column(DateTime, default=datetime.datetime.utcnow, index=True)

    application = relationship("LoanApplication", back_populates="decisions")


class RepaymentSchedule(Base):
    __tablename__ = "repayment_schedules"

    id = Column(String(36), primary_key=True, index=True)
    application_id = Column(String(36), ForeignKey("loan_applications.id", ondelete="CASCADE"), nullable=False, index=True)
    installment_number = Column(Integer, nullable=False)
    due_date = Column(String(10), nullable=False)
    principal_component = Column(Float, nullable=False)
    interest_component = Column(Float, nullable=False)
    total_installment = Column(Float, nullable=False)
    outstanding_principal = Column(Float, nullable=False)
    payment_status = Column(String(20), nullable=False, default="PENDING") # PENDING, PAID, OVERDUE
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    application = relationship("LoanApplication", back_populates="repayment_schedules")

    __table_args__ = (
        Index("idx_app_installment", "application_id", "installment_number", unique=True),
    )


class LoanEvent(Base):
    __tablename__ = "loan_events"

    id = Column(String(36), primary_key=True, index=True)
    application_id = Column(String(36), ForeignKey("loan_applications.id", ondelete="CASCADE"), nullable=True, index=True)
    entity_type = Column(String(50), nullable=False) # APPLICANT, APPLICATION, DECISION, DOCUMENT, REPAYMENT, PRODUCT, EXCEPTION
    entity_id = Column(String(36), nullable=False, index=True)
    event_type = Column(String(50), nullable=False) # CREATED, SUBMITTED, UPDATED, VERIFIED, DECIDED, OVERRIDDEN, SCHEDULED
    previous_state = Column(String(50), nullable=True)
    new_state = Column(String(50), nullable=True)
    actor = Column(String(50), nullable=False, default="SYSTEM")
    description = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow, index=True)

    application = relationship("LoanApplication", back_populates="events")


class IssueRecord(Base):
    __tablename__ = "issue_records"

    id = Column(String(36), primary_key=True, index=True)
    applicant_id = Column(String(36), ForeignKey("applicants.id", ondelete="CASCADE"), nullable=True, index=True)
    application_id = Column(String(36), ForeignKey("loan_applications.id", ondelete="CASCADE"), nullable=True, index=True)
    issue_type = Column(String(50), nullable=False, index=True)
    # MISSING_INCOME_PROOF, DUPLICATE_APPLICATION, HIGH_DEBT_BURDEN, UNSTABLE_EMPLOYMENT,
    # INCOME_CONFLICT, INVALID_LOAN_TERM, RECONCILIATION_FAILURE, RULE_VIOLATION
    severity = Column(String(20), nullable=False, default="MEDIUM") # LOW, MEDIUM, HIGH, CRITICAL
    description = Column(Text, nullable=False)
    ground_truth_label = Column(String(50), nullable=True)
    resolution_status = Column(String(20), nullable=False, default="OPEN") # OPEN, IN_PROGRESS, RESOLVED, WAIVED
    resolution_notes = Column(Text, nullable=True)
    resolved_by = Column(String(50), nullable=True)
    resolved_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow, index=True)

    application = relationship("LoanApplication", back_populates="issues")
