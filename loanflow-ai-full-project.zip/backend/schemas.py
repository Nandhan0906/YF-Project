from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field, EmailStr

# Applicant Schemas
class ApplicantBase(BaseModel):
    first_name: str
    last_name: str
    national_id: str
    email: EmailStr
    phone: str
    date_of_birth: str
    address: str
    city: str
    credit_score: int = Field(default=650, ge=300, le=850)
    risk_band: str = "MEDIUM"

class ApplicantCreate(ApplicantBase):
    pass

class ApplicantUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    credit_score: Optional[int] = None
    risk_band: Optional[str] = None

class EmploymentSchema(BaseModel):
    id: str
    employer_name: str
    job_title: str
    employment_type: str
    tenure_months: int
    is_current: bool
    verified: bool

class IncomeRecordSchema(BaseModel):
    id: str
    income_source: str
    monthly_amount: float
    frequency: str
    verification_status: str

class CreditFacilitySchema(BaseModel):
    id: str
    lender_name: str
    facility_type: str
    credit_limit: float
    outstanding_balance: float
    monthly_installment: float
    status: str

class ApplicantResponse(ApplicantBase):
    id: str
    created_at: datetime
    updated_at: datetime
    employments: Optional[List[EmploymentSchema]] = []
    incomes: Optional[List[IncomeRecordSchema]] = []
    credit_facilities: Optional[List[CreditFacilitySchema]] = []

    class Config:
        from_attributes = True

# Loan Product Schemas
class LoanProductBase(BaseModel):
    code: str
    name: str
    description: Optional[str] = None
    min_principal: float
    max_principal: float
    min_tenure_months: int
    max_tenure_months: int
    annual_interest_rate: float
    min_income_requirement: float
    max_dti_ratio: float
    required_employment_status: str
    status: str = "ACTIVE"

class LoanProductCreate(LoanProductBase):
    pass

class LoanProductUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    min_principal: Optional[float] = None
    max_principal: Optional[float] = None
    min_tenure_months: Optional[int] = None
    max_tenure_months: Optional[int] = None
    annual_interest_rate: Optional[float] = None
    min_income_requirement: Optional[float] = None
    max_dti_ratio: Optional[float] = None
    required_employment_status: Optional[str] = None
    status: Optional[str] = None

class LoanProductResponse(LoanProductBase):
    id: str
    created_at: datetime

    class Config:
        from_attributes = True

# Loan Application Schemas
class LoanApplicationCreate(BaseModel):
    applicant_id: str
    product_id: str
    requested_principal: float
    requested_tenure_months: int
    purpose: Optional[str] = "General Purpose"

class LoanApplicationResponse(BaseModel):
    id: str
    application_number: str
    applicant_id: str
    product_id: str
    requested_principal: float
    requested_tenure_months: int
    purpose: Optional[str] = None
    status: str
    submitted_at: Optional[datetime] = None
    decided_at: Optional[datetime] = None
    disbursed_at: Optional[datetime] = None
    closed_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

# Affordability Schemas
class AffordabilityCalculationRequest(BaseModel):
    principal: float
    annual_interest_rate: float
    tenure_months: int
    monthly_income: float
    existing_monthly_debt: float

class AffordabilityCalculationResponse(BaseModel):
    monthly_income: float
    existing_monthly_debt: float
    proposed_emi: float
    total_monthly_debt: float
    dti_ratio: float
    disposable_income: float
    is_affordable: bool
    formula_explanation: str
    max_affordable_principal: float

# Decision Schemas
class DecisionResponse(BaseModel):
    id: str
    application_id: str
    outcome: str
    rule_version: str
    reason_codes: List[str]
    explanation: str
    input_snapshot: Dict[str, Any]
    underwriter_override: bool
    override_reason: Optional[str] = None
    decided_by: str
    created_at: datetime

class DecisionOverrideRequest(BaseModel):
    outcome: str = Field(pattern="^(APPROVED|REJECTED|MANUAL_REVIEW)$")
    reason: str

# Repayment Schedule Schemas
class RepaymentInstallmentResponse(BaseModel):
    id: str
    application_id: str
    installment_number: int
    due_date: str
    principal_component: float
    interest_component: float
    total_installment: float
    outstanding_principal: float
    payment_status: str

class RepaymentScheduleSummary(BaseModel):
    application_id: str
    total_principal: float
    total_interest: float
    total_repayment: float
    reconciliation_status: str
    installments: List[RepaymentInstallmentResponse]

# Document Schemas
class DocumentCreate(BaseModel):
    application_id: str
    document_type: str
    document_name: str
    file_path: Optional[str] = None

class DocumentStatusUpdate(BaseModel):
    status: str
    rejection_reason: Optional[str] = None
    verified_by: Optional[str] = "Underwriter"

class DocumentResponse(BaseModel):
    id: str
    application_id: str
    document_type: str
    document_name: str
    file_path: Optional[str]
    status: str
    rejection_reason: Optional[str]
    verified_by: Optional[str]
    verified_at: Optional[datetime]
    created_at: datetime

    class Config:
        from_attributes = True

# Issue & Audit Schemas
class IssueRecordResponse(BaseModel):
    id: str
    applicant_id: Optional[str]
    application_id: Optional[str]
    issue_type: str
    severity: str
    description: str
    ground_truth_label: Optional[str]
    resolution_status: str
    resolution_notes: Optional[str]
    resolved_by: Optional[str]
    resolved_at: Optional[datetime]
    created_at: datetime

    class Config:
        from_attributes = True

class IssueResolveRequest(BaseModel):
    resolution_status: str = Field(pattern="^(RESOLVED|WAIVED|IN_PROGRESS)$")
    resolution_notes: str
    resolved_by: str = "Senior Underwriter"

class LoanEventResponse(BaseModel):
    id: str
    application_id: Optional[str]
    entity_type: str
    entity_id: str
    event_type: str
    previous_state: Optional[str]
    new_state: Optional[str]
    actor: str
    description: str
    created_at: datetime

    class Config:
        from_attributes = True
