"""
Deterministic Financial Affordability Engine
Uses reducing-balance Equal Monthly Installment (EMI) formula:
EMI = P * r * (1 + r)^n / ((1 + r)^n - 1)
Where:
P = Principal loan amount
r = Monthly interest rate (annual_rate / 12 / 100)
n = Tenure in months
"""

import math

def calculate_reducing_balance_emi(principal: float, annual_rate_pct: float, tenure_months: int) -> float:
    if principal <= 0 or tenure_months <= 0:
        return 0.0
    if annual_rate_pct <= 0:
        return round(principal / tenure_months, 2)

    monthly_rate = (annual_rate_pct / 100.0) / 12.0
    factor = math.pow(1.0 + monthly_rate, tenure_months)
    emi = principal * monthly_rate * factor / (factor - 1.0)
    return round(emi, 2)


def calculate_affordability(
    monthly_income: float,
    existing_monthly_debt: float,
    principal: float,
    annual_rate_pct: float,
    tenure_months: int,
    max_dti_pct: float = 50.0
) -> dict:
    """
    Computes deterministic affordability metrics.
    Returns:
      - monthly_income
      - existing_monthly_debt
      - proposed_emi
      - total_monthly_debt
      - dti_ratio (percentage)
      - disposable_income
      - is_affordable
      - formula_explanation
      - max_affordable_principal
    """
    safe_income = max(0.0, float(monthly_income))
    safe_existing_debt = max(0.0, float(existing_monthly_debt))
    safe_principal = max(0.0, float(principal))
    safe_tenure = max(1, int(tenure_months))
    safe_rate = max(0.0, float(annual_rate_pct))

    proposed_emi = calculate_reducing_balance_emi(safe_principal, safe_rate, safe_tenure)
    total_monthly_debt = safe_existing_debt + proposed_emi

    if safe_income <= 0:
        dti_ratio = 999.99
        disposable_income = -total_monthly_debt
        is_affordable = False
    else:
        dti_ratio = round((total_monthly_debt / safe_income) * 100.0, 2)
        disposable_income = round(safe_income - total_monthly_debt, 2)
        is_affordable = (dti_ratio <= max_dti_pct) and (disposable_income > 0)

    # Max affordable principal estimation based on max allowable EMI
    max_allowable_debt = safe_income * (max_dti_pct / 100.0)
    max_allowable_emi = max(0.0, max_allowable_debt - safe_existing_debt)
    if safe_rate > 0 and max_allowable_emi > 0:
        monthly_rate = (safe_rate / 100.0) / 12.0
        factor = math.pow(1.0 + monthly_rate, safe_tenure)
        max_principal = max_allowable_emi * (factor - 1.0) / (monthly_rate * factor)
        max_affordable_principal = round(max(0.0, max_principal), 2)
    elif max_allowable_emi > 0:
        max_affordable_principal = round(max_allowable_emi * safe_tenure, 2)
    else:
        max_affordable_principal = 0.0

    formula_explanation = (
        f"EMI calculated via reducing-balance: P={safe_principal}, APR={safe_rate}%, "
        f"Tenure={safe_tenure}m => Proposed EMI={proposed_emi}. "
        f"DTI = (Existing Debt {safe_existing_debt} + Proposed EMI {proposed_emi}) / "
        f"Income {safe_income} = {dti_ratio}%. Threshold={max_dti_pct}%."
    )

    return {
        "monthly_income": safe_income,
        "existing_monthly_debt": safe_existing_debt,
        "proposed_emi": proposed_emi,
        "total_monthly_debt": round(total_monthly_debt, 2),
        "dti_ratio": dti_ratio,
        "disposable_income": disposable_income,
        "is_affordable": is_affordable,
        "formula_explanation": formula_explanation,
        "max_affordable_principal": max_affordable_principal,
    }
