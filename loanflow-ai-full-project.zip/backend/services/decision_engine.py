"""
Deterministic Explainable Loan Decision Engine
Evaluates applicant eligibility, employment stability, verified income, existing debt,
DTI, disposable income, product boundary rules, and document completeness.
Outputs:
- APPROVED
- REJECTED
- MANUAL_REVIEW
With transparent reason codes, rule evaluations, input snapshots, and rule version.
"""

from typing import Dict, Any, List

RULE_ENGINE_VERSION = "2.1.0-FINTECH"

def evaluate_loan_decision(
    applicant_data: Dict[str, Any],
    product_data: Dict[str, Any],
    application_data: Dict[str, Any],
    affordability_data: Dict[str, Any],
    documents_data: List[Dict[str, Any]],
    issues_data: List[Dict[str, Any]]
) -> Dict[str, Any]:
    reason_codes: List[str] = []
    explanations: List[str] = []
    rule_evaluations: List[Dict[str, Any]] = []

    # 1. Product Boundary Checks
    requested_principal = application_data.get("requested_principal", 0.0)
    min_principal = product_data.get("min_principal", 0.0)
    max_principal = product_data.get("max_principal", 1000000.0)

    if requested_principal < min_principal:
        reason_codes.append("RULE_PRINCIPAL_BELOW_MIN")
        explanations.append(f"Requested loan amount (${requested_principal:,.2f}) is below product minimum (${min_principal:,.2f}).")
        rule_evaluations.append({"rule": "MIN_PRINCIPAL", "passed": False, "details": f"${requested_principal} < ${min_principal}"})
    elif requested_principal > max_principal:
        reason_codes.append("RULE_PRINCIPAL_EXCEEDS_MAX")
        explanations.append(f"Requested loan amount (${requested_principal:,.2f}) exceeds product maximum (${max_principal:,.2f}).")
        rule_evaluations.append({"rule": "MAX_PRINCIPAL", "passed": False, "details": f"${requested_principal} > ${max_principal}"})
    else:
        rule_evaluations.append({"rule": "PRINCIPAL_BOUNDS", "passed": True, "details": f"${min_principal} <= ${requested_principal} <= ${max_principal}"})

    requested_tenure = application_data.get("requested_tenure_months", 0)
    min_tenure = product_data.get("min_tenure_months", 1)
    max_tenure = product_data.get("max_tenure_months", 360)

    if requested_tenure < min_tenure or requested_tenure > max_tenure:
        reason_codes.append("RULE_TENURE_OUT_OF_BOUNDS")
        explanations.append(f"Requested tenure ({requested_tenure} months) is outside product range ({min_tenure}-{max_tenure} months).")
        rule_evaluations.append({"rule": "TENURE_BOUNDS", "passed": False, "details": f"{requested_tenure} not in [{min_tenure}, {max_tenure}]"})
    else:
        rule_evaluations.append({"rule": "TENURE_BOUNDS", "passed": True, "details": f"{min_tenure} <= {requested_tenure} <= {max_tenure}"})

    # 2. Income Requirement Check
    monthly_income = affordability_data.get("monthly_income", 0.0)
    min_income_req = product_data.get("min_income_requirement", 2000.0)

    if monthly_income < min_income_req:
        reason_codes.append("RULE_INSUFFICIENT_INCOME")
        explanations.append(f"Monthly income (${monthly_income:,.2f}) does not meet product minimum requirement (${min_income_req:,.2f}).")
        rule_evaluations.append({"rule": "MIN_INCOME", "passed": False, "details": f"${monthly_income} < ${min_income_req}"})
    else:
        rule_evaluations.append({"rule": "MIN_INCOME", "passed": True, "details": f"${monthly_income} >= ${min_income_req}"})

    # 3. Debt-to-Income (DTI) & Disposable Income Checks
    dti_ratio = affordability_data.get("dti_ratio", 0.0)
    max_dti_ratio = product_data.get("max_dti_ratio", 50.0)
    disposable_income = affordability_data.get("disposable_income", 0.0)

    if dti_ratio > max_dti_ratio:
        reason_codes.append("RULE_DTI_EXCEEDED")
        explanations.append(f"Debt-to-Income ratio ({dti_ratio:.1f}%) exceeds allowed maximum ({max_dti_ratio:.1f}%).")
        rule_evaluations.append({"rule": "MAX_DTI", "passed": False, "details": f"{dti_ratio}% > {max_dti_ratio}%"})
    elif dti_ratio >= (max_dti_ratio - 5.0): # Borderline buffer
        reason_codes.append("RULE_BORDERLINE_DTI")
        explanations.append(f"Debt-to-Income ratio ({dti_ratio:.1f}%) is borderline within 5% of maximum ({max_dti_ratio:.1f}%).")
        rule_evaluations.append({"rule": "BORDERLINE_DTI", "passed": False, "details": f"{dti_ratio}% in [{max_dti_ratio-5}, {max_dti_ratio}]"})
    else:
        rule_evaluations.append({"rule": "DTI_RATIO", "passed": True, "details": f"{dti_ratio}% <= {max_dti_ratio}%"})

    if disposable_income <= 0:
        reason_codes.append("RULE_NEGATIVE_DISPOSABLE_INCOME")
        explanations.append(f"Net disposable income (${disposable_income:,.2f}) is zero or negative after debt commitments.")
        rule_evaluations.append({"rule": "DISPOSABLE_INCOME", "passed": False, "details": f"${disposable_income} <= 0"})
    else:
        rule_evaluations.append({"rule": "DISPOSABLE_INCOME", "passed": True, "details": f"${disposable_income} > 0"})

    # 4. Employment Stability Check
    employments = applicant_data.get("employments", [])
    primary_emp = next((e for e in employments if e.get("is_current")), None)
    emp_tenure = primary_emp.get("tenure_months", 0) if primary_emp else 0
    emp_type = primary_emp.get("employment_type", "UNEMPLOYED") if primary_emp else "UNEMPLOYED"

    required_emp = product_data.get("required_employment_status", "PERMANENT")
    if emp_type == "UNEMPLOYED":
        reason_codes.append("RULE_UNEMPLOYED")
        explanations.append("Applicant has no active employment records.")
        rule_evaluations.append({"rule": "EMPLOYMENT_STATUS", "passed": False, "details": "Unemployed"})
    elif required_emp == "PERMANENT" and emp_type not in ["PERMANENT", "CONTRACT"]:
        reason_codes.append("RULE_EMPLOYMENT_TYPE_MISMATCH")
        explanations.append(f"Employment type '{emp_type}' does not meet required '{required_emp}'.")
        rule_evaluations.append({"rule": "EMPLOYMENT_STATUS", "passed": False, "details": f"{emp_type} != {required_emp}"})
    else:
        rule_evaluations.append({"rule": "EMPLOYMENT_STATUS", "passed": True, "details": f"Type: {emp_type}"})

    if emp_tenure < 6 and emp_type != "UNEMPLOYED":
        reason_codes.append("RULE_UNSTABLE_EMPLOYMENT")
        explanations.append(f"Current employment tenure ({emp_tenure} months) is under minimum stability threshold (6 months).")
        rule_evaluations.append({"rule": "EMPLOYMENT_TENURE", "passed": False, "details": f"{emp_tenure}m < 6m"})
    else:
        rule_evaluations.append({"rule": "EMPLOYMENT_TENURE", "passed": True, "details": f"{emp_tenure}m >= 6m"})

    # 5. Document Completeness Check
    mandatory_doc_types = ["IDENTITY_PROOF", "INCOME_PROOF", "BANK_STATEMENTS"]
    uploaded_doc_types = {d.get("document_type"): d.get("status") for d in documents_data}

    missing_docs = []
    rejected_docs = []
    pending_docs = []

    for m_type in mandatory_doc_types:
        if m_type not in uploaded_doc_types:
            missing_docs.append(m_type)
        elif uploaded_doc_types[m_type] == "REJECTED":
            rejected_docs.append(m_type)
        elif uploaded_doc_types[m_type] == "PENDING":
            pending_docs.append(m_type)

    if missing_docs:
        reason_codes.append("RULE_MISSING_DOCUMENTS")
        explanations.append(f"Mandatory documents missing: {', '.join(missing_docs)}.")
        rule_evaluations.append({"rule": "DOCUMENTS_PRESENT", "passed": False, "details": f"Missing: {missing_docs}"})
    if rejected_docs:
        reason_codes.append("RULE_REJECTED_DOCUMENTS")
        explanations.append(f"Mandatory documents marked as rejected: {', '.join(rejected_docs)}.")
        rule_evaluations.append({"rule": "DOCUMENTS_VERIFIED", "passed": False, "details": f"Rejected: {rejected_docs}"})
    if pending_docs:
        reason_codes.append("RULE_PENDING_DOCUMENTS")
        explanations.append(f"Documents awaiting underwriter verification: {', '.join(pending_docs)}.")
        rule_evaluations.append({"rule": "DOCUMENTS_PENDING", "passed": False, "details": f"Pending: {pending_docs}"})

    # 6. Check Active Issues (from synthetic deliberate exceptions)
    has_income_conflict = any(i.get("issue_type") == "INCOME_CONFLICT" for i in issues_data)
    has_duplicate_app = any(i.get("issue_type") == "DUPLICATE_APPLICATION" for i in issues_data)

    if has_income_conflict:
        reason_codes.append("RULE_INCOME_CONFLICT")
        explanations.append("Applicant stated income conflicts with verified employer/tax document records.")
        rule_evaluations.append({"rule": "INCOME_CONSISTENCY", "passed": False, "details": "Income discrepancy detected"})

    if has_duplicate_app:
        reason_codes.append("RULE_DUPLICATE_APPLICATION")
        explanations.append("Duplicate concurrent loan application detected for this applicant within 30 days.")
        rule_evaluations.append({"rule": "DUPLICATE_CHECK", "passed": False, "details": "Concurrent application exists"})

    # Deterministic Decision Outcome Resolution
    # REJECTED if hard limits breached
    hard_reject_reasons = {
        "RULE_PRINCIPAL_BELOW_MIN",
        "RULE_PRINCIPAL_EXCEEDS_MAX",
        "RULE_TENURE_OUT_OF_BOUNDS",
        "RULE_INSUFFICIENT_INCOME",
        "RULE_DTI_EXCEEDED",
        "RULE_NEGATIVE_DISPOSABLE_INCOME",
        "RULE_UNEMPLOYED",
        "RULE_REJECTED_DOCUMENTS"
    }

    # MANUAL REVIEW if borderline, missing docs, pending docs, unstable tenure, or conflicts
    manual_review_reasons = {
        "RULE_BORDERLINE_DTI",
        "RULE_UNSTABLE_EMPLOYMENT",
        "RULE_MISSING_DOCUMENTS",
        "RULE_PENDING_DOCUMENTS",
        "RULE_INCOME_CONFLICT",
        "RULE_DUPLICATE_APPLICATION"
    }

    matched_rejects = [r for r in reason_codes if r in hard_reject_reasons]
    matched_reviews = [r for r in reason_codes if r in manual_review_reasons]

    if matched_rejects:
        outcome = "REJECTED"
        final_explanation = "Application rejected due to business policy constraints: " + " ".join(explanations)
    elif matched_reviews:
        outcome = "MANUAL_REVIEW"
        final_explanation = "Application routed to Underwriter Manual Review Queue: " + " ".join(explanations)
    else:
        outcome = "APPROVED"
        reason_codes.append("RULE_ALL_CRITERIA_SATISFIED")
        final_explanation = "Applicant satisfies all credit, affordability, employment, and document verification criteria."

    input_snapshot = {
        "applicant_id": applicant_data.get("id"),
        "credit_score": applicant_data.get("credit_score"),
        "monthly_income": monthly_income,
        "existing_monthly_debt": affordability_data.get("existing_monthly_debt"),
        "proposed_emi": affordability_data.get("proposed_emi"),
        "dti_ratio": dti_ratio,
        "disposable_income": disposable_income,
        "product_code": product_data.get("code"),
        "requested_principal": requested_principal,
        "requested_tenure_months": requested_tenure,
    }

    return {
        "outcome": outcome,
        "rule_version": RULE_ENGINE_VERSION,
        "reason_codes": reason_codes,
        "explanation": final_explanation,
        "rule_evaluations": rule_evaluations,
        "input_snapshot": input_snapshot
    }
