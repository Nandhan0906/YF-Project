"""
Repayment Schedule Engine
Generates monthly reducing-balance amortization schedules for approved loans.
Ensures total principal paid reconciles exactly to disbursed principal with penny-adjustments.
"""

from datetime import datetime, timedelta
from typing import List, Dict, Any
from .affordability import calculate_reducing_balance_emi

def generate_repayment_schedule(
    application_id: str,
    principal: float,
    annual_interest_rate: float,
    tenure_months: int,
    start_date: str = None
) -> Dict[str, Any]:
    if principal <= 0 or tenure_months <= 0:
        raise ValueError("Principal and tenure must be strictly positive.")

    emi = calculate_reducing_balance_emi(principal, annual_interest_rate, tenure_months)
    monthly_rate = (annual_interest_rate / 100.0) / 12.0

    current_balance = float(principal)
    installments: List[Dict[str, Any]] = []

    if not start_date:
        base_date = datetime.now() + timedelta(days=30)
    else:
        base_date = datetime.strptime(start_date, "%Y-%m-%d")

    total_principal_paid = 0.0
    total_interest_paid = 0.0

    for i in range(1, tenure_months + 1):
        # Monthly interest on remaining balance
        interest_comp = round(current_balance * monthly_rate, 2)

        # For the final installment, reconcile exact remaining balance
        if i == tenure_months:
            principal_comp = round(current_balance, 2)
            installment_amount = round(principal_comp + interest_comp, 2)
            ending_balance = 0.0
        else:
            principal_comp = round(emi - interest_comp, 2)
            if principal_comp > current_balance:
                principal_comp = round(current_balance, 2)
            ending_balance = round(current_balance - principal_comp, 2)
            installment_amount = round(principal_comp + interest_comp, 2)

        due_date_str = (base_date + timedelta(days=(i - 1) * 30)).strftime("%Y-%m-%d")

        total_principal_paid += principal_comp
        total_interest_paid += interest_comp

        installments.append({
            "installment_number": i,
            "due_date": due_date_str,
            "principal_component": principal_comp,
            "interest_component": interest_comp,
            "total_installment": installment_amount,
            "outstanding_principal": ending_balance,
            "payment_status": "PENDING"
        })

        current_balance = ending_balance

    # Reconciliation Check
    total_principal_paid = round(total_principal_paid, 2)
    total_interest_paid = round(total_interest_paid, 2)
    total_repayment = round(total_principal_paid + total_interest_paid, 2)

    diff = abs(total_principal_paid - principal)
    reconciled = (diff < 0.02) # Within 2 cents tolerance

    return {
        "application_id": application_id,
        "total_principal": total_principal_paid,
        "total_interest": total_interest_paid,
        "total_repayment": total_repayment,
        "reconciliation_status": "RECONCILED" if reconciled else "RECONCILIATION_FAILED",
        "installments": installments
    }
