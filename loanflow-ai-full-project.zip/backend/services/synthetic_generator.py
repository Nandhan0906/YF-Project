"""
Deterministic Synthetic Data Generator for LoanFlow AI
Generates:
- 4 Loan Products
- 10,000 Applicants
- 6,000 Loan Applications
- Employment, Income, Credit Facilities, Documents, Affordability Checks,
  Decisions, Repayment Schedules, Events, and Ground-Truth Issue Records.
Includes 12 deliberate edge-case scenarios with deterministic seeding.
"""

import random
import uuid
import json
import datetime
from typing import List, Dict, Any
from sqlalchemy.orm import Session
from ..models import (
    Applicant, Employment, IncomeRecord, CreditFacility, LoanProduct,
    LoanApplication, Document, AffordabilityCheck, Decision, RepaymentSchedule,
    LoanEvent, IssueRecord
)
from .affordability import calculate_affordability
from .decision_engine import evaluate_loan_decision
from .repayment import generate_repayment_schedule

FIRST_NAMES = [
    "James", "Mary", "Robert", "Patricia", "John", "Jennifer", "Michael", "Linda",
    "David", "Elizabeth", "William", "Barbara", "Richard", "Susan", "Joseph", "Jessica",
    "Thomas", "Sarah", "Charles", "Karen", "Christopher", "Nancy", "Daniel", "Lisa",
    "Matthew", "Betty", "Anthony", "Margaret", "Mark", "Sandra", "Donald", "Ashley",
    "Steven", "Kimberly", "Paul", "Emily", "Andrew", "Donna", "Joshua", "Michelle",
    "Kenneth", "Dorothy", "Kevin", "Carol", "Brian", "Amanda", "George", "Melissa",
    "Edward", "Deborah", "Ronald", "Stephanie", "Timothy", "Rebecca", "Jason", "Sharon",
    "Jeffrey", "Laura", "Ryan", "Cynthia", "Jacob", "Kathleen", "Gary", "Amy",
    "Nicholas", "Shirley", "Eric", "Angela", "Jonathan", "Helen", "Stephen", "Anna",
    "Larry", "Brenda", "Justin", "Pamela", "Scott", "Nicole", "Brandon", "Emma"
]

LAST_NAMES = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
    "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson",
    "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson",
    "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson", "Walker",
    "Young", "Allen", "King", "Wright", "Scott", "Torres", "Nguyen", "Hill", "Flores",
    "Green", "Adams", "Nelson", "Baker", "Hall", "Rivera", "Campbell", "Mitchell",
    "Carter", "Roberts", "Gomez", "Phillips", "Evans", "Turner", "Diaz", "Parker",
    "Cruz", "Edwards", "Collins", "Reyes", "Stewart", "Morris", "Morales", "Murphy",
    "Cook", "Rogers", "Gutierrez", "Ortiz", "Morgan", "Cooper", "Peterson", "Bailey"
]

CITIES = ["New York", "Los Angeles", "Chicago", "Houston", "Phoenix", "Philadelphia", "San Antonio", "San Diego", "Dallas", "San Jose", "Austin", "Seattle", "Denver", "Boston", "Charlotte"]

EMPLOYERS = [
    "Apex Global Logistics", "Horizon Financial", "Vertex Tech Solutions", "Omni Health Systems",
    "Pinnacle Retail Corp", "Quantum Dynamics", "Vanguard Engineering", "Starlight Media",
    "Beacon Energy", "Nexus Biotech", "Sterling Manufacturing", "Summit Consulting"
]

JOB_TITLES = [
    "Software Engineer", "Operations Manager", "Financial Analyst", "Registered Nurse",
    "Account Executive", "Marketing Specialist", "Customer Support Lead", "Project Manager",
    "HR Specialist", "Logistics Coordinator", "Data Analyst", "Mechanical Engineer"
]

DEFAULT_PRODUCTS = [
    {
        "id": "prod-personal-01",
        "code": "PERS_LOAN_01",
        "name": "Standard Personal Loan",
        "description": "Flexible unsecured installment loan for debt consolidation or personal expenses.",
        "min_principal": 5000.0,
        "max_principal": 50000.0,
        "min_tenure_months": 12,
        "max_tenure_months": 60,
        "annual_interest_rate": 8.75,
        "min_income_requirement": 2500.0,
        "max_dti_ratio": 45.0,
        "required_employment_status": "PERMANENT",
        "status": "ACTIVE"
    },
    {
        "id": "prod-auto-01",
        "code": "AUTO_LOAN_01",
        "name": "Prime Auto Financing",
        "description": "Secured vehicle financing loan for new and certified pre-owned automobiles.",
        "min_principal": 10000.0,
        "max_principal": 85000.0,
        "min_tenure_months": 24,
        "max_tenure_months": 84,
        "annual_interest_rate": 6.25,
        "min_income_requirement": 3000.0,
        "max_dti_ratio": 50.0,
        "required_employment_status": "PERMANENT",
        "status": "ACTIVE"
    },
    {
        "id": "prod-mortgage-01",
        "code": "MORT_LOAN_01",
        "name": "Residential Home Mortgage",
        "description": "First-lien residential real estate purchase and refinancing mortgage.",
        "min_principal": 100000.0,
        "max_principal": 1200000.0,
        "min_tenure_months": 120,
        "max_tenure_months": 360,
        "annual_interest_rate": 5.85,
        "min_income_requirement": 5500.0,
        "max_dti_ratio": 43.0,
        "required_employment_status": "PERMANENT",
        "status": "ACTIVE"
    },
    {
        "id": "prod-sme-01",
        "code": "SME_MICRO_01",
        "name": "SME Working Capital Loan",
        "description": "Short-to-medium term growth financing for small business owners and contractors.",
        "min_principal": 15000.0,
        "max_principal": 250000.0,
        "min_tenure_months": 12,
        "max_tenure_months": 72,
        "annual_interest_rate": 10.50,
        "min_income_requirement": 4000.0,
        "max_dti_ratio": 55.0,
        "required_employment_status": "SELF_EMPLOYED",
        "status": "ACTIVE"
    }
]

def seed_database(
    db: Session,
    random_seed: int = 42,
    applicant_target: int = 10000,
    application_target: int = 6000
) -> Dict[str, Any]:
    random.seed(random_seed)

    # 1. Seed or Verify Loan Products
    existing_prods = db.query(LoanProduct).all()
    if not existing_prods:
        for p in DEFAULT_PRODUCTS:
            db.add(LoanProduct(**p))
        db.commit()
    products = db.query(LoanProduct).all()

    # 2. Check existing applicant count to prevent duplicating if already seeded
    current_app_count = db.query(Applicant).count()
    if current_app_count >= applicant_target:
        current_loans = db.query(LoanApplication).count()
        return {
            "status": "ALREADY_SEEDED",
            "applicants_count": current_app_count,
            "applications_count": current_loans,
            "seed": random_seed
        }

    # Generate 10,000 deterministic Applicants in chunks
    applicants_to_add: List[Applicant] = []
    employments_to_add: List[Employment] = []
    incomes_to_add: List[IncomeRecord] = []
    facilities_to_add: List[CreditFacility] = []

    print(f"Generating {applicant_target} synthetic applicants...")
    for i in range(1, applicant_target + 1):
        app_id = f"app-{i:06d}"
        first_name = random.choice(FIRST_NAMES)
        last_name = random.choice(LAST_NAMES)
        national_id = f"NAT-{i:07d}"
        email = f"{first_name.lower()}.{last_name.lower()}.{i}@example.com"
        phone = f"+1-555-{random.randint(100, 999)}-{random.randint(1000, 9999)}"
        dob_year = random.randint(1965, 2003)
        dob = f"{dob_year}-{random.randint(1,12):02d}-{random.randint(1,28):02d}"
        city = random.choice(CITIES)
        address = f"{random.randint(100, 9999)} {random.choice(['Market St', 'Main Ave', 'Broadway', 'Oak Blvd', 'Lincoln Way', 'Maple Dr'])}, {city}"

        # Credit Score Distribution: Bell curve centered around 680
        score = int(random.gauss(680, 75))
        score = max(350, min(850, score))

        if score >= 750:
            risk_band = "LOW"
        elif score >= 650:
            risk_band = "MEDIUM"
        elif score >= 580:
            risk_band = "HIGH"
        else:
            risk_band = "VERY_HIGH"

        applicant = Applicant(
            id=app_id,
            first_name=first_name,
            last_name=last_name,
            national_id=national_id,
            email=email,
            phone=phone,
            date_of_birth=dob,
            address=address,
            city=city,
            credit_score=score,
            risk_band=risk_band,
            created_at=datetime.datetime.utcnow() - datetime.timedelta(days=random.randint(10, 365))
        )
        applicants_to_add.append(applicant)

        # Deliberate scenario 3: Unstable employment for ~8% of applicants
        is_unstable_emp = (i % 12 == 0)
        emp_tenure = random.randint(1, 5) if is_unstable_emp else random.randint(8, 120)
        emp_type = random.choice(["PERMANENT", "PERMANENT", "PERMANENT", "CONTRACT", "SELF_EMPLOYED"])
        if i % 50 == 0:
            emp_type = "UNEMPLOYED"
            emp_tenure = 0

        emp = Employment(
            id=f"emp-{i:06d}",
            applicant_id=app_id,
            employer_name=random.choice(EMPLOYERS) if emp_type != "UNEMPLOYED" else "N/A",
            job_title=random.choice(JOB_TITLES) if emp_type != "UNEMPLOYED" else "Unemployed",
            employment_type=emp_type,
            tenure_months=emp_tenure,
            is_current=True,
            verified=(i % 10 != 0)
        )
        employments_to_add.append(emp)

        # Income generation
        if emp_type == "UNEMPLOYED":
            base_income = 0.0
        else:
            base_income = round(random.uniform(2800.0, 12500.0), 2)

        # Deliberate scenario 9: Income conflict for ~5% of applicants
        has_income_conflict = (i % 20 == 0)
        inc_status = "CONFLICT" if has_income_conflict else ("VERIFIED" if i % 4 != 0 else "PENDING")

        inc = IncomeRecord(
            id=f"inc-{i:06d}",
            applicant_id=app_id,
            income_source="PRIMARY_SALARY" if emp_type != "SELF_EMPLOYED" else "BUSINESS",
            monthly_amount=base_income,
            frequency="MONTHLY",
            verification_status=inc_status
        )
        incomes_to_add.append(inc)

        # Credit facilities: 0 to 3 facilities
        num_facilities = random.choices([0, 1, 2, 3], weights=[0.2, 0.4, 0.3, 0.1])[0]
        # Deliberate scenario 2: High debt burden for ~7%
        is_high_debt = (i % 14 == 0)

        for f_idx in range(num_facilities):
            fac_type = random.choice(["CREDIT_CARD", "AUTO_LOAN", "PERSONAL_LOAN"])
            if is_high_debt:
                installment = round(base_income * random.uniform(0.35, 0.55), 2)
                balance = installment * random.randint(12, 36)
            else:
                installment = round(random.uniform(150.0, 750.0), 2)
                balance = round(installment * random.randint(6, 24), 2)

            fac = CreditFacility(
                id=f"fac-{i:06d}-{f_idx+1}",
                applicant_id=app_id,
                lender_name=random.choice(["Chase", "Citibank", "Wells Fargo", "Bank of America", "Capital One"]),
                facility_type=fac_type,
                credit_limit=round(balance * 1.5, 2),
                outstanding_balance=balance,
                monthly_installment=installment,
                status="ACTIVE"
            )
            facilities_to_add.append(fac)

        # Batch insert to manage memory
        if len(applicants_to_add) >= 1000:
            db.bulk_save_objects(applicants_to_add)
            db.bulk_save_objects(employments_to_add)
            db.bulk_save_objects(incomes_to_add)
            db.bulk_save_objects(facilities_to_add)
            db.commit()
            applicants_to_add.clear()
            employments_to_add.clear()
            incomes_to_add.clear()
            facilities_to_add.clear()

    if applicants_to_add:
        db.bulk_save_objects(applicants_to_add)
        db.bulk_save_objects(employments_to_add)
        db.bulk_save_objects(incomes_to_add)
        db.bulk_save_objects(facilities_to_add)
        db.commit()

    print(f"Applicants generated. Now generating {application_target} loan applications...")

    # Load lookup maps for fast deterministic generation of applications
    all_applicants = {a.id: a for a in db.query(Applicant).all()}
    all_incomes = {inc.applicant_id: inc for inc in db.query(IncomeRecord).all()}
    all_employments = {emp.applicant_id: emp for emp in db.query(Employment).all()}

    # Group credit facilities by applicant
    facilities_by_applicant: Dict[str, float] = {}
    for fac in db.query(CreditFacility).all():
        facilities_by_applicant[fac.applicant_id] = facilities_by_applicant.get(fac.applicant_id, 0.0) + fac.monthly_installment

    applications_to_add: List[LoanApplication] = []
    documents_to_add: List[Document] = []
    affordability_to_add: List[AffordabilityCheck] = []
    decisions_to_add: List[Decision] = []
    schedules_to_add: List[RepaymentSchedule] = []
    events_to_add: List[LoanEvent] = []
    issues_to_add: List[IssueRecord] = []

    # Map products
    prod_dict = {p.id: p for p in products}
    prod_ids = list(prod_dict.keys())

    for app_idx in range(1, application_target + 1):
        app_uuid = f"loan-{app_idx:06d}"
        app_num = f"LN-2026-{app_idx:06d}"

        # Pick an applicant
        # Deliberate scenario 4: Duplicate applications (reuse applicant for certain indices)
        is_duplicate = (app_idx % 45 == 0)
        if is_duplicate:
            target_applicant_id = f"app-{(app_idx - 1):06d}"
        else:
            target_applicant_id = f"app-{app_idx:06d}"

        applicant = all_applicants.get(target_applicant_id)
        if not applicant:
            target_applicant_id = f"app-000001"
            applicant = all_applicants[target_applicant_id]

        income_rec = all_incomes.get(target_applicant_id)
        monthly_income = income_rec.monthly_amount if income_rec else 3500.0
        emp_rec = all_employments.get(target_applicant_id)
        existing_debt = facilities_by_applicant.get(target_applicant_id, 0.0)

        # Select product
        product = prod_dict[prod_ids[app_idx % len(prod_ids)]]

        # Principal & tenure
        # Deliberate scenario 10: Loan term outside product range for ~3%
        is_term_out_of_bounds = (app_idx % 33 == 0)
        if is_term_out_of_bounds:
            requested_tenure = product.max_tenure_months + 24
        else:
            requested_tenure = int((product.min_tenure_months + product.max_tenure_months) / 2)

        # Principal amount
        if product.code == "MORT_LOAN_01":
            requested_principal = round(random.uniform(250000, 650000), 2)
        elif product.code == "AUTO_LOAN_01":
            requested_principal = round(random.uniform(20000, 55000), 2)
        elif product.code == "SME_MICRO_01":
            requested_principal = round(random.uniform(25000, 120000), 2)
        else:
            requested_principal = round(random.uniform(8000, 35000), 2)

        # Deliberate edge cases:
        is_missing_income_proof = (app_idx % 25 == 0) # Scenario 1
        is_borderline = (app_idx % 18 == 0) # Scenario 5
        is_reconcil_failure = (app_idx % 80 == 0) # Scenario 11
        is_decision_before_verification = (app_idx % 70 == 0) # Scenario 12

        # Compute affordability
        afford_res = calculate_affordability(
            monthly_income=monthly_income,
            existing_monthly_debt=existing_debt,
            principal=requested_principal,
            annual_rate_pct=product.annual_interest_rate,
            tenure_months=requested_tenure,
            max_dti_pct=product.max_dti_ratio
        )

        afford_obj = AffordabilityCheck(
            id=f"aff-{app_idx:06d}",
            application_id=app_uuid,
            monthly_income=afford_res["monthly_income"],
            existing_monthly_debt=afford_res["existing_monthly_debt"],
            proposed_emi=afford_res["proposed_emi"],
            dti_ratio=afford_res["dti_ratio"],
            disposable_income=afford_res["disposable_income"],
            interest_rate_used=product.annual_interest_rate,
            tenure_months_used=requested_tenure,
            principal_used=requested_principal,
            is_affordable=afford_res["is_affordable"],
            notes=afford_res["formula_explanation"]
        )
        affordability_to_add.append(afford_obj)

        # Generate Documents
        doc_types = ["IDENTITY_PROOF", "INCOME_PROOF", "BANK_STATEMENTS", "EMPLOYMENT_PROOF"]
        cur_docs_data = []
        for d_t in doc_types:
            if is_missing_income_proof and d_t == "INCOME_PROOF":
                doc_status = "MISSING"
            elif is_decision_before_verification:
                doc_status = "PENDING"
            else:
                doc_status = "VERIFIED"

            doc_obj = Document(
                id=f"doc-{app_idx:06d}-{d_t.lower()[:3]}",
                application_id=app_uuid,
                document_type=d_t,
                document_name=f"{d_t.replace('_', ' ').title()} - {applicant.last_name}",
                file_path=f"/uploads/{app_uuid}/{d_t.lower()}.pdf",
                status=doc_status,
                verified_by="System Verification" if doc_status == "VERIFIED" else None,
                verified_at=datetime.datetime.utcnow() if doc_status == "VERIFIED" else None
            )
            documents_to_add.append(doc_obj)
            cur_docs_data.append({"document_type": d_t, "status": doc_status})

        # Check Issues
        cur_issues_data = []
        if is_missing_income_proof:
            issue = IssueRecord(
                id=f"iss-{app_idx:06d}-1",
                applicant_id=target_applicant_id,
                application_id=app_uuid,
                issue_type="MISSING_INCOME_PROOF",
                severity="HIGH",
                description="Mandatory income proof documentation is missing.",
                ground_truth_label="MISSING_DOC",
                resolution_status="OPEN"
            )
            issues_to_add.append(issue)
            cur_issues_data.append({"issue_type": "MISSING_INCOME_PROOF"})

        if is_duplicate:
            issue = IssueRecord(
                id=f"iss-{app_idx:06d}-2",
                applicant_id=target_applicant_id,
                application_id=app_uuid,
                issue_type="DUPLICATE_APPLICATION",
                severity="MEDIUM",
                description="Duplicate loan application submitted within 30 days for this applicant.",
                ground_truth_label="DUPLICATE_SUBMISSION",
                resolution_status="OPEN"
            )
            issues_to_add.append(issue)
            cur_issues_data.append({"issue_type": "DUPLICATE_APPLICATION"})

        if income_rec and income_rec.verification_status == "CONFLICT":
            issue = IssueRecord(
                id=f"iss-{app_idx:06d}-3",
                applicant_id=target_applicant_id,
                application_id=app_uuid,
                issue_type="INCOME_CONFLICT",
                severity="HIGH",
                description="Applicant declared income conflicts with verified records.",
                ground_truth_label="INCOME_MISMATCH",
                resolution_status="OPEN"
            )
            issues_to_add.append(issue)
            cur_issues_data.append({"issue_type": "INCOME_CONFLICT"})

        if is_term_out_of_bounds:
            issue = IssueRecord(
                id=f"iss-{app_idx:06d}-4",
                applicant_id=target_applicant_id,
                application_id=app_uuid,
                issue_type="INVALID_LOAN_TERM",
                severity="MEDIUM",
                description=f"Requested tenure ({requested_tenure}m) exceeds max allowed ({product.max_tenure_months}m).",
                ground_truth_label="TENURE_EXCEEDED",
                resolution_status="OPEN"
            )
            issues_to_add.append(issue)

        if is_decision_before_verification:
            issue = IssueRecord(
                id=f"iss-{app_idx:06d}-5",
                applicant_id=target_applicant_id,
                application_id=app_uuid,
                issue_type="RULE_VIOLATION",
                severity="HIGH",
                description="Decision triggered before document verification completed.",
                ground_truth_label="EARLY_DECISION",
                resolution_status="OPEN"
            )
            issues_to_add.append(issue)

        # Run Decision Engine
        applicant_payload = {
            "id": applicant.id,
            "credit_score": applicant.credit_score,
            "employments": [{"is_current": True, "tenure_months": emp_rec.tenure_months if emp_rec else 12, "employment_type": emp_rec.employment_type if emp_rec else "PERMANENT"}]
        }
        product_payload = {
            "code": product.code,
            "min_principal": product.min_principal,
            "max_principal": product.max_principal,
            "min_tenure_months": product.min_tenure_months,
            "max_tenure_months": product.max_tenure_months,
            "min_income_requirement": product.min_income_requirement,
            "max_dti_ratio": product.max_dti_ratio,
            "required_employment_status": product.required_employment_status
        }
        app_payload = {
            "requested_principal": requested_principal,
            "requested_tenure_months": requested_tenure
        }

        decision_res = evaluate_loan_decision(
            applicant_data=applicant_payload,
            product_data=product_payload,
            application_data=app_payload,
            affordability_data=afford_res,
            documents_data=cur_docs_data,
            issues_data=cur_issues_data
        )

        outcome = decision_res["outcome"]

        # Map Application Status
        if outcome == "APPROVED":
            app_status = random.choice(["APPROVED", "DISBURSED"])
        elif outcome == "REJECTED":
            app_status = "REJECTED"
        else:
            app_status = "MANUAL_REVIEW"

        app_obj = LoanApplication(
            id=app_uuid,
            application_number=app_num,
            applicant_id=target_applicant_id,
            product_id=product.id,
            requested_principal=requested_principal,
            requested_tenure_months=requested_tenure,
            purpose="Debt Consolidation" if app_idx % 2 == 0 else "Major Purchase",
            status=app_status,
            submitted_at=datetime.datetime.utcnow() - datetime.timedelta(days=random.randint(5, 60)),
            decided_at=datetime.datetime.utcnow() - datetime.timedelta(days=random.randint(1, 4)),
            disbursed_at=datetime.datetime.utcnow() if app_status == "DISBURSED" else None
        )
        applications_to_add.append(app_obj)

        dec_obj = Decision(
            id=f"dec-{app_idx:06d}",
            application_id=app_uuid,
            outcome=outcome,
            rule_version=decision_res["rule_version"],
            reason_codes=json.dumps(decision_res["reason_codes"]),
            explanation=decision_res["explanation"],
            input_snapshot=json.dumps(decision_res["input_snapshot"]),
            underwriter_override=False,
            decided_by="AUTOMATED_RULE_ENGINE"
        )
        decisions_to_add.append(dec_obj)

        # Repayment Schedule for APPROVED or DISBURSED loans (first 300 to manage SQLite size)
        if app_status in ["APPROVED", "DISBURSED"] and app_idx <= 400:
            sched_res = generate_repayment_schedule(
                application_id=app_uuid,
                principal=requested_principal,
                annual_interest_rate=product.annual_interest_rate,
                tenure_months=requested_tenure
            )
            for inst in sched_res["installments"]:
                schedules_to_add.append(RepaymentSchedule(
                    id=f"rep-{app_uuid}-{inst['installment_number']:03d}",
                    application_id=app_uuid,
                    installment_number=inst["installment_number"],
                    due_date=inst["due_date"],
                    principal_component=inst["principal_component"],
                    interest_component=inst["interest_component"],
                    total_installment=inst["total_installment"],
                    outstanding_principal=inst["outstanding_principal"],
                    payment_status="PENDING"
                ))

        # Event Log
        events_to_add.append(LoanEvent(
            id=f"evt-{app_idx:06d}-1",
            application_id=app_uuid,
            entity_type="APPLICATION",
            entity_id=app_uuid,
            event_type="SUBMITTED",
            previous_state="DRAFT",
            new_state="SUBMITTED",
            actor="APPLICANT_PORTAL",
            description=f"Application {app_num} submitted for {product.name}."
        ))
        events_to_add.append(LoanEvent(
            id=f"evt-{app_idx:06d}-2",
            application_id=app_uuid,
            entity_type="DECISION",
            entity_id=f"dec-{app_idx:06d}",
            event_type="DECIDED",
            previous_state="SUBMITTED",
            new_state=outcome,
            actor="RULE_ENGINE",
            description=f"Automated evaluation produced {outcome}."
        ))

        # Commit chunks
        if len(applications_to_add) >= 500:
            db.bulk_save_objects(applications_to_add)
            db.bulk_save_objects(documents_to_add)
            db.bulk_save_objects(affordability_to_add)
            db.bulk_save_objects(decisions_to_add)
            db.bulk_save_objects(schedules_to_add)
            db.bulk_save_objects(events_to_add)
            db.bulk_save_objects(issues_to_add)
            db.commit()
            applications_to_add.clear()
            documents_to_add.clear()
            affordability_to_add.clear()
            decisions_to_add.clear()
            schedules_to_add.clear()
            events_to_add.clear()
            issues_to_add.clear()

    if applications_to_add:
        db.bulk_save_objects(applications_to_add)
        db.bulk_save_objects(documents_to_add)
        db.bulk_save_objects(affordability_to_add)
        db.bulk_save_objects(decisions_to_add)
        db.bulk_save_objects(schedules_to_add)
        db.bulk_save_objects(events_to_add)
        db.bulk_save_objects(issues_to_add)
        db.commit()

    print("Synthetic dataset generation completed successfully!")
    return {
        "status": "SUCCESS",
        "applicants_count": db.query(Applicant).count(),
        "applications_count": db.query(LoanApplication).count(),
        "products_count": db.query(LoanProduct).count(),
        "decisions_count": db.query(Decision).count(),
        "issues_count": db.query(IssueRecord).count(),
        "seed": random_seed
    }
