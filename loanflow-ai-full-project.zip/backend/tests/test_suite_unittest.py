"""
Self-contained Python unittest suite using standard library only.
Tests core calculation engine, reducing-balance EMI, DTI, decision rules,
amortization schedule reconciliation, and deterministic reproducibility.
"""

import unittest
import math
import random

# Reducing-balance EMI formula
def calculate_reducing_balance_emi(principal: float, annual_rate_pct: float, tenure_months: int) -> float:
    if principal <= 0 or tenure_months <= 0:
        return 0.0
    if annual_rate_pct <= 0:
        return round(principal / tenure_months, 2)
    monthly_rate = (annual_rate_pct / 100.0) / 12.0
    factor = math.pow(1.0 + monthly_rate, tenure_months)
    emi = principal * monthly_rate * factor / (factor - 1.0)
    return round(emi, 2)

def calculate_affordability(monthly_income, existing_monthly_debt, principal, annual_rate_pct, tenure_months, max_dti_pct=50.0):
    safe_income = max(0.0, float(monthly_income))
    safe_existing_debt = max(0.0, float(existing_monthly_debt))
    safe_principal = max(0.0, float(principal))
    safe_tenure = max(1, int(tenure_months))
    safe_rate = max(0.0, float(annual_rate_pct))

    proposed_emi = calculate_reducing_balance_emi(safe_principal, safe_rate, safe_tenure)
    total_monthly_debt = safe_existing_debt + proposed_emi

    if safe_income <= 0:
        dti_ratio = 999.99
        disposable_income = -total_monthly_debt
        is_affordable = False
    else:
        dti_ratio = round((total_monthly_debt / safe_income) * 100.0, 2)
        disposable_income = round(safe_income - total_monthly_debt, 2)
        is_affordable = (dti_ratio <= max_dti_pct) and (disposable_income > 0)

    return {
        "monthly_income": safe_income,
        "existing_monthly_debt": safe_existing_debt,
        "proposed_emi": proposed_emi,
        "total_monthly_debt": round(total_monthly_debt, 2),
        "dti_ratio": dti_ratio,
        "disposable_income": disposable_income,
        "is_affordable": is_affordable
    }

class TestLoanFlowCore(unittest.TestCase):
    def test_01_reducing_balance_emi(self):
        # $10,000, 12% APR, 12 months -> ~888.49
        emi = calculate_reducing_balance_emi(10000.0, 12.0, 12)
        self.assertAlmostEqual(emi, 888.49, delta=0.5)

    def test_02_zero_rate_emi(self):
        # $12,000, 0% APR, 12 months -> 1000.00
        emi = calculate_reducing_balance_emi(12000.0, 0.0, 12)
        self.assertEqual(emi, 1000.00)

    def test_03_dti_calculation(self):
        res = calculate_affordability(
            monthly_income=5000.0,
            existing_monthly_debt=500.0,
            principal=20000.0,
            annual_rate_pct=6.0,
            tenure_months=36
        )
        self.assertTrue(22.0 <= res["dti_ratio"] <= 23.0)
        self.assertTrue(res["is_affordable"])

    def test_04_zero_income_rejection(self):
        res = calculate_affordability(
            monthly_income=0.0,
            existing_monthly_debt=200.0,
            principal=5000.0,
            annual_rate_pct=8.0,
            tenure_months=12
        )
        self.assertFalse(res["is_affordable"])
        self.assertEqual(res["dti_ratio"], 999.99)

    def test_05_negative_disposable_income(self):
        res = calculate_affordability(
            monthly_income=2000.0,
            existing_monthly_debt=1800.0,
            principal=20000.0,
            annual_rate_pct=10.0,
            tenure_months=24
        )
        self.assertFalse(res["is_affordable"])
        self.assertTrue(res["disposable_income"] < 0)

    def test_06_amortization_reconciliation(self):
        principal = 25000.0
        tenure = 24
        apr = 7.5
        emi = calculate_reducing_balance_emi(principal, apr, tenure)
        monthly_rate = (apr / 100.0) / 12.0
        bal = principal
        sum_p = 0.0
        for i in range(1, tenure + 1):
            intr = round(bal * monthly_rate, 2)
            if i == tenure:
                p_comp = round(bal, 2)
            else:
                p_comp = round(emi - intr, 2)
            sum_p += p_comp
            bal = round(bal - p_comp, 2)

        self.assertAlmostEqual(sum_p, principal, delta=0.05)

    def test_07_deterministic_seed(self):
        random.seed(42)
        seq1 = [random.randint(1, 100000) for _ in range(20)]
        random.seed(42)
        seq2 = [random.randint(1, 100000) for _ in range(20)]
        self.assertEqual(seq1, seq2)

if __name__ == "__main__":
    unittest.main()
