# Theme Name: Opulent
# Vibe & Description: Centered on precious materials, it builds a contrast of extreme luxury between gold foil and dark velvet, employing strictly symmetrical layouts to create a solemn and dramatic visual order.

# Color
- Select a suitable dark color based on user requirements (such as deep black #050505, deep brown #1a100e, or deep blue #0b1526) as the primary background color. It should evoke the sense of a midnight curtain—deep, restrained, and ceremonial.
- Champagne gold (#D4AF37) is used for lines, borders, and highlighted text, symbolizing wealth, glory, and radiance. It serves as the soul color of the entire visual system.
-Pearl white (#F5F5F5) is sparingly applied to body and informational text, ensuring readability without compromising the overall sense of luxury.

# Font
- Heading: PlayfairDisplay (url: https://resource-static.bj.bcebos.com/fonts/PlayfairDisplay-VariableFont_wght.woff2)
- Body: 系统默认字体
# Animation
## Interaction Emphasis
Modify tailwind.config.js to register the following keyframe animation.
```js
keyframes: {
    'pulse': {
    from {
        transform: scale3d(1, 1, 1);
    }
    50% {
        transform: scale3d(1.05, 1.05, 1.05);
    }
    to {
        transform: scale3d(1, 1, 1);
    }
}
```
Extending animation properties
```js
animation: {
    'pulse-slow': 'pulse 0.2 ease-in-out',
}
```
Use when interacting with elements, such as hover. -- hover:animate-pulse-slow

##Entrance
Modify tailwind.config.js to register the following keyframe animation.
```js
keyframes: {
  'pulse': {
        from {
            transform: scale3d(1, 1, 1);
        }

        50% {
            transform: scale3d(1.05, 1.05, 1.05);
        }

        to {
            transform: scale3d(1, 1, 1);
        }
    }
}
```

Extend the animation property; note that entrance animations begin with ""entrance-"" to distinguish them.
```js
animation: {
    // entrance animation
    'entrance-pulse-show': 'pulse 0.2 ease-in-out',
}
```
## Animation implementation
- The project integrates the tailwindcss-intersect plugin, which allows you to achieve animation effects when elements enter the viewport in a manner similar to the following:
opacity-0 intersect:opacity-100 transition duration-700




# Layout
- The full-screen immersive header image, combined with decorative borders, creates a sense of ceremony, like the opening of a movie.
-Emphasis is placed on the rhythm of vertical divisions and straight lines.

# Elements
- Radial sun patterns, used as background textures or section dividers, convey a sense of power and expansion.
- The use of a double gold border and geometric decorative turns at the corners enhances the decorative and ceremonial feel.