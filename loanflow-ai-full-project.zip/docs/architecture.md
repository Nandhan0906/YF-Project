# Architecture & Technical Design: LoanFlow AI

## 1. System Overview

LoanFlow AI is designed as a modular, decoupled loan origination and credit management system. It provides both an interactive, responsive single-page web application (React, TypeScript, Tailwind CSS, shadcn/ui) and a high-performance Python FastAPI backend backed by an SQLite relational database.

```
+-----------------------------------------------------------------------------------+
|                                 LoanFlow AI UI                                    |
|   +---------------------------------------------------------------------------+   |
|   | Dashboard | Applicants | Applications | Products | Affordability | ...     |   |
|   +---------------------------------------------------------------------------+   |
|        |                               |                              |           |
|        v                               v                              v           |
|  +------------+                +---------------+             +-----------------+  |
|  | Chart.js   |                | AI Search     |             | Reactive Store  |  |
|  | Analytics  |                | Grounding API |             | (dbStore.ts)    |  |
|  +------------+                +---------------+             +-----------------+  |
+-----------------------------------------------------------------------------------+
                                         |
                       RESTful HTTP (JSON / SSE)
                                         v
+-----------------------------------------------------------------------------------+
|                              Python FastAPI Backend                               |
|   +---------------------------------------------------------------------------+   |
|   | Endpoints: /api/dashboard | /api/applicants | /api/applications | ...     |   |
|   +---------------------------------------------------------------------------+   |
|        |                               |                              |           |
|        v                               v                              v           |
|  +---------------------+   +---------------------+   +------------------------+   |
|  | Affordability Engine|   | Decision Engine     |   | Repayment Engine       |   |
|  | (Reducing EMI/DTI)  |   | (Rule Matrix)       |   | (Amortization & Reconc)|   |
|  +---------------------+   +---------------------+   +------------------------+   |
|                                        |                                          |
|                                        v                                          |
|                         SQLAlchemy ORM (12 Entities)                              |
|                                        |                                          |
|                                        v                                          |
|                             SQLite (loanflow.db)                                  |
+-----------------------------------------------------------------------------------+
```

---

## 2. Core Architectural Principles

1. **Determinism**:
   Financial calculations (EMI, DTI, disposable income) and business decision rules are completely deterministic. Given identical inputs, the system produces the exact same numeric and categorical output with zero stochastic variance.

2. **Full Lifecycle State Machine**:
   Loan applications follow a strictly governed state machine:
   `DRAFT` -> `SUBMITTED` -> `UNDER_REVIEW` -> `APPROVED` | `REJECTED` | `MANUAL_REVIEW` -> `DISBURSED` -> `CLOSED`.
   Invalid transitions are blocked at both client and API levels.

3. **Adverse Action Explainability**:
   Under the Equal Credit Opportunity Act (ECOA) and Fair Credit Reporting Act (FCRA), credit decisions cannot be a black box. The decision engine assigns human-readable Adverse Action reason codes (e.g. `HIGH_DTI`, `INSUFFICIENT_INCOME`, `UNSTABLE_EMPLOYMENT`) and records input snapshots.

4. **Amortization Integrity & Penny Reconciliation**:
   Because reducing-balance interest formulas produce decimal amounts, standard rounding can accumulate minor penny discrepancies. The schedule engine reconciles the final installment so that the ending outstanding balance equals exactly `$0.00`.

5. **Immutable Audit Trail**:
   All state changes, underwriting decisions, overrides, document verifications, and exception resolutions trigger an immutable event in the `LoanEvent` log with timestamps, actors, and descriptions.

---

## 3. Calculation Specifications

### 3.1 Reducing-Balance Equal Monthly Installment (EMI)
$$\text{Periodic Rate } r = \frac{\text{Annual Interest Rate}}{12 \times 100}$$
$$\text{EMI} = P \times r \times \frac{(1+r)^n}{(1+r)^n - 1}$$
When $r = 0$, $\text{EMI} = \frac{P}{n}$.

### 3.2 Debt-to-Income (DTI) Ratio
$$\text{DTI} = \frac{\text{Sum of Existing Monthly Debt Obligations} + \text{Proposed Loan EMI}}{\text{Total Verified Monthly Income}} \times 100$$
If verified monthly income $\le 0$, DTI is marked non-computable (infinite) and routes to immediate review or rejection.

### 3.3 Net Monthly Disposable Income
$$\text{Net Disposable} = \text{Monthly Income} - \text{Total Monthly Debt Obligations} - \text{Proposed EMI} - \text{Estimated Living Expenses}$$
