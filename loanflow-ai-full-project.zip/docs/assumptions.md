# Business, Regulatory & Modeling Assumptions

## 1. Interest Rate & Amortization Assumptions
- **Accrual Basis**: 30/360 or Actual/360 standard monthly periodic calculation ($r = \text{APR} / 12 / 100$).
- **Compounding Frequency**: Compounded monthly at the end of each payment cycle.
- **Rounding Convention**: Financial rounding to 2 decimal places with final installment penny-reconciliation ensuring ending outstanding balance equals exactly $0.00.

## 2. Affordability & DTI Guidelines
- **Standard DTI Cap**: 43.0% to 50.0% depending on product tier (Personal Loans 45%, Mortgages 43%, Auto Loans 50%, Working Capital 55%).
- **Borderline Buffer**: Applications with DTI within 3% of the maximum allowable threshold are routed to `MANUAL_REVIEW` rather than instant rejection.
- **Zero or Negative Income**: If verified income is $0 or negative, DTI is non-computable and the application is automatically routed to `MANUAL_REVIEW` or `REJECTED`.

## 3. Underwriting Decision Rules
- **Minimum Employment Tenure**: 6 months with the current employer is required for automated `APPROVED` status; tenures between 3 and 6 months trigger `MANUAL_REVIEW`.
- **Duplicate Protection**: Applications submitted within 30 days of an active pending application for the same national ID trigger duplicate exception review.
- **Document Verification Gate**: An application cannot transition from `UNDER_REVIEW` to `APPROVED` or `DISBURSED` unless all mandatory documents are marked `VERIFIED`, or explicitly waived by a senior underwriter with mandatory audit justification.

## 4. Synthetic Data Realism & Privacy
- **Privacy Assurance**: All synthetic borrower names, addresses, emails, and national IDs are pseudo-randomly generated; no actual consumer PII is stored.
- **Deterministic Seed**: The default random seed is fixed at `42`, guaranteeing 100% reproducible test data and test suites across environments.
