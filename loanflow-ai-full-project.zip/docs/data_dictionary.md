# Data Dictionary: LoanFlow AI Relational Schema

This document defines the 12 core relational entities, fields, constraints, data types, and relationships.

---

## 1. Applicant (`applicants`)
Stores personal, identity, and demographic details for loan applicants.

| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | VARCHAR(36) | PRIMARY KEY | Unique UUID identifier |
| `first_name` | VARCHAR(64) | NOT NULL | Applicant given name |
| `last_name` | VARCHAR(64) | NOT NULL | Applicant family name |
| `national_id` | VARCHAR(32) | UNIQUE, NOT NULL, INDEX | Tax ID or Social Security Number |
| `email` | VARCHAR(128) | NOT NULL, INDEX | Primary email address |
| `phone` | VARCHAR(32) | NOT NULL | Mobile or contact phone number |
| `date_of_birth` | VARCHAR(16) | NOT NULL | Date of birth (YYYY-MM-DD) |
| `address` | VARCHAR(256) | NOT NULL | Primary residence street address |
| `city` | VARCHAR(64) | NOT NULL | City of residence |
| `credit_score` | INTEGER | NOT NULL | Bureau credit score (300-850) |
| `risk_band` | VARCHAR(16) | NOT NULL | LOW, MEDIUM, HIGH, VERY_HIGH |
| `created_at` | TIMESTAMP | DEFAULT NOW | Creation timestamp |

---

## 2. Employment (`employments`)
Tracks employment history and stability metrics.

| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | VARCHAR(36) | PRIMARY KEY | Unique UUID |
| `applicant_id` | VARCHAR(36) | FOREIGN KEY (applicants.id) | Linked applicant |
| `employer_name` | VARCHAR(128) | NOT NULL | Registered business or employer |
| `employment_type`| VARCHAR(32) | NOT NULL | PERMANENT, CONTRACT, SELF_EMPLOYED |
| `job_title` | VARCHAR(64) | NOT NULL | Current position |
| `tenure_months` | INTEGER | NOT NULL | Duration in months |
| `is_current` | BOOLEAN | DEFAULT TRUE | Active position indicator |
| `verified` | BOOLEAN | DEFAULT FALSE | Employer verification flag |

---

## 3. IncomeRecord (`income_records`)
Granular earnings records from multiple verified or declared sources.

| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | VARCHAR(36) | PRIMARY KEY | Unique UUID |
| `applicant_id` | VARCHAR(36) | FOREIGN KEY (applicants.id) | Linked applicant |
| `income_source` | VARCHAR(32) | NOT NULL | SALARY, BUSINESS, RENTAL, INVESTMENT |
| `monthly_amount` | FLOAT | NOT NULL | Normalized monthly net amount |
| `frequency` | VARCHAR(16) | NOT NULL | MONTHLY, BIWEEKLY, ANNUALLY |
| `verification_status`| VARCHAR(16) | NOT NULL | PENDING, VERIFIED, REJECTED, CONFLICT |

---

## 4. CreditFacility (`credit_facilities`)
Existing credit lines, cards, and loan commitments.

| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | VARCHAR(36) | PRIMARY KEY | Unique UUID |
| `applicant_id` | VARCHAR(36) | FOREIGN KEY (applicants.id) | Linked applicant |
| `lender_name` | VARCHAR(128) | NOT NULL | Credit institution |
| `facility_type` | VARCHAR(32) | NOT NULL | MORTGAGE, CREDIT_CARD, AUTO_LOAN, PERSONAL |
| `credit_limit` | FLOAT | NOT NULL | Authorized credit line |
| `outstanding_balance`| FLOAT | NOT NULL | Current balance owing |
| `monthly_installment`| FLOAT | NOT NULL | Monthly required debt service |
| `status` | VARCHAR(16) | NOT NULL | ACTIVE, CLOSED, DEFAULT |

---

## 5. LoanProduct (`loan_products`)
Configurable credit products and policy parameters.

| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | VARCHAR(36) | PRIMARY KEY | Unique product ID |
| `name` | VARCHAR(64) | NOT NULL | Public product title |
| `code` | VARCHAR(32) | UNIQUE, NOT NULL | Internal product code |
| `description` | VARCHAR(256) | NOT NULL | Product marketing overview |
| `min_principal` | FLOAT | NOT NULL | Minimum borrowing limit |
| `max_principal` | FLOAT | NOT NULL | Maximum borrowing limit |
| `min_tenure_months`| INTEGER | NOT NULL | Minimum term in months |
| `max_tenure_months`| INTEGER | NOT NULL | Maximum term in months |
| `annual_interest_rate`| FLOAT | NOT NULL | Annual percentage rate (APR %) |
| `min_income` | FLOAT | NOT NULL | Minimum monthly income requirement |
| `max_dti_ratio` | FLOAT | NOT NULL | Maximum allowable DTI (%) |
| `required_employment`| VARCHAR(32) | NOT NULL | Permitted employment status |
| `status` | VARCHAR(16) | NOT NULL | ACTIVE, INACTIVE |

---

## 6. LoanApplication (`loan_applications`)
Core loan origination record.

| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | VARCHAR(36) | PRIMARY KEY | Unique UUID |
| `application_number`| VARCHAR(32) | UNIQUE, NOT NULL, INDEX | Human-readable tracking number |
| `applicant_id` | VARCHAR(36) | FOREIGN KEY (applicants.id) | Borrower |
| `product_id` | VARCHAR(36) | FOREIGN KEY (loan_products.id)| Selected credit product |
| `requested_principal`| FLOAT | NOT NULL | Requested borrowing amount |
| `requested_tenure_months`| INTEGER | NOT NULL | Requested repayment months |
| `loan_purpose` | VARCHAR(128) | NOT NULL | Stated use of funds |
| `status` | VARCHAR(24) | NOT NULL, INDEX | DRAFT, SUBMITTED, UNDER_REVIEW, APPROVED, REJECTED, MANUAL_REVIEW, DISBURSED, CLOSED |

---

## 7. Document (`documents`)
Attached identity and income documentation.

| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | VARCHAR(36) | PRIMARY KEY | Unique UUID |
| `application_id` | VARCHAR(36) | FOREIGN KEY (loan_applications.id)| Linked application |
| `document_type` | VARCHAR(32) | NOT NULL | IDENTITY_PROOF, INCOME_PROOF, etc. |
| `document_name` | VARCHAR(128) | NOT NULL | File display name |
| `status` | VARCHAR(16) | NOT NULL | PENDING, VERIFIED, REJECTED, MISSING |
| `verification_notes`| VARCHAR(256) | NULLABLE | Underwriter audit remarks |

---

## 8. AffordabilityCheck (`affordability_checks`)
Snapshot of financial affordability math executed.

| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | VARCHAR(36) | PRIMARY KEY | Unique UUID |
| `application_id` | VARCHAR(36) | FOREIGN KEY (loan_applications.id)| Linked application |
| `monthly_income` | FLOAT | NOT NULL | Verified monthly income |
| `existing_monthly_debt`| FLOAT | NOT NULL | Sum of other monthly debt obligations |
| `proposed_emi` | FLOAT | NOT NULL | Reducing-balance EMI |
| `dti_ratio` | FLOAT | NOT NULL | Total debt to income (%) |
| `disposable_income`| FLOAT | NOT NULL | Net disposable income remaining |
| `max_affordable_principal`| FLOAT | NOT NULL | Maximum affordable borrowing power |

---

## 9. Decision (`decisions`)
Deterministic underwriting evaluation record.

| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | VARCHAR(36) | PRIMARY KEY | Unique UUID |
| `application_id` | VARCHAR(36) | FOREIGN KEY (loan_applications.id)| Linked application |
| `outcome` | VARCHAR(16) | NOT NULL | APPROVED, REJECTED, MANUAL_REVIEW |
| `reason_codes` | JSON | NOT NULL | Array of triggered rule codes |
| `explanation` | TEXT | NOT NULL | Plain-text explainability summary |
| `rule_version` | VARCHAR(16) | NOT NULL | Decision engine version |
| `underwriter_override`| BOOLEAN | DEFAULT FALSE | Override flag |
| `override_reason`| TEXT | NULLABLE | Mandatory underwriter justification |

---

## 10. RepaymentSchedule (`repayment_schedules`)
Periodic amortization installment breakdown.

| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | VARCHAR(36) | PRIMARY KEY | Unique UUID |
| `application_id` | VARCHAR(36) | FOREIGN KEY (loan_applications.id)| Linked application |
| `installment_number`| INTEGER | NOT NULL | Period index (1 to N) |
| `due_date` | VARCHAR(16) | NOT NULL | Due date (YYYY-MM-DD) |
| `principal_component`| FLOAT | NOT NULL | Principal reduction |
| `interest_component` | FLOAT | NOT NULL | Interest payment |
| `total_installment` | FLOAT | NOT NULL | Monthly EMI |
| `outstanding_principal`| FLOAT | NOT NULL | Remaining balance |

---

## 11. LoanEvent (`loan_events`)
Immutable compliance audit event log.

| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | VARCHAR(36) | PRIMARY KEY | Unique UUID |
| `entity_type` | VARCHAR(32) | NOT NULL | Entity name |
| `entity_id` | VARCHAR(36) | NOT NULL | Entity identifier |
| `event_type` | VARCHAR(32) | NOT NULL | Action performed |
| `description` | VARCHAR(256) | NOT NULL | Audit text summary |
| `actor` | VARCHAR(64) | NOT NULL | User or system actor |
| `created_at` | TIMESTAMP | DEFAULT NOW | Timestamp |

---

## 12. IssueRecord (`issue_records`)
Exceptions, data conflicts, and policy violation tracker.

| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | VARCHAR(36) | PRIMARY KEY | Unique UUID |
| `application_id` | VARCHAR(36) | FOREIGN KEY (loan_applications.id)| Linked application |
| `issue_type` | VARCHAR(32) | NOT NULL | Category of exception |
| `severity` | VARCHAR(16) | NOT NULL | LOW, MEDIUM, HIGH, CRITICAL |
| `description` | VARCHAR(256) | NOT NULL | Detailed issue narrative |
| `resolution_status`| VARCHAR(16) | NOT NULL | OPEN, IN_PROGRESS, RESOLVED, WAIVED |
| `resolution_remarks`| VARCHAR(256)| NULLABLE | Resolution audit remarks |
