# Engineering Prompt & Iteration History: LoanFlow AI

## Initial Prompt & Requirements
- **Goal**: Build LoanFlow AI, an intelligent loan origination, affordability calculation, deterministic decision engine, document verification, repayment schedule, exception management, audit logging, and portfolio reporting platform.
- **Stack**:
  - Frontend: React, TypeScript, Tailwind CSS, shadcn/ui, Chart.js, Lucide icons, responsive navigation with 12 sections.
  - Backend: Python, FastAPI, SQLAlchemy ORM, SQLite database, Pydantic schemas, and automated test suites.
  - Synthetic Data Engine: Seedable generator producing 10,000 applicants, 6,000 applications, 4 configurable loan products, and deliberate edge cases.

## Iteration Log

1. **Design System & Aesthetics**:
   - Initialized modern fintech theme tokens in `src/index.css` (Navy sidebar `hsl(222 47% 11%)`, blue/indigo accent `hsl(221 83% 53%)`, slate background).
   - Documented visual design principles in `docs/DESIGN.md`.

2. **Python Backend Architecture**:
   - Created `backend/` with SQLite config (`loanflow.db`), SQLAlchemy 12 entity models in `models.py`, Pydantic schemas in `schemas.py`.
   - Implemented deterministic financial algorithms in `services/affordability.py` and `services/repayment.py`.
   - Implemented rule-based decisioning in `services/decision_engine.py` with Adverse Action reason codes.
   - Built seedable synthetic dataset generator in `services/synthetic_generator.py`.
   - Built comprehensive automated test suite (`tests/test_loanflow.py` and `tests/test_suite_unittest.py`), verifying 100% pass on calculations, DTI edge cases, and reconciliation.

3. **Frontend Reactive State & Client Store**:
   - Implemented `src/services/dbStore.ts` mirroring the relational model with reactive state, localStorage synchronization, and deterministic client-side calculation engines.
   - Defined TypeScript models in `src/types/loanflow.ts`.

4. **UI Components & 12 Pages**:
   - Built `AppLayout.tsx` with collapsible navy sidebar and mobile sheet drawer.
   - Built `AISearchModal.tsx` for real-time grounded underwriting search and source citations.
   - Built `DashboardPage.tsx` with 8 KPI metric cards and 6 Chart.js interactive charts.
   - Built `ApplicantsPage.tsx` with search, filtering, and `ApplicantDetailModal.tsx`.
   - Built `ApplicationsPage.tsx` with pipeline filters and multi-step `NewApplicationModal.tsx`.
   - Built `ProductsPage.tsx`, `AffordabilityPage.tsx`, `DecisionsPage.tsx`, `DocumentsPage.tsx`, `RepaymentsPage.tsx`, `ExceptionsPage.tsx`, `AuditLogsPage.tsx`, `ReportsPage.tsx`, and `SettingsPage.tsx`.

5. **Linting & Validation**:
   - Ran `npm run lint` and verified clean compile with zero errors.
