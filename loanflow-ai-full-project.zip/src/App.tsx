import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import IntersectObserver from '@/components/common/IntersectObserver';
import { Toaster } from '@/components/ui/sonner';
import { AppLayout } from '@/components/layout/AppLayout';
import { NewApplicationModal } from '@/components/applications/NewApplicationModal';
import { NewApplicantModal } from '@/components/applicants/NewApplicantModal';
import { routes } from './routes';

const App: React.FC = () => {
  const [newAppOpen, setNewAppOpen] = useState(false);
  const [newApplicantOpen, setNewApplicantOpen] = useState(false);

  return (
    <Router>
      <IntersectObserver />
      <AppLayout
        onOpenNewApplication={() => setNewAppOpen(true)}
        onOpenNewApplicant={() => setNewApplicantOpen(true)}
      >
        <Routes>
          {routes.map((route, index) => (
            <Route
              key={index}
              path={route.path}
              element={route.element}
            />
          ))}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AppLayout>

      <NewApplicationModal
        open={newAppOpen}
        onOpenChange={setNewAppOpen}
        onSuccess={(id) => {
          window.location.href = `/applications?id=${id}`;
        }}
      />

      <NewApplicantModal
        open={newApplicantOpen}
        onOpenChange={setNewApplicantOpen}
        onSuccess={() => {
          window.location.href = '/applicants';
        }}
      />

      <Toaster position="top-right" richColors />
    </Router>
  );
};

export default App;
