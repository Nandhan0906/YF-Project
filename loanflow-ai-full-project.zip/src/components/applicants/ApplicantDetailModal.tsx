import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  User,
  Briefcase,
  DollarSign,
  CreditCard,
  FileSpreadsheet,
  CheckCircle,
  AlertTriangle,
  Clock
} from 'lucide-react';
import { Applicant } from '@/types/loanflow';
import { dbStore } from '@/services/dbStore';

interface ApplicantDetailModalProps {
  applicantId: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onApplyLoan?: (applicantId: string) => void;
}

export const ApplicantDetailModal: React.FC<ApplicantDetailModalProps> = ({
  applicantId,
  open,
  onOpenChange,
  onApplyLoan
}) => {
  if (!applicantId) return null;
  const applicant = dbStore.applicants.get(applicantId);
  if (!applicant) return null;

  const employments = Array.from(dbStore.employments.values()).filter(e => e.applicant_id === applicantId);
  const incomes = Array.from(dbStore.incomes.values()).filter(i => i.applicant_id === applicantId);
  const facilities = Array.from(dbStore.creditFacilities.values()).filter(f => f.applicant_id === applicantId);
  const applications = Array.from(dbStore.applications.values()).filter(a => a.applicant_id === applicantId);

  const totalMonthlyIncome = incomes.reduce((s, i) => s + i.monthly_amount, 0);
  const totalMonthlyDebt = facilities.filter(f => f.status === 'ACTIVE').reduce((s, f) => s + f.monthly_installment, 0);

  const getRiskBadge = (band: string) => {
    switch (band) {
      case 'LOW':
        return <Badge className="bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border-emerald-500/30">LOW RISK (Prime)</Badge>;
      case 'MEDIUM':
        return <Badge className="bg-blue-500/20 text-blue-700 dark:text-blue-400 border-blue-500/30">MEDIUM RISK</Badge>;
      case 'HIGH':
        return <Badge className="bg-amber-500/20 text-amber-700 dark:text-amber-400 border-amber-500/30">HIGH RISK</Badge>;
      default:
        return <Badge variant="destructive">VERY HIGH RISK</Badge>;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-3xl max-h-[90dvh] overflow-y-auto bg-card border-border">
        <DialogHeader className="border-b border-border pb-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <DialogTitle className="text-xl font-bold text-foreground">
                {applicant.first_name} {applicant.last_name}
              </DialogTitle>
              <p className="text-xs text-muted-foreground mt-0.5 font-mono">
                ID: {applicant.id} • National ID: {applicant.national_id}
              </p>
            </div>
            <div className="flex items-center gap-2">
              {getRiskBadge(applicant.risk_band)}
              {onApplyLoan && (
                <Button
                  size="sm"
                  onClick={() => {
                    onOpenChange(false);
                    onApplyLoan(applicant.id);
                  }}
                  className="bg-primary text-primary-foreground hover:bg-primary/90 h-8 text-xs font-semibold"
                >
                  Apply for Loan
                </Button>
              )}
            </div>
          </div>
        </DialogHeader>

        {/* Quick Highlights Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-2">
          <div className="p-2.5 rounded-lg bg-muted/40 border border-border">
            <span className="text-[11px] text-muted-foreground block">Credit Score</span>
            <span className="text-lg font-bold text-foreground">{applicant.credit_score}</span>
          </div>
          <div className="p-2.5 rounded-lg bg-muted/40 border border-border">
            <span className="text-[11px] text-muted-foreground block">Total Monthly Income</span>
            <span className="text-lg font-bold text-emerald-600 dark:text-emerald-400">
              ${totalMonthlyIncome.toLocaleString()}
            </span>
          </div>
          <div className="p-2.5 rounded-lg bg-muted/40 border border-border">
            <span className="text-[11px] text-muted-foreground block">Monthly Debt Commitments</span>
            <span className="text-lg font-bold text-foreground">
              ${totalMonthlyDebt.toLocaleString()}
            </span>
          </div>
          <div className="p-2.5 rounded-lg bg-muted/40 border border-border">
            <span className="text-[11px] text-muted-foreground block">Existing DTI</span>
            <span className="text-lg font-bold text-purple-600">
              {totalMonthlyIncome > 0 ? `${((totalMonthlyDebt / totalMonthlyIncome) * 100).toFixed(1)}%` : 'N/A'}
            </span>
          </div>
        </div>

        {/* Tabbed Profile Views */}
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid grid-cols-5 w-full bg-muted">
            <TabsTrigger value="overview" className="text-xs">Overview</TabsTrigger>
            <TabsTrigger value="employment" className="text-xs">Employment</TabsTrigger>
            <TabsTrigger value="income" className="text-xs">Income</TabsTrigger>
            <TabsTrigger value="facilities" className="text-xs">Credit Lines</TabsTrigger>
            <TabsTrigger value="applications" className="text-xs">Loans ({applications.length})</TabsTrigger>
          </TabsList>

          {/* Tab 1: Overview */}
          <TabsContent value="overview" className="space-y-3 pt-3 text-xs">
            <div className="grid grid-cols-2 gap-3 p-3 rounded-lg bg-muted/20 border border-border">
              <div>
                <span className="text-muted-foreground block">Email</span>
                <span className="font-medium text-foreground">{applicant.email}</span>
              </div>
              <div>
                <span className="text-muted-foreground block">Phone</span>
                <span className="font-medium text-foreground">{applicant.phone}</span>
              </div>
              <div>
                <span className="text-muted-foreground block">Date of Birth</span>
                <span className="font-medium text-foreground">{applicant.date_of_birth}</span>
              </div>
              <div>
                <span className="text-muted-foreground block">City / State</span>
                <span className="font-medium text-foreground">{applicant.city}</span>
              </div>
              <div className="col-span-2">
                <span className="text-muted-foreground block">Residential Address</span>
                <span className="font-medium text-foreground">{applicant.address}</span>
              </div>
              <div>
                <span className="text-muted-foreground block">Registered On</span>
                <span className="font-medium text-foreground">
                  {new Date(applicant.created_at).toLocaleDateString()}
                </span>
              </div>
            </div>
          </TabsContent>

          {/* Tab 2: Employment */}
          <TabsContent value="employment" className="space-y-3 pt-3 text-xs">
            {employments.length === 0 ? (
              <p className="text-muted-foreground py-4 text-center">No employment records attached.</p>
            ) : (
              <div className="space-y-2">
                {employments.map(e => (
                  <div key={e.id} className="p-3 rounded-lg border border-border bg-muted/20 flex items-center justify-between">
                    <div>
                      <p className="font-bold text-foreground text-sm">{e.employer_name}</p>
                      <p className="text-muted-foreground">{e.job_title} • {e.employment_type}</p>
                      <p className="text-[11px] text-muted-foreground mt-0.5">Tenure: {e.tenure_months} months {e.is_current ? '(Current)' : ''}</p>
                    </div>
                    <div>
                      {e.verified ? (
                        <Badge className="bg-emerald-500/20 text-emerald-600 border-none">Verified</Badge>
                      ) : (
                        <Badge variant="outline" className="text-amber-600">Pending Verification</Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Tab 3: Income Records */}
          <TabsContent value="income" className="space-y-3 pt-3 text-xs">
            {incomes.length === 0 ? (
              <p className="text-muted-foreground py-4 text-center">No income records registered.</p>
            ) : (
              <div className="space-y-2">
                {incomes.map(inc => (
                  <div key={inc.id} className="p-3 rounded-lg border border-border bg-muted/20 flex items-center justify-between">
                    <div>
                      <p className="font-bold text-foreground text-sm">
                        ${inc.monthly_amount.toLocaleString()} / mo
                      </p>
                      <p className="text-muted-foreground">{inc.income_source.replace(/_/g, ' ')} • {inc.frequency}</p>
                    </div>
                    <div>
                      {inc.verification_status === 'VERIFIED' && (
                        <Badge className="bg-emerald-500/20 text-emerald-600 border-none">Verified</Badge>
                      )}
                      {inc.verification_status === 'CONFLICT' && (
                        <Badge variant="destructive">Conflict Flagged</Badge>
                      )}
                      {inc.verification_status === 'PENDING' && (
                        <Badge variant="outline" className="text-amber-600">Pending</Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Tab 4: Credit Facilities */}
          <TabsContent value="facilities" className="space-y-3 pt-3 text-xs">
            {facilities.length === 0 ? (
              <p className="text-muted-foreground py-4 text-center">No existing credit lines registered.</p>
            ) : (
              <div className="space-y-2">
                {facilities.map(fac => (
                  <div key={fac.id} className="p-3 rounded-lg border border-border bg-muted/20 flex items-center justify-between">
                    <div>
                      <p className="font-bold text-foreground">{fac.lender_name}</p>
                      <p className="text-muted-foreground">{fac.facility_type.replace(/_/g, ' ')}</p>
                      <p className="text-[11px] text-muted-foreground mt-0.5">
                        Balance: ${fac.outstanding_balance.toLocaleString()} / Limit: ${fac.credit_limit.toLocaleString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-foreground">${fac.monthly_installment.toLocaleString()} / mo</p>
                      <Badge variant="outline" className="text-[10px] mt-0.5">{fac.status}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Tab 5: Applications */}
          <TabsContent value="applications" className="space-y-3 pt-3 text-xs">
            {applications.length === 0 ? (
              <p className="text-muted-foreground py-4 text-center">No loan applications yet.</p>
            ) : (
              <div className="space-y-2">
                {applications.map(app => {
                  const prod = dbStore.products.get(app.product_id);
                  return (
                    <div key={app.id} className="p-3 rounded-lg border border-border bg-muted/20 flex items-center justify-between">
                      <div>
                        <p className="font-mono font-bold text-foreground">{app.application_number}</p>
                        <p className="text-muted-foreground">{prod ? prod.name : 'Loan'}</p>
                        <p className="text-[11px] text-muted-foreground mt-0.5">
                          ${app.requested_principal.toLocaleString()} for {app.requested_tenure_months} months
                        </p>
                      </div>
                      <div className="text-right">
                        <Badge variant="outline">{app.status}</Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};
