import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { toast } from 'sonner';
import { dbStore } from '@/services/dbStore';
import { RiskBand } from '@/types/loanflow';

interface NewApplicantModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: (newId: string) => void;
}

export const NewApplicantModal: React.FC<NewApplicantModalProps> = ({
  open,
  onOpenChange,
  onSuccess
}) => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [nationalId, setNationalId] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [dob, setDob] = useState('1990-01-01');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('New York');
  const [creditScore, setCreditScore] = useState(700);
  const [riskBand, setRiskBand] = useState<RiskBand>('LOW');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName || !lastName || !nationalId || !email) {
      toast.error('Please fill in all mandatory applicant fields.');
      return;
    }

    try {
      const applicant = dbStore.createApplicant({
        first_name: firstName,
        last_name: lastName,
        national_id: nationalId,
        email,
        phone: phone || '+1-555-019-2831',
        date_of_birth: dob,
        address: address || '100 Main Street',
        city,
        credit_score: creditScore,
        risk_band: riskBand
      });

      toast.success(`Applicant ${applicant.first_name} ${applicant.last_name} registered successfully!`);
      onOpenChange(false);
      onSuccess(applicant.id);

      // Reset
      setFirstName('');
      setLastName('');
      setNationalId('');
      setEmail('');
      setAddress('');
    } catch (err: any) {
      toast.error(err.message || 'Failed to create applicant');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-xl bg-card border-border">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold">Register New Loan Applicant</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 pt-2 text-sm">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>First Name *</Label>
              <Input
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                placeholder="e.g. John"
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label>Last Name *</Label>
              <Input
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                placeholder="e.g. Doe"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>National ID (SSN / Tax ID) *</Label>
              <Input
                value={nationalId}
                onChange={(e) => setNationalId(e.target.value)}
                placeholder="e.g. NAT-902184"
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label>Email Address *</Label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="e.g. john.doe@example.com"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Phone Number</Label>
              <Input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+1-555-019-2831"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Date of Birth</Label>
              <Input
                type="date"
                value={dob}
                onChange={(e) => setDob(e.target.value)}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Address</Label>
              <Input
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="e.g. 742 Evergreen Terrace"
              />
            </div>
            <div className="space-y-1.5">
              <Label>City</Label>
              <Input
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="e.g. New York"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Credit Score (300 - 850)</Label>
              <Input
                type="number"
                min={300}
                max={850}
                value={creditScore}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setCreditScore(val);
                  if (val >= 750) setRiskBand('LOW');
                  else if (val >= 650) setRiskBand('MEDIUM');
                  else if (val >= 580) setRiskBand('HIGH');
                  else setRiskBand('VERY_HIGH');
                }}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Calculated Risk Band</Label>
              <Select value={riskBand} onValueChange={(val: any) => setRiskBand(val)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select risk band" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="LOW">LOW (Prime)</SelectItem>
                  <SelectItem value="MEDIUM">MEDIUM (Near Prime)</SelectItem>
                  <SelectItem value="HIGH">HIGH (Subprime)</SelectItem>
                  <SelectItem value="VERY_HIGH">VERY_HIGH (Deep Subprime)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-border">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90">
              Register Applicant
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
