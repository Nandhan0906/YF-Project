import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  FileText,
  Calculator,
  Scale,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Play,
  RotateCcw,
  CalendarDays,
  ShieldCheck,
  Send
} from 'lucide-react';
import { toast } from 'sonner';
import { dbStore } from '@/services/dbStore';
import { DecisionOutcome } from '@/types/loanflow';

interface ApplicationDetailModalProps {
  applicationId: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onRefresh?: () => void;
}

export const ApplicationDetailModal: React.FC<ApplicationDetailModalProps> = ({
  applicationId,
  open,
  onOpenChange,
  onRefresh
}) => {
  const [overrideOutcome, setOverrideOutcome] = useState<DecisionOutcome>('APPROVED');
  const [overrideReason, setOverrideReason] = useState('');
  const [isOverriding, setIsOverriding] = useState(false);

  if (!applicationId) return null;
  const app = dbStore.applications.get(applicationId);
  if (!app) return null;

  const applicant = dbStore.applicants.get(app.applicant_id);
  const product = dbStore.products.get(app.product_id);
  const afford = Array.from(dbStore.affordabilityChecks.values()).reverse().find(a => a.application_id === applicationId);
  const decision = Array.from(dbStore.decisions.values()).reverse().find(d => d.application_id === applicationId);
  const docs = Array.from(dbStore.documents.values()).filter(d => d.application_id === applicationId);
  const schedule = dbStore.repaymentSchedules.get(applicationId) || [];

  const handleRunDecision = () => {
    try {
      const res = dbStore.evaluateApplication(app.id);
      toast.success(`Automated Decision generated: ${res.decision.outcome}`);
      if (onRefresh) onRefresh();
    } catch (err: any) {
      toast.error(err.message || 'Failed to run decision');
    }
  };

  const handleSubmitDraft = () => {
    try {
      dbStore.submitApplication(app.id);
      toast.success('Application moved to SUBMITTED state');
      if (onRefresh) onRefresh();
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handleOverrideSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!overrideReason.trim()) {
      toast.error('Underwriter justification note is required for manual override.');
      return;
    }

    try {
      dbStore.overrideDecision(app.id, overrideOutcome, overrideReason);
      toast.success(`Decision successfully overridden to ${overrideOutcome}`);
      setIsOverriding(false);
      setOverrideReason('');
      if (onRefresh) onRefresh();
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'APPROVED':
      case 'DISBURSED':
        return <Badge className="bg-emerald-500/20 text-emerald-600 border-none">Approved</Badge>;
      case 'REJECTED':
        return <Badge variant="destructive">Rejected</Badge>;
      case 'MANUAL_REVIEW':
        return <Badge className="bg-amber-500/20 text-amber-700 dark:text-amber-300 border-amber-500/30">Manual Review</Badge>;
      case 'SUBMITTED':
        return <Badge className="bg-blue-500/20 text-blue-600 border-none">Submitted</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-4xl max-h-[90dvh] overflow-y-auto bg-card border-border">
        <DialogHeader className="border-b border-border pb-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <DialogTitle className="text-xl font-bold text-foreground flex items-center gap-2">
                <span>Application: {app.application_number}</span>
                {getStatusBadge(app.status)}
              </DialogTitle>
              <p className="text-xs text-muted-foreground mt-0.5">
                Borrower: <span className="font-semibold text-foreground">{applicant ? `${applicant.first_name} ${applicant.last_name}` : 'Unknown'}</span> • Product: {product ? product.name : 'Loan'}
              </p>
            </div>
            <div className="flex items-center gap-2">
              {app.status === 'DRAFT' && (
                <Button size="sm" onClick={handleSubmitDraft} className="bg-blue-600 hover:bg-blue-500 text-white text-xs gap-1.5 h-8">
                  <Send className="w-3.5 h-3.5" /> Submit to Underwriting
                </Button>
              )}
              {app.status === 'SUBMITTED' && (
                <Button size="sm" onClick={handleRunDecision} className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs gap-1.5 h-8">
                  <Play className="w-3.5 h-3.5" /> Run Decision Engine
                </Button>
              )}
              {decision && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setIsOverriding(!isOverriding)}
                  className="text-xs gap-1.5 h-8"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Underwriter Override
                </Button>
              )}
            </div>
          </div>
        </DialogHeader>

        {/* Override Drawer / Form */}
        {isOverriding && (
          <form onSubmit={handleOverrideSubmit} className="p-3.5 rounded-lg bg-amber-500/10 border border-amber-500/30 space-y-2.5 text-xs">
            <p className="font-bold text-amber-900 dark:text-amber-200">Manual Underwriter Decision Override</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <Label>Override Outcome</Label>
                <select
                  value={overrideOutcome}
                  onChange={(e: any) => setOverrideOutcome(e.target.value)}
                  className="w-full h-8 mt-1 rounded bg-background border border-border px-2 text-xs"
                >
                  <option value="APPROVED">APPROVED</option>
                  <option value="REJECTED">REJECTED</option>
                  <option value="MANUAL_REVIEW">MANUAL_REVIEW</option>
                </select>
              </div>
              <div>
                <Label>Mandatory Audit Rationale *</Label>
                <Input
                  value={overrideReason}
                  onChange={(e) => setOverrideReason(e.target.value)}
                  placeholder="e.g. Compensating factor: 12 months liquid reserves."
                  className="h-8 text-xs mt-1"
                  required
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <Button type="button" variant="ghost" size="sm" onClick={() => setIsOverriding(false)} className="h-7 text-xs">
                Cancel
              </Button>
              <Button type="submit" size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 h-7 text-xs">
                Record Override
              </Button>
            </div>
          </form>
        )}

        {/* Quick Highlights Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-2 text-xs">
          <div className="p-2.5 rounded-lg bg-muted/40 border border-border">
            <span className="text-muted-foreground block text-[11px]">Requested Principal</span>
            <span className="text-base font-bold text-foreground">${app.requested_principal.toLocaleString()}</span>
          </div>
          <div className="p-2.5 rounded-lg bg-muted/40 border border-border">
            <span className="text-muted-foreground block text-[11px]">Tenure & Rate</span>
            <span className="text-base font-bold text-foreground">{app.requested_tenure_months}m @ {product?.annual_interest_rate}%</span>
          </div>
          <div className="p-2.5 rounded-lg bg-muted/40 border border-border">
            <span className="text-muted-foreground block text-[11px]">Calculated DTI</span>
            <span className="text-base font-bold text-purple-600">{afford ? `${afford.dti_ratio}%` : 'Pending'}</span>
          </div>
          <div className="p-2.5 rounded-lg bg-muted/40 border border-border">
            <span className="text-muted-foreground block text-[11px]">Decision Outcome</span>
            <span className="text-base font-bold text-foreground">{decision ? decision.outcome : 'Pending'}</span>
          </div>
        </div>

        {/* Tabbed Inspection View */}
        <Tabs defaultValue="affordability" className="w-full">
          <TabsList className="grid grid-cols-4 w-full bg-muted text-xs">
            <TabsTrigger value="affordability">Affordability</TabsTrigger>
            <TabsTrigger value="decision">Decision & Rules</TabsTrigger>
            <TabsTrigger value="documents">Documents ({docs.length})</TabsTrigger>
            <TabsTrigger value="schedule">Repayment ({schedule.length})</TabsTrigger>
          </TabsList>

          {/* Tab 1: Affordability */}
          <TabsContent value="affordability" className="space-y-3 pt-3 text-xs">
            {!afford ? (
              <p className="text-muted-foreground py-4 text-center">Affordability calculation not yet executed.</p>
            ) : (
              <div className="space-y-3">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 rounded-lg bg-muted/20 border border-border">
                  <div>
                    <span className="text-muted-foreground block">Verified Income</span>
                    <span className="font-bold text-foreground text-sm">${afford.monthly_income.toLocaleString()} / mo</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground block">Existing Debt</span>
                    <span className="font-bold text-foreground text-sm">${afford.existing_monthly_debt.toLocaleString()} / mo</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground block">Proposed EMI</span>
                    <span className="font-bold text-primary text-sm">${afford.proposed_emi.toLocaleString()} / mo</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground block">Net Disposable</span>
                    <span className={`font-bold text-sm ${afford.disposable_income < 0 ? 'text-destructive' : 'text-emerald-600'}`}>
                      ${afford.disposable_income.toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-muted/40 border border-border">
                  <span className="font-semibold text-foreground block mb-1">Mathematical Formula & Invariant Audit:</span>
                  <p className="text-muted-foreground font-mono leading-relaxed">{afford.notes}</p>
                </div>
              </div>
            )}
          </TabsContent>

          {/* Tab 2: Decision & Rules */}
          <TabsContent value="decision" className="space-y-3 pt-3 text-xs">
            {!decision ? (
              <p className="text-muted-foreground py-4 text-center">Decision engine evaluation pending.</p>
            ) : (
              <div className="space-y-3">
                <div className="p-3 rounded-lg border border-border bg-muted/20 flex items-center justify-between">
                  <div>
                    <p className="font-bold text-foreground text-sm">Outcome: {decision.outcome}</p>
                    <p className="text-muted-foreground text-[11px]">Rule Engine Version: {decision.rule_version} • Decided By: {decision.decided_by}</p>
                  </div>
                  {decision.underwriter_override && (
                    <Badge variant="outline" className="bg-amber-500/20 text-amber-700">Overridden by Senior Underwriter</Badge>
                  )}
                </div>

                <div className="p-3 rounded-lg bg-muted/40 border border-border space-y-1">
                  <p className="font-semibold text-foreground">Detailed Explanation:</p>
                  <p className="text-muted-foreground leading-relaxed">{decision.explanation}</p>
                  {decision.override_reason && (
                    <p className="text-amber-800 dark:text-amber-200 mt-2 font-medium">
                      Override Reason: {decision.override_reason}
                    </p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <p className="font-semibold text-foreground">Triggered Business Reason Codes:</p>
                  <div className="flex flex-wrap gap-1.5">
                    {decision.reason_codes.map((rc, i) => (
                      <Badge key={i} variant="outline" className="font-mono text-[10px]">
                        {rc}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </TabsContent>

          {/* Tab 3: Documents */}
          <TabsContent value="documents" className="space-y-3 pt-3 text-xs">
            <div className="space-y-2">
              {docs.map(doc => (
                <div key={doc.id} className="p-3 rounded-lg border border-border bg-muted/20 flex items-center justify-between">
                  <div>
                    <p className="font-bold text-foreground">{doc.document_name}</p>
                    <p className="text-muted-foreground">{doc.document_type.replace(/_/g, ' ')}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className={doc.status === 'VERIFIED' ? 'text-emerald-600' : (doc.status === 'REJECTED' ? 'text-rose-600' : 'text-amber-600')}>
                      {doc.status}
                    </Badge>
                    {doc.status === 'PENDING' && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          dbStore.updateDocumentStatus(doc.id, 'VERIFIED');
                          toast.success(`${doc.document_name} verified`);
                          if (onRefresh) onRefresh();
                        }}
                        className="h-7 text-[11px]"
                      >
                        Verify
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Tab 4: Repayment Schedule */}
          <TabsContent value="schedule" className="space-y-3 pt-3 text-xs">
            {schedule.length === 0 ? (
              <p className="text-muted-foreground py-4 text-center">
                Repayment schedule will be generated once application is APPROVED or DISBURSED.
              </p>
            ) : (
              <div className="space-y-2">
                <div className="flex justify-between items-center text-muted-foreground">
                  <span>{schedule.length} Monthly Installments</span>
                  <Badge className="bg-emerald-500/20 text-emerald-600 border-none">
                    Schedule Reconciled to $0.00
                  </Badge>
                </div>
                <div className="max-h-60 overflow-y-auto border border-border rounded-lg">
                  <table className="w-full text-left text-[11px] whitespace-nowrap">
                    <thead className="bg-muted/40 sticky top-0 border-b border-border text-muted-foreground">
                      <tr>
                        <th className="p-2">#</th>
                        <th className="p-2">Due Date</th>
                        <th className="p-2">Principal</th>
                        <th className="p-2">Interest</th>
                        <th className="p-2">Total EMI</th>
                        <th className="p-2 text-right">Balance</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border/60">
                      {schedule.map(inst => (
                        <tr key={inst.id}>
                          <td className="p-2 font-mono">{inst.installment_number}</td>
                          <td className="p-2 text-muted-foreground">{inst.due_date}</td>
                          <td className="p-2 font-medium">${inst.principal_component.toLocaleString()}</td>
                          <td className="p-2 text-muted-foreground">${inst.interest_component.toLocaleString()}</td>
                          <td className="p-2 font-bold">${inst.total_installment.toLocaleString()}</td>
                          <td className="p-2 text-right font-mono">${inst.outstanding_principal.toLocaleString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};
