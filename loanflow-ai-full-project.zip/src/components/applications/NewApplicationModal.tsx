import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { dbStore, calculateAffordability } from '@/services/dbStore';
import { Check, ChevronRight, AlertCircle, FileText, Calculator } from 'lucide-react';

interface NewApplicationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialApplicantId?: string | null;
  onSuccess: (applicationId: string) => void;
}

export const NewApplicationModal: React.FC<NewApplicationModalProps> = ({
  open,
  onOpenChange,
  initialApplicantId,
  onSuccess
}) => {
  const [step, setStep] = useState(1);
  const [applicantId, setApplicantId] = useState<string>('');
  const [productId, setProductId] = useState<string>('prod-personal-01');
  const [principal, setPrincipal] = useState<number>(15000);
  const [tenure, setTenure] = useState<number>(36);
  const [purpose, setPurpose] = useState<string>('Debt Consolidation');

  const applicants = Array.from(dbStore.applicants.values());
  const products = Array.from(dbStore.products.values());

  useEffect(() => {
    if (initialApplicantId) {
      setApplicantId(initialApplicantId);
    } else if (applicants.length > 0 && !applicantId) {
      setApplicantId(applicants[0].id);
    }
  }, [initialApplicantId, applicants]);

  const selectedApplicant = dbStore.applicants.get(applicantId);
  const selectedProduct = dbStore.products.get(productId) || products[0];

  // Affordability Preview
  const incList = Array.from(dbStore.incomes.values()).filter(i => i.applicant_id === applicantId);
  const mIncome = incList.reduce((s, i) => s + i.monthly_amount, 0);
  const facList = Array.from(dbStore.creditFacilities.values()).filter(f => f.applicant_id === applicantId && f.status === 'ACTIVE');
  const mDebt = facList.reduce((s, f) => s + f.monthly_installment, 0);

  const affordPreview = calculateAffordability(
    mIncome,
    mDebt,
    principal,
    selectedProduct ? selectedProduct.annual_interest_rate : 8.75,
    tenure,
    selectedProduct ? selectedProduct.max_dti_ratio : 45.0
  );

  const handleSubmit = () => {
    if (!applicantId || !productId) {
      toast.error('Please select both an applicant and a loan product.');
      return;
    }

    try {
      const newApp = dbStore.createApplication(applicantId, productId, principal, tenure, purpose);
      toast.success(`Application ${newApp.application_number} drafted successfully!`);
      onOpenChange(false);
      onSuccess(newApp.id);
      setStep(1);
    } catch (err: any) {
      toast.error(err.message || 'Failed to create application');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl bg-card border-border">
        <DialogHeader className="border-b border-border pb-3">
          <DialogTitle className="text-lg font-bold flex items-center justify-between">
            <span>New Loan Application Origination</span>
            <span className="text-xs font-normal text-muted-foreground">Step {step} of 3</span>
          </DialogTitle>
        </DialogHeader>

        {/* Multi-Step Wizard Body */}
        <div className="space-y-4 pt-2 text-xs">
          {step === 1 && (
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label>1. Select Applicant *</Label>
                <Select value={applicantId} onValueChange={setApplicantId}>
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="Select borrower" />
                  </SelectTrigger>
                  <SelectContent className="max-h-56">
                    {applicants.map((a) => (
                      <SelectItem key={a.id} value={a.id}>
                        {a.first_name} {a.last_name} ({a.national_id}) - Score: {a.credit_score}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedApplicant && (
                <div className="p-3 rounded-lg bg-muted/40 border border-border space-y-1">
                  <div className="flex justify-between font-semibold text-foreground">
                    <span>{selectedApplicant.first_name} {selectedApplicant.last_name}</span>
                    <Badge variant="outline">{selectedApplicant.risk_band} RISK</Badge>
                  </div>
                  <p className="text-muted-foreground">
                    Email: {selectedApplicant.email} • City: {selectedApplicant.city}
                  </p>
                  <p className="text-muted-foreground">
                    Verified Income: ${mIncome.toLocaleString()} / mo • Active Debt: ${mDebt.toLocaleString()} / mo
                  </p>
                </div>
              )}

              <div className="space-y-1.5 pt-2">
                <Label>2. Select Loan Product *</Label>
                <Select value={productId} onValueChange={setProductId}>
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="Select product" />
                  </SelectTrigger>
                  <SelectContent>
                    {products.map((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.name} ({p.annual_interest_rate}% APR)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedProduct && (
                <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-900 dark:text-blue-200 space-y-1">
                  <p className="font-semibold">{selectedProduct.name}</p>
                  <p className="text-[11px] opacity-80">{selectedProduct.description}</p>
                  <p className="text-[11px]">
                    Limits: ${selectedProduct.min_principal.toLocaleString()} - ${selectedProduct.max_principal.toLocaleString()} •
                    Tenure: {selectedProduct.min_tenure_months}-{selectedProduct.max_tenure_months} months
                  </p>
                </div>
              )}
            </div>
          )}

          {step === 2 && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Requested Principal ($) *</Label>
                  <Input
                    type="number"
                    min={selectedProduct?.min_principal || 1000}
                    max={selectedProduct?.max_principal || 1000000}
                    value={principal}
                    onChange={(e) => setPrincipal(Number(e.target.value))}
                    className="h-9"
                  />
                  <span className="text-[10px] text-muted-foreground block">
                    Product Range: ${selectedProduct?.min_principal.toLocaleString()} - ${selectedProduct?.max_principal.toLocaleString()}
                  </span>
                </div>

                <div className="space-y-1.5">
                  <Label>Requested Tenure (Months) *</Label>
                  <Input
                    type="number"
                    min={selectedProduct?.min_tenure_months || 6}
                    max={selectedProduct?.max_tenure_months || 360}
                    value={tenure}
                    onChange={(e) => setTenure(Number(e.target.value))}
                    className="h-9"
                  />
                  <span className="text-[10px] text-muted-foreground block">
                    Product Range: {selectedProduct?.min_tenure_months} - {selectedProduct?.max_tenure_months} months
                  </span>
                </div>
              </div>

              <div className="space-y-1.5">
                <Label>Loan Purpose</Label>
                <Select value={purpose} onValueChange={setPurpose}>
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="Select purpose" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Debt Consolidation">Debt Consolidation</SelectItem>
                    <SelectItem value="Home Improvement">Home Improvement</SelectItem>
                    <SelectItem value="Vehicle Purchase">Vehicle Purchase</SelectItem>
                    <SelectItem value="Business Expansion">Business Working Capital</SelectItem>
                    <SelectItem value="Medical Expenses">Medical Expenses</SelectItem>
                    <SelectItem value="Major Purchase">Major Purchase</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Affordability Preview Strip */}
              <div className="p-3 rounded-lg bg-muted/40 border border-border space-y-2 mt-2">
                <div className="flex items-center gap-1.5 font-semibold text-foreground">
                  <Calculator className="w-4 h-4 text-primary" />
                  Real-Time Affordability Engine Preview
                </div>
                <div className="grid grid-cols-3 gap-2 text-[11px]">
                  <div>
                    <span className="text-muted-foreground block">Proposed EMI</span>
                    <span className="font-bold text-foreground text-sm">${affordPreview.proposed_emi.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground block">Resulting DTI</span>
                    <span className={`font-bold text-sm ${affordPreview.dti_ratio > (selectedProduct?.max_dti_ratio || 50) ? 'text-destructive' : 'text-emerald-600'}`}>
                      {affordPreview.dti_ratio}%
                    </span>
                  </div>
                  <div>
                    <span className="text-muted-foreground block">Disposable Income</span>
                    <span className={`font-bold text-sm ${affordPreview.disposable_income < 0 ? 'text-destructive' : 'text-foreground'}`}>
                      ${affordPreview.disposable_income.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-950 dark:text-emerald-200">
                <p className="font-bold text-sm">Application Summary Ready for Origination</p>
                <p className="text-[11px] mt-0.5 opacity-90">
                  Review the parameters below before generating the official origination record.
                </p>
              </div>

              <div className="space-y-2 p-3 rounded-lg border border-border bg-muted/20 text-xs">
                <div className="flex justify-between py-1 border-b border-border">
                  <span className="text-muted-foreground">Borrower</span>
                  <span className="font-bold text-foreground">{selectedApplicant?.first_name} {selectedApplicant?.last_name}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-border">
                  <span className="text-muted-foreground">Product</span>
                  <span className="font-bold text-foreground">{selectedProduct?.name}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-border">
                  <span className="text-muted-foreground">Principal & Tenure</span>
                  <span className="font-bold text-foreground">${principal.toLocaleString()} over {tenure} months</span>
                </div>
                <div className="flex justify-between py-1 border-b border-border">
                  <span className="text-muted-foreground">Annual Interest Rate</span>
                  <span className="font-bold text-foreground">{selectedProduct?.annual_interest_rate}% APR</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-muted-foreground">Projected Installment</span>
                  <span className="font-bold text-primary">${affordPreview.proposed_emi.toLocaleString()} / month</span>
                </div>
              </div>

              <div className="p-2.5 rounded bg-muted/30 border border-border text-[11px] text-muted-foreground flex items-center gap-2">
                <FileText className="w-4 h-4 text-blue-500 shrink-0" />
                <span>Standard verification document slots (Identity, Income, Bank Statements) will be attached automatically upon creation.</span>
              </div>
            </div>
          )}

          {/* Wizard Action Footer */}
          <div className="flex items-center justify-between pt-3 border-t border-border">
            <Button
              type="button"
              variant="outline"
              disabled={step === 1}
              onClick={() => setStep(s => s - 1)}
              className="text-xs"
            >
              Back
            </Button>

            <div className="flex gap-2">
              <Button
                type="button"
                variant="ghost"
                onClick={() => onOpenChange(false)}
                className="text-xs"
              >
                Cancel
              </Button>
              {step < 3 ? (
                <Button
                  type="button"
                  onClick={() => setStep(s => s + 1)}
                  className="bg-primary text-primary-foreground hover:bg-primary/90 text-xs font-semibold gap-1"
                >
                  Continue <ChevronRight className="w-3.5 h-3.5" />
                </Button>
              ) : (
                <Button
                  type="button"
                  onClick={handleSubmit}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold"
                >
                  Confirm & Create Application
                </Button>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
