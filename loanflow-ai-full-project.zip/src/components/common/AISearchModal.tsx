import React, { useState } from 'react';
import {
  Search,
  Sparkles,
  ExternalLink,
  Loader2,
  X,
  FileText,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

interface AISearchModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialQuery?: string;
}

interface SearchSource {
  title: string;
  uri: string;
}

const PRESET_TOPICS = [
  'Current mortgage interest rate benchmarks in 2026',
  'CFPB compliance requirements for debt-to-income limits',
  'Automated underwriting guidelines for reducing-balance EMI',
  'Best practices for verifying self-employed borrower income'
];

export const AISearchModal: React.FC<AISearchModalProps> = ({
  open,
  onOpenChange,
  initialQuery = ''
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [isLoading, setIsLoading] = useState(false);
  const [answer, setAnswer] = useState<string | null>(null);
  const [sources, setSources] = useState<SearchSource[]>([]);

  const handleSearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) return;
    setIsLoading(true);
    setAnswer(null);
    setSources([]);

    // Simulated grounded AI synthesis for loan origination knowledge
    setTimeout(() => {
      let simulatedAnswer = '';
      let simulatedSources: SearchSource[] = [];

      const q = searchQuery.toLowerCase();
      if (q.includes('dti') || q.includes('debt-to-income') || q.includes('limit')) {
        simulatedAnswer = `### Debt-to-Income (DTI) Regulatory & Industry Standards (2026)

Under conventional loan underwriting and Qualified Mortgage (QM) guidelines:
1. **Standard Maximum DTI**: The standard conforming threshold typically caps total debt-to-income at **43% to 45%** for conventional paper, with exceptions up to **50%** permitted when supported by compensating factors (such as high credit score >720 or 6+ months liquid cash reserves).
2. **Reducing-Balance Calculation**: DTI is deterministically computed as:
   $$\\text{DTI} = \\frac{\\text{Existing Monthly Debt Commitments} + \\text{Proposed Loan Installment (EMI)}}{\\text{Gross Verified Monthly Income}} \\times 100$$
3. **High-Risk Threshold**: Any ratio exceeding **50.0%** triggers an automatic policy rejection or formal exception review under fair lending standards.`;
        simulatedSources = [
          { title: 'Consumer Financial Protection Bureau (CFPB) - Qualified Mortgage Standards', uri: 'https://www.consumerfinance.gov/rules-policy/regulations/1026/43/' },
          { title: 'Fannie Mae Single-Family Selling Guide - Debt-to-Income Ratios', uri: 'https://selling-guide.fanniemae.com/sel/b3-6-02/debt-income-ratios' }
        ];
      } else if (q.includes('emi') || q.includes('formula') || q.includes('reducing')) {
        simulatedAnswer = `### Reducing-Balance Equal Monthly Installment (EMI) Formula

The standardized mathematical model for amortization requires calculating monthly interest on the decreasing principal balance:

$$\\text{EMI} = P \\times r \\times \\frac{(1+r)^n}{(1+r)^n - 1}$$

- **P**: Principal loan amount disbursed
- **r**: Periodic monthly interest rate ($\\text{Annual APR} / 12 / 100$)
- **n**: Total tenure in months

**Key Accounting Invariants:**
- Every installment splits into principal reduction and interest accrued.
- In early months, interest represents the majority of the payment.
- The final installment must incorporate a penny-reconciliation adjustment ensuring remaining balance equals exactly **$0.00**.`;
        simulatedSources = [
          { title: 'Investopedia - Amortization Schedule & Reducing Balance Formula', uri: 'https://www.investopedia.com/terms/a/amortization_schedule.asp' },
          { title: 'Bank for International Settlements (BIS) - Credit Risk Measurement', uri: 'https://www.bis.org/bcbs/publ/d424.htm' }
        ];
      } else {
        simulatedAnswer = `### FinTech Loan Origination & Decisioning Overview for "${searchQuery}"

In modern automated loan origination platforms:
- **Deterministic Rules vs. Black-Box ML**: Regulated credit decisions must maintain explainability under the Equal Credit Opportunity Act (ECOA) and FCRA. Automated decisions must issue deterministic Adverse Action reason codes when rejected.
- **Verification Integrity**: Four-eye review is required for documents flagged as high-risk or when stated income differs from third-party automated bank statement pulls.
- **Audit Logging**: Every status transition from DRAFT to DISBURSED must be recorded in an append-only audit trail preserving actors, timestamps, and input snapshots.`;
        simulatedSources = [
          { title: 'Federal Reserve - Consumer Compliance Handbook on ECOA', uri: 'https://www.federalreserve.gov/boarddocs/supmanual/cch/fairlend.pdf' },
          { title: 'FinTech Underwriting Architecture & Policy Guide', uri: 'https://www.occ.gov/topics/supervision-and-examination/credit/retail-credit/index-retail-credit.html' }
        ];
      }

      setAnswer(simulatedAnswer);
      setSources(simulatedSources);
      setIsLoading(false);
    }, 700);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl bg-card border-border">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl font-bold">
            <Sparkles className="w-5 h-5 text-primary animate-pulse" />
            AI Underwriting & Regulatory Search
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 pt-2">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch(query)}
                placeholder="Ask about credit guidelines, DTI limits, EMI formula, regulations..."
                className="pl-9"
              />
            </div>
            <Button
              onClick={() => handleSearch(query)}
              disabled={isLoading || !query.trim()}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Search'}
            </Button>
          </div>

          {!answer && !isLoading && (
            <div className="space-y-2 pt-2">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Suggested Search Prompts:
              </p>
              <div className="flex flex-wrap gap-2">
                {PRESET_TOPICS.map((topic, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setQuery(topic);
                      handleSearch(topic);
                    }}
                    className="text-xs bg-muted hover:bg-muted/80 text-foreground px-3 py-1.5 rounded-full border border-border text-left transition-colors"
                  >
                    {topic}
                  </button>
                ))}
              </div>
            </div>
          )}

          {isLoading && (
            <div className="py-12 flex flex-col items-center justify-center space-y-3">
              <Loader2 className="w-8 h-8 text-primary animate-spin" />
              <p className="text-sm text-muted-foreground">Searching underwriting rules & regulations...</p>
            </div>
          )}

          {answer && (
            <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
              <div className="p-4 rounded-lg bg-muted/40 border border-border text-sm leading-relaxed whitespace-pre-wrap">
                {answer}
              </div>

              {sources.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                    Cited Sources & Grounded References:
                  </div>
                  <div className="space-y-1.5">
                    {sources.map((src, i) => (
                      <a
                        key={i}
                        href={src.uri}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center justify-between p-2 rounded bg-muted/30 hover:bg-muted/70 border border-border text-xs text-primary group transition-colors"
                      >
                        <span className="font-medium truncate mr-2">{src.title}</span>
                        <ExternalLink className="w-3.5 h-3.5 shrink-0 opacity-70 group-hover:opacity-100" />
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
