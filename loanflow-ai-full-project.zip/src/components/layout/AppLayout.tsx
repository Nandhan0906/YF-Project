import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  FileSpreadsheet,
  PackageCheck,
  Calculator,
  Scale,
  FileCheck2,
  CalendarDays,
  AlertTriangle,
  History,
  BarChart3,
  Settings,
  Search,
  Bell,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Menu,
  Shield,
  PlusCircle,
  Clock,
  Layers
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger
} from '@/components/ui/sheet';
import { AISearchModal } from '@/components/common/AISearchModal';
import { dbStore } from '@/services/dbStore';

interface AppLayoutProps {
  children: React.ReactNode;
  onOpenNewApplication?: () => void;
  onOpenNewApplicant?: () => void;
}

const NAV_ITEMS = [
  { name: 'Dashboard', path: '/', icon: LayoutDashboard },
  { name: 'Applicants', path: '/applicants', icon: Users },
  { name: 'Loan Applications', path: '/applications', icon: FileSpreadsheet },
  { name: 'Loan Products', path: '/products', icon: PackageCheck },
  { name: 'Affordability Analysis', path: '/affordability', icon: Calculator },
  { name: 'Loan Decisions', path: '/decisions', icon: Scale },
  { name: 'Document Verification', path: '/documents', icon: FileCheck2 },
  { name: 'Repayment Schedules', path: '/repayments', icon: CalendarDays },
  { name: 'Exception Management', path: '/exceptions', icon: AlertTriangle },
  { name: 'Audit Logs', path: '/audit-logs', icon: History },
  { name: 'Reports & Analytics', path: '/reports', icon: BarChart3 },
  { name: 'Settings & System Seed', path: '/settings', icon: Settings }
];

export const AppLayout: React.FC<AppLayoutProps> = ({
  children,
  onOpenNewApplication,
  onOpenNewApplicant
}) => {
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [aiSearchOpen, setAiSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const summary = dbStore.getDashboardSummary();
  const currentDate = 'Oct 30, 2026';

  const handleGlobalSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setAiSearchOpen(true);
    }
  };

  return (
    <div className="flex min-h-screen w-full bg-background text-foreground">
      {/* DESKTOP SIDEBAR (>= md) */}
      <aside
        className={`hidden md:flex flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border transition-all duration-300 shrink-0 ${
          collapsed ? 'w-20' : 'w-64'
        }`}
      >
        {/* Brand Header */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-sidebar-border">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shrink-0 shadow-md">
              <Shield className="w-5 h-5 text-white" />
            </div>
            {!collapsed && (
              <div className="min-w-0">
                <span className="font-bold text-lg tracking-tight text-white block truncate">
                  LoanFlow <span className="text-blue-400 font-extrabold">AI</span>
                </span>
                <span className="text-[10px] text-slate-400 block -mt-1 font-mono uppercase tracking-wider">
                  Origination Platform
                </span>
              </div>
            )}
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCollapsed(!collapsed)}
            className="text-slate-400 hover:text-white hover:bg-sidebar-accent w-8 h-8 shrink-0"
            title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </Button>
        </div>

        {/* Navigation Links */}
        <div className="flex-1 overflow-y-auto py-4 px-2 space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-all group ${
                  active
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-sidebar-accent'
                }`}
                title={collapsed ? item.name : undefined}
              >
                <Icon className={`w-5 h-5 shrink-0 ${active ? 'text-white' : 'text-slate-400 group-hover:text-blue-400'}`} />
                {!collapsed && (
                  <span className="truncate flex-1">{item.name}</span>
                )}
                {!collapsed && item.name === 'Exception Management' && summary.open_exceptions_count > 0 && (
                  <Badge variant="destructive" className="ml-auto text-[10px] px-1.5 py-0 h-4">
                    {summary.open_exceptions_count}
                  </Badge>
                )}
                {!collapsed && item.name === 'Document Verification' && summary.pending_document_verifications > 0 && (
                  <Badge variant="secondary" className="ml-auto text-[10px] px-1.5 py-0 h-4 bg-amber-500/20 text-amber-300 border-none">
                    {summary.pending_document_verifications}
                  </Badge>
                )}
              </Link>
            );
          })}
        </div>

        {/* Sidebar Footer */}
        <div className="p-3 border-t border-sidebar-border text-xs text-slate-400">
          {!collapsed ? (
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-slate-200">System v2.1.0</p>
                <p className="text-[11px] text-slate-400">Deterministic Engine</p>
              </div>
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" title="Engine Online" />
            </div>
          ) : (
            <div className="flex justify-center">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" title="Online" />
            </div>
          )}
        </div>
      </aside>

      {/* MOBILE SHEET DRAWER (< md) */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="w-72 bg-sidebar text-sidebar-foreground p-0 border-sidebar-border">
          <SheetHeader className="p-4 border-b border-sidebar-border flex flex-row items-center justify-between space-y-0">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
                <Shield className="w-4 h-4 text-white" />
              </div>
              <SheetTitle className="text-white text-base font-bold">LoanFlow AI</SheetTitle>
            </div>
          </SheetHeader>
          <div className="py-4 px-2 space-y-1 overflow-y-auto max-h-[calc(100vh-80px)]">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const active = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileOpen(false)}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
                    active
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-300 hover:text-white hover:bg-sidebar-accent'
                  }`}
                >
                  <Icon className="w-5 h-5 shrink-0" />
                  <span className="truncate">{item.name}</span>
                </Link>
              );
            })}
          </div>
        </SheetContent>
      </Sheet>

      {/* MAIN CONTENT AREA */}
      <div className="flex-1 min-w-0 flex flex-col overflow-x-hidden">
        {/* TOP NAVIGATION BAR */}
        <header className="h-16 bg-card border-b border-border px-4 md:px-6 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-3 flex-1 min-w-0 mr-4">
            {/* Mobile Hamburger Menu */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-foreground hover:bg-muted"
              onClick={() => setMobileOpen(true)}
            >
              <Menu className="w-5 h-5" />
            </Button>

            {/* Global Search Bar */}
            <form onSubmit={handleGlobalSearchSubmit} className="relative flex-1 max-w-md hidden sm:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Global search applicants, loans, or regulations..."
                className="pl-9 pr-20 h-9 bg-muted/50 border-border text-sm focus-visible:ring-1"
              />
              <Button
                type="button"
                size="sm"
                variant="ghost"
                onClick={() => setAiSearchOpen(true)}
                className="absolute right-1 top-1/2 -translate-y-1/2 h-7 px-2 text-xs font-semibold text-primary hover:bg-primary/10 flex items-center gap-1"
              >
                <Sparkles className="w-3.5 h-3.5 text-primary" />
                AI Ask
              </Button>
            </form>
          </div>

          {/* Right Action Icons & Profile */}
          <div className="flex items-center gap-2 md:gap-3 shrink-0">
            {/* Date Display */}
            <div className="hidden lg:flex items-center gap-1.5 text-xs text-muted-foreground bg-muted/60 px-2.5 py-1.5 rounded-md border border-border">
              <Clock className="w-3.5 h-3.5" />
              <span>{currentDate}</span>
            </div>

            {/* AI Search Launch Button */}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setAiSearchOpen(true)}
              className="gap-1.5 border-primary/40 text-primary hover:bg-primary/5 text-xs font-semibold h-8"
            >
              <Sparkles className="w-3.5 h-3.5 text-primary" />
              <span className="hidden sm:inline">AI Underwriting Guide</span>
            </Button>

            {/* Notifications Popover */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative h-8 w-8 text-foreground hover:bg-muted">
                  <Bell className="w-4 h-4" />
                  {summary.open_exceptions_count > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-destructive" />
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80 p-2">
                <DropdownMenuLabel className="font-semibold text-xs text-muted-foreground uppercase">
                  Active Alerts & Exceptions
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <div className="space-y-2 py-1 text-xs">
                  <div className="p-2 rounded bg-amber-500/10 border border-amber-500/20 text-amber-900 dark:text-amber-200">
                    <p className="font-semibold">Pending Document Reviews ({summary.pending_document_verifications})</p>
                    <p className="text-[11px] opacity-80">Borrower submissions awaiting underwriter sign-off.</p>
                  </div>
                  <div className="p-2 rounded bg-destructive/10 border border-destructive/20 text-destructive">
                    <p className="font-semibold">Open Policy Exceptions ({summary.open_exceptions_count})</p>
                    <p className="text-[11px] opacity-80">Critical data inconsistencies or duplicate submissions.</p>
                  </div>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Quick Action Button */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 h-8 gap-1.5 text-xs font-semibold">
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>Action</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={onOpenNewApplication} className="cursor-pointer">
                  <FileSpreadsheet className="w-4 h-4 mr-2 text-blue-500" />
                  New Loan Application
                </DropdownMenuItem>
                <DropdownMenuItem onClick={onOpenNewApplicant} className="cursor-pointer">
                  <Users className="w-4 h-4 mr-2 text-emerald-500" />
                  Register New Applicant
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link to="/affordability" className="cursor-pointer flex items-center">
                    <Calculator className="w-4 h-4 mr-2 text-indigo-500" />
                    Affordability Calculator
                  </Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* User Session Profile Badge */}
            <div className="flex items-center gap-2 pl-2 border-l border-border">
              <div className="w-8 h-8 rounded-full bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 flex items-center justify-center font-bold text-xs shadow-sm">
                SO
              </div>
              <div className="hidden xl:block text-left text-xs leading-tight">
                <p className="font-semibold text-foreground">Sarah Owens</p>
                <p className="text-[10px] text-muted-foreground">Sr. Credit Officer</p>
              </div>
            </div>
          </div>
        </header>

        {/* PAGE CONTENT CONTAINER */}
        <main className="flex-1 p-4 md:p-6 lg:p-8 max-w-7xl w-full mx-auto space-y-6">
          {children}
        </main>
      </div>

      {/* Global AI Search Dialog */}
      <AISearchModal
        open={aiSearchOpen}
        onOpenChange={setAiSearchOpen}
        initialQuery={searchQuery}
      />
    </div>
  );
};
