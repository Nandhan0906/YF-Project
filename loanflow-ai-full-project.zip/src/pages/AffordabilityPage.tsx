import React, { useState } from 'react';
import {
  Calculator,
  Percent,
  DollarSign,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  FileText,
  RotateCcw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { calculateAffordability, calculateReducingBalanceEmi } from '@/services/dbStore';

export const AffordabilityPage: React.FC = () => {
  const [monthlyIncome, setMonthlyIncome] = useState<number>(6500);
  const [existingDebt, setExistingDebt] = useState<number>(1200);
  const [principal, setPrincipal] = useState<number>(25000);
  const [annualRate, setAnnualRate] = useState<number>(7.5);
  const [tenureMonths, setTenureMonths] = useState<number>(36);
  const [maxDti, setMaxDti] = useState<number>(45.0);

  const result = calculateAffordability(
    monthlyIncome,
    existingDebt,
    principal,
    annualRate,
    tenureMonths,
    maxDti
  );

  const isDtiExceeded = result.dti_ratio > maxDti;
  const isNegativeDisposable = result.disposable_income < 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
          <Calculator className="w-6 h-6 text-primary" />
          Affordability Calculation Engine
        </h1>
        <p className="text-xs text-muted-foreground mt-1">
          Deterministic reducing-balance EMI simulation, debt-to-income (DTI) analysis, and disposable income stress testing.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Input Form Parameters (1 Col) */}
        <div className="p-5 rounded-xl bg-card border border-border shadow-sm space-y-4">
          <h3 className="font-bold text-sm text-foreground flex items-center justify-between">
            <span>Borrower Financial Inputs</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setMonthlyIncome(6500);
                setExistingDebt(1200);
                setPrincipal(25000);
                setAnnualRate(7.5);
                setTenureMonths(36);
                setMaxDti(45.0);
              }}
              className="h-6 text-[11px] text-muted-foreground"
            >
              <RotateCcw className="w-3 h-3 mr-1" /> Reset
            </Button>
          </h3>

          <div className="space-y-3 text-xs">
            <div className="space-y-1">
              <Label>Verified Net Monthly Income ($)</Label>
              <Input
                type="number"
                value={monthlyIncome}
                onChange={(e) => setMonthlyIncome(Number(e.target.value))}
                className="h-8"
              />
            </div>

            <div className="space-y-1">
              <Label>Existing Monthly Debt Commitments ($)</Label>
              <Input
                type="number"
                value={existingDebt}
                onChange={(e) => setExistingDebt(Number(e.target.value))}
                className="h-8"
              />
            </div>

            <div className="space-y-1">
              <Label>Proposed Loan Principal ($)</Label>
              <Input
                type="number"
                value={principal}
                onChange={(e) => setPrincipal(Number(e.target.value))}
                className="h-8"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <Label>Annual APR (%)</Label>
                <Input
                  type="number"
                  step="0.1"
                  value={annualRate}
                  onChange={(e) => setAnnualRate(Number(e.target.value))}
                  className="h-8"
                />
              </div>

              <div className="space-y-1">
                <Label>Tenure (Months)</Label>
                <Input
                  type="number"
                  value={tenureMonths}
                  onChange={(e) => setTenureMonths(Number(e.target.value))}
                  className="h-8"
                />
              </div>
            </div>

            <div className="space-y-1">
              <Label>Maximum Permitted DTI Threshold (%)</Label>
              <Input
                type="number"
                value={maxDti}
                onChange={(e) => setMaxDti(Number(e.target.value))}
                className="h-8"
              />
            </div>
          </div>
        </div>

        {/* Right: Output Telemetry & Invariants (2 Cols) */}
        <div className="lg:col-span-2 space-y-5">
          {/* 4 Main Output Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 rounded-xl bg-card border border-border shadow-sm">
              <span className="text-[11px] text-muted-foreground block">Proposed Monthly EMI</span>
              <span className="text-2xl font-bold text-primary mt-1 block">
                ${result.proposed_emi.toLocaleString()}
              </span>
              <span className="text-[10px] text-muted-foreground block mt-0.5">Reducing balance</span>
            </div>

            <div className="p-4 rounded-xl bg-card border border-border shadow-sm">
              <span className="text-[11px] text-muted-foreground block">Calculated DTI Ratio</span>
              <span className={`text-2xl font-bold mt-1 block ${isDtiExceeded ? 'text-destructive' : 'text-emerald-600'}`}>
                {result.dti_ratio}%
              </span>
              <span className="text-[10px] text-muted-foreground block mt-0.5">
                Cap: {maxDti}%
              </span>
            </div>

            <div className="p-4 rounded-xl bg-card border border-border shadow-sm">
              <span className="text-[11px] text-muted-foreground block">Net Disposable Income</span>
              <span className={`text-2xl font-bold mt-1 block ${isNegativeDisposable ? 'text-destructive' : 'text-foreground'}`}>
                ${result.disposable_income.toLocaleString()}
              </span>
              <span className="text-[10px] text-muted-foreground block mt-0.5">Post-debt liquidity</span>
            </div>

            <div className="p-4 rounded-xl bg-card border border-border shadow-sm">
              <span className="text-[11px] text-muted-foreground block">Max Affordable Loan</span>
              <span className="text-2xl font-bold text-indigo-600 dark:text-indigo-400 mt-1 block">
                ${result.max_affordable_principal.toLocaleString()}
              </span>
              <span className="text-[10px] text-muted-foreground block mt-0.5">At {maxDti}% DTI ceiling</span>
            </div>
          </div>

          {/* Policy Compliance Assessment */}
          <div className="p-5 rounded-xl bg-card border border-border shadow-sm space-y-3">
            <h3 className="font-bold text-sm text-foreground">Underwriting Affordability Assessment</h3>
            {isDtiExceeded || isNegativeDisposable ? (
              <div className="p-3.5 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-950 dark:text-rose-200 text-xs flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">Affordability Stress Failure Triggered</p>
                  <p className="mt-0.5 leading-relaxed">
                    {isDtiExceeded && `Resulting DTI ratio of ${result.dti_ratio}% exceeds the product regulatory maximum of ${maxDti}%. `}
                    {isNegativeDisposable && `Borrower suffers from negative net disposable income ($${result.disposable_income}).`}
                  </p>
                </div>
              </div>
            ) : (
              <div className="p-3.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-950 dark:text-emerald-200 text-xs flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold">Affordability Criteria Strictly Satisfied</p>
                  <p className="mt-0.5 leading-relaxed">
                    DTI of {result.dti_ratio}% is within the allowed {maxDti}% ceiling with adequate disposable buffer of ${result.disposable_income.toLocaleString()} per month.
                  </p>
                </div>
              </div>
            )}

            {/* Formula Breakdown Panel */}
            <div className="p-4 rounded-lg bg-muted/40 border border-border text-xs space-y-2">
              <span className="font-semibold text-foreground block">Mathematical Amortization Trace:</span>
              <p className="font-mono text-muted-foreground leading-relaxed whitespace-pre-wrap">
                {result.notes}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
