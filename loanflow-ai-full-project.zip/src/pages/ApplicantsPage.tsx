import React, { useState } from 'react';
import {
  Users,
  Search,
  Plus,
  Filter,
  ShieldCheck,
  ChevronRight,
  FileSpreadsheet,
  ArrowUpDown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { dbStore } from '@/services/dbStore';
import { Applicant } from '@/types/loanflow';
import { ApplicantDetailModal } from '@/components/applicants/ApplicantDetailModal';
import { NewApplicantModal } from '@/components/applicants/NewApplicantModal';

interface ApplicantsPageProps {
  onOpenNewApplication?: (applicantId?: string) => void;
}

export const ApplicantsPage: React.FC<ApplicantsPageProps> = ({ onOpenNewApplication }) => {
  const [search, setSearch] = useState('');
  const [riskFilter, setRiskFilter] = useState('all');
  const [selectedApplicantId, setSelectedApplicantId] = useState<string | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [newApplicantOpen, setNewApplicantOpen] = useState(false);
  const [page, setPage] = useState(1);
  const itemsPerPage = 12;

  const applicants = Array.from(dbStore.applicants.values());

  const filtered = applicants.filter(app => {
    const matchesSearch =
      search === '' ||
      `${app.first_name} ${app.last_name}`.toLowerCase().includes(search.toLowerCase()) ||
      app.national_id.toLowerCase().includes(search.toLowerCase()) ||
      app.email.toLowerCase().includes(search.toLowerCase()) ||
      app.city.toLowerCase().includes(search.toLowerCase());

    const matchesRisk = riskFilter === 'all' || app.risk_band === riskFilter;

    return matchesSearch && matchesRisk;
  });

  const totalPages = Math.max(1, Math.ceil(filtered.length / itemsPerPage));
  const paginated = filtered.slice((page - 1) * itemsPerPage, page * itemsPerPage);

  const getRiskBadge = (band: string) => {
    switch (band) {
      case 'LOW':
        return <Badge className="bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border-none">Prime (Low)</Badge>;
      case 'MEDIUM':
        return <Badge className="bg-blue-500/20 text-blue-700 dark:text-blue-400 border-none">Near-Prime</Badge>;
      case 'HIGH':
        return <Badge className="bg-amber-500/20 text-amber-700 dark:text-amber-400 border-none">Subprime</Badge>;
      default:
        return <Badge variant="destructive">Deep Subprime</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <Users className="w-6 h-6 text-primary" />
            Applicant Profiles Management
          </h1>
          <p className="text-xs text-muted-foreground mt-1">
            Browse, search, register, and inspect loan applicant credit profiles and financial histories.
          </p>
        </div>
        <Button
          onClick={() => setNewApplicantOpen(true)}
          className="bg-primary text-primary-foreground hover:bg-primary/90 h-9 gap-1.5 text-xs font-semibold"
        >
          <Plus className="w-4 h-4" />
          Register New Applicant
        </Button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-xl bg-card border border-border shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            placeholder="Search by name, National ID, email, city..."
            className="pl-9 h-9 text-xs"
          />
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <Select
            value={riskFilter}
            onValueChange={(val) => {
              setRiskFilter(val);
              setPage(1);
            }}
          >
            <SelectTrigger className="h-9 w-44 text-xs">
              <SelectValue placeholder="Filter by Risk Band" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Risk Bands</SelectItem>
              <SelectItem value="LOW">Low Risk (Prime)</SelectItem>
              <SelectItem value="MEDIUM">Medium Risk</SelectItem>
              <SelectItem value="HIGH">High Risk</SelectItem>
              <SelectItem value="VERY_HIGH">Very High Risk</SelectItem>
            </SelectContent>
          </Select>

          <span className="text-xs text-muted-foreground whitespace-nowrap">
            Showing {filtered.length} of {applicants.length}
          </span>
        </div>
      </div>

      {/* Applicants Table */}
      <div className="rounded-xl bg-card border border-border shadow-sm overflow-hidden">
        <div className="overflow-x-auto w-full">
          <table className="w-full text-left text-xs whitespace-nowrap">
            <thead className="bg-muted/40 border-b border-border text-muted-foreground">
              <tr>
                <th className="py-3 px-4 font-semibold">Applicant Name</th>
                <th className="py-3 px-4 font-semibold">National ID</th>
                <th className="py-3 px-4 font-semibold">Credit Score</th>
                <th className="py-3 px-4 font-semibold">Risk Band</th>
                <th className="py-3 px-4 font-semibold">City</th>
                <th className="py-3 px-4 font-semibold">Contact</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {paginated.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-muted-foreground">
                    No applicants found matching filter criteria.
                  </td>
                </tr>
              ) : (
                paginated.map((app) => (
                  <tr
                    key={app.id}
                    onClick={() => {
                      setSelectedApplicantId(app.id);
                      setDetailOpen(true);
                    }}
                    className="hover:bg-muted/40 cursor-pointer transition-colors"
                  >
                    <td className="py-3.5 px-4 font-medium text-foreground">
                      {app.first_name} {app.last_name}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-muted-foreground">{app.national_id}</td>
                    <td className="py-3.5 px-4 font-bold text-foreground">{app.credit_score}</td>
                    <td className="py-3.5 px-4">{getRiskBadge(app.risk_band)}</td>
                    <td className="py-3.5 px-4 text-muted-foreground">{app.city}</td>
                    <td className="py-3.5 px-4 text-muted-foreground">{app.email}</td>
                    <td className="py-3.5 px-4 text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedApplicantId(app.id);
                          setDetailOpen(true);
                        }}
                        className="h-7 px-2.5 text-xs text-primary hover:bg-primary/10"
                      >
                        Inspect Profile <ChevronRight className="w-3.5 h-3.5 ml-1" />
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div className="p-3 border-t border-border flex items-center justify-between text-xs text-muted-foreground">
          <span>
            Page {page} of {totalPages}
          </span>
          <div className="flex gap-1.5">
            <Button
              variant="outline"
              size="sm"
              disabled={page <= 1}
              onClick={() => setPage(p => p - 1)}
              className="h-7 text-xs"
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={page >= totalPages}
              onClick={() => setPage(p => p + 1)}
              className="h-7 text-xs"
            >
              Next
            </Button>
          </div>
        </div>
      </div>

      {/* Applicant Detail Profile Modal */}
      <ApplicantDetailModal
        applicantId={selectedApplicantId}
        open={detailOpen}
        onOpenChange={setDetailOpen}
        onApplyLoan={(id) => {
          if (onOpenNewApplication) {
            onOpenNewApplication(id);
          }
        }}
      />

      {/* Register New Applicant Modal */}
      <NewApplicantModal
        open={newApplicantOpen}
        onOpenChange={setNewApplicantOpen}
        onSuccess={(newId) => {
          setSelectedApplicantId(newId);
          setDetailOpen(true);
        }}
      />
    </div>
  );
};
