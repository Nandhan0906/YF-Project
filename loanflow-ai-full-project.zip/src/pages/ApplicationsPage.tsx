import React, { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  FileSpreadsheet,
  Search,
  Plus,
  Filter,
  ChevronRight,
  Eye,
  SlidersHorizontal,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { dbStore } from '@/services/dbStore';
import { ApplicationStatus } from '@/types/loanflow';
import { ApplicationDetailModal } from '@/components/applications/ApplicationDetailModal';
import { NewApplicationModal } from '@/components/applications/NewApplicationModal';

interface ApplicationsPageProps {
  onOpenNewApplication?: () => void;
}

export const ApplicationsPage: React.FC<ApplicationsPageProps> = () => {
  const [searchParams] = useSearchParams();
  const initialId = searchParams.get('id');

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedAppId, setSelectedAppId] = useState<string | null>(initialId);
  const [detailOpen, setDetailOpen] = useState<boolean>(!!initialId);
  const [newAppOpen, setNewAppOpen] = useState(false);
  const [page, setPage] = useState(1);
  const [refreshKey, setRefreshKey] = useState(0);
  const itemsPerPage = 12;

  const applications = Array.from(dbStore.applications.values());

  const filtered = applications.filter((app) => {
    const applicant = dbStore.applicants.get(app.applicant_id);
    const applicantName = applicant ? `${applicant.first_name} ${applicant.last_name}` : '';
    const nationalId = applicant ? applicant.national_id : '';

    const matchesSearch =
      search === '' ||
      app.application_number.toLowerCase().includes(search.toLowerCase()) ||
      applicantName.toLowerCase().includes(search.toLowerCase()) ||
      nationalId.toLowerCase().includes(search.toLowerCase());

    const matchesStatus = statusFilter === 'all' || app.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const totalPages = Math.max(1, Math.ceil(filtered.length / itemsPerPage));
  const paginated = filtered.slice((page - 1) * itemsPerPage, page * itemsPerPage);

  const getStatusBadge = (status: ApplicationStatus) => {
    switch (status) {
      case 'APPROVED':
      case 'DISBURSED':
        return <Badge className="bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border-none">Approved</Badge>;
      case 'REJECTED':
        return <Badge variant="destructive">Rejected</Badge>;
      case 'MANUAL_REVIEW':
        return <Badge className="bg-amber-500/20 text-amber-700 dark:text-amber-400 border-amber-500/30">Manual Review</Badge>;
      case 'SUBMITTED':
      case 'UNDER_REVIEW':
        return <Badge className="bg-blue-500/20 text-blue-700 dark:text-blue-400 border-none">In Review</Badge>;
      case 'DRAFT':
        return <Badge variant="outline" className="text-slate-500">Draft</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <FileSpreadsheet className="w-6 h-6 text-primary" />
            Loan Applications Pipeline
          </h1>
          <p className="text-xs text-muted-foreground mt-1">
            End-to-end origination lifecycle management across underwriting states.
          </p>
        </div>
        <Button
          onClick={() => setNewAppOpen(true)}
          className="bg-primary text-primary-foreground hover:bg-primary/90 h-9 gap-1.5 text-xs font-semibold"
        >
          <Plus className="w-4 h-4" />
          Originate Application
        </Button>
      </div>

      {/* Filter and Status Strip */}
      <div className="p-4 rounded-xl bg-card border border-border shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            placeholder="Search by app #, borrower name, national ID..."
            className="pl-9 h-9 text-xs"
          />
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <Select
            value={statusFilter}
            onValueChange={(val) => {
              setStatusFilter(val);
              setPage(1);
            }}
          >
            <SelectTrigger className="h-9 w-44 text-xs">
              <SelectValue placeholder="Filter by Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All States</SelectItem>
              <SelectItem value="DRAFT">DRAFT</SelectItem>
              <SelectItem value="SUBMITTED">SUBMITTED</SelectItem>
              <SelectItem value="UNDER_REVIEW">UNDER_REVIEW</SelectItem>
              <SelectItem value="APPROVED">APPROVED</SelectItem>
              <SelectItem value="REJECTED">REJECTED</SelectItem>
              <SelectItem value="MANUAL_REVIEW">MANUAL_REVIEW</SelectItem>
              <SelectItem value="DISBURSED">DISBURSED</SelectItem>
            </SelectContent>
          </Select>

          <span className="text-xs text-muted-foreground whitespace-nowrap">
            Showing {filtered.length} of {applications.length}
          </span>
        </div>
      </div>

      {/* Table */}
      <div className="rounded-xl bg-card border border-border shadow-sm overflow-hidden">
        <div className="overflow-x-auto w-full">
          <table className="w-full text-left text-xs whitespace-nowrap">
            <thead className="bg-muted/40 border-b border-border text-muted-foreground">
              <tr>
                <th className="py-3 px-4 font-semibold">Application #</th>
                <th className="py-3 px-4 font-semibold">Borrower</th>
                <th className="py-3 px-4 font-semibold">Product</th>
                <th className="py-3 px-4 font-semibold">Principal</th>
                <th className="py-3 px-4 font-semibold">Tenure</th>
                <th className="py-3 px-4 font-semibold">Purpose</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {paginated.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-muted-foreground">
                    No loan applications matching search filters.
                  </td>
                </tr>
              ) : (
                paginated.map((app) => {
                  const applicant = dbStore.applicants.get(app.applicant_id);
                  const product = dbStore.products.get(app.product_id);
                  return (
                    <tr
                      key={app.id}
                      onClick={() => {
                        setSelectedAppId(app.id);
                        setDetailOpen(true);
                      }}
                      className="hover:bg-muted/40 cursor-pointer transition-colors"
                    >
                      <td className="py-3.5 px-4 font-mono font-medium text-foreground">
                        {app.application_number}
                      </td>
                      <td className="py-3.5 px-4 font-medium text-foreground">
                        {applicant ? `${applicant.first_name} ${applicant.last_name}` : 'Unknown'}
                      </td>
                      <td className="py-3.5 px-4 text-muted-foreground">{product ? product.name : 'Loan'}</td>
                      <td className="py-3.5 px-4 font-bold text-foreground">
                        ${app.requested_principal.toLocaleString()}
                      </td>
                      <td className="py-3.5 px-4 text-muted-foreground">{app.requested_tenure_months} mo</td>
                      <td className="py-3.5 px-4 text-muted-foreground">{app.purpose || app.loan_purpose || 'Standard'}</td>
                      <td className="py-3.5 px-4">{getStatusBadge(app.status)}</td>
                      <td className="py-3.5 px-4 text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedAppId(app.id);
                            setDetailOpen(true);
                          }}
                          className="h-7 px-2.5 text-xs text-primary hover:bg-primary/10"
                        >
                          Details <ChevronRight className="w-3.5 h-3.5 ml-1" />
                        </Button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="p-3 border-t border-border flex items-center justify-between text-xs text-muted-foreground">
          <span>
            Page {page} of {totalPages}
          </span>
          <div className="flex gap-1.5">
            <Button
              variant="outline"
              size="sm"
              disabled={page <= 1}
              onClick={() => setPage(p => p - 1)}
              className="h-7 text-xs"
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={page >= totalPages}
              onClick={() => setPage(p => p + 1)}
              className="h-7 text-xs"
            >
              Next
            </Button>
          </div>
        </div>
      </div>

      {/* Detail Modal */}
      <ApplicationDetailModal
        applicationId={selectedAppId}
        open={detailOpen}
        onOpenChange={setDetailOpen}
        onRefresh={() => setRefreshKey(k => k + 1)}
      />

      {/* New Application Wizard */}
      <NewApplicationModal
        open={newAppOpen}
        onOpenChange={setNewAppOpen}
        onSuccess={(id) => {
          setSelectedAppId(id);
          setDetailOpen(true);
          setRefreshKey(k => k + 1);
        }}
      />
    </div>
  );
};
