import React, { useState } from 'react';
import {
  History,
  Search,
  Filter,
  Clock,
  ShieldCheck,
  ChevronDown,
  Layers
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { dbStore } from '@/services/dbStore';
import { LoanEvent } from '@/types/loanflow';

export const AuditLogsPage: React.FC = () => {
  const [search, setSearch] = useState('');
  const [entityFilter, setEntityFilter] = useState('all');
  const [eventFilter, setEventFilter] = useState('all');

  const events = dbStore.events;

  const filtered = events.filter((evt) => {
    const matchesSearch =
      search === '' ||
      evt.description.toLowerCase().includes(search.toLowerCase()) ||
      evt.actor.toLowerCase().includes(search.toLowerCase()) ||
      evt.entity_id.toLowerCase().includes(search.toLowerCase());

    const matchesEntity = entityFilter === 'all' || evt.entity_type === entityFilter;
    const matchesEvent = eventFilter === 'all' || evt.event_type === eventFilter;

    return matchesSearch && matchesEntity && matchesEvent;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
          <History className="w-6 h-6 text-primary" />
          Immutable Compliance Audit Trail
        </h1>
        <p className="text-xs text-muted-foreground mt-1">
          Chronological record of every origination lifecycle transition, decision evaluation, underwriter override, and verification.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-xl bg-card border border-border shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by description, actor, entity ID..."
            className="pl-9 h-9 text-xs"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
          <Select value={entityFilter} onValueChange={setEntityFilter}>
            <SelectTrigger className="h-9 w-40 text-xs">
              <SelectValue placeholder="Entity Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Entities</SelectItem>
              <SelectItem value="LoanApplication">Loan Application</SelectItem>
              <SelectItem value="Decision">Decision</SelectItem>
              <SelectItem value="Document">Document</SelectItem>
              <SelectItem value="Applicant">Applicant</SelectItem>
              <SelectItem value="AffordabilityCheck">Affordability Check</SelectItem>
              <SelectItem value="IssueRecord">Issue Record</SelectItem>
            </SelectContent>
          </Select>

          <Select value={eventFilter} onValueChange={setEventFilter}>
            <SelectTrigger className="h-9 w-44 text-xs">
              <SelectValue placeholder="Event Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Event Types</SelectItem>
              <SelectItem value="APPLICATION_CREATED">APPLICATION_CREATED</SelectItem>
              <SelectItem value="STATE_TRANSITION">STATE_TRANSITION</SelectItem>
              <SelectItem value="DECISION_EVALUATED">DECISION_EVALUATED</SelectItem>
              <SelectItem value="UNDERWRITER_OVERRIDE">UNDERWRITER_OVERRIDE</SelectItem>
              <SelectItem value="DOCUMENT_VERIFIED">DOCUMENT_VERIFIED</SelectItem>
              <SelectItem value="ISSUE_LOGGED">ISSUE_LOGGED</SelectItem>
              <SelectItem value="ISSUE_RESOLVED">ISSUE_RESOLVED</SelectItem>
            </SelectContent>
          </Select>

          <span className="text-xs text-muted-foreground whitespace-nowrap">
            Showing {filtered.length} audit logs
          </span>
        </div>
      </div>

      {/* Audit Logs Table */}
      <div className="rounded-xl bg-card border border-border shadow-sm overflow-hidden">
        <div className="overflow-x-auto w-full">
          <table className="w-full text-left text-xs whitespace-nowrap">
            <thead className="bg-muted/40 border-b border-border text-muted-foreground">
              <tr>
                <th className="py-3 px-4 font-semibold">Timestamp</th>
                <th className="py-3 px-4 font-semibold">Event Type</th>
                <th className="py-3 px-4 font-semibold">Entity Type</th>
                <th className="py-3 px-4 font-semibold">Entity ID</th>
                <th className="py-3 px-4 font-semibold">Actor</th>
                <th className="py-3 px-4 font-semibold">Audit Description</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-muted-foreground">
                    No audit records matching filter criteria.
                  </td>
                </tr>
              ) : (
                filtered.map((evt) => (
                  <tr key={evt.id} className="hover:bg-muted/40 transition-colors">
                    <td className="py-3.5 px-4 font-mono text-muted-foreground text-[11px]">
                      {new Date(evt.created_at).toLocaleString()}
                    </td>
                    <td className="py-3.5 px-4">
                      <Badge variant="outline" className="font-mono text-[10px]">
                        {evt.event_type}
                      </Badge>
                    </td>
                    <td className="py-3.5 px-4 text-foreground font-medium">
                      {evt.entity_type}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-[11px] text-muted-foreground">
                      {evt.entity_id}
                    </td>
                    <td className="py-3.5 px-4 text-foreground font-medium">
                      {evt.actor}
                    </td>
                    <td className="py-3.5 px-4 text-muted-foreground max-w-md truncate font-sans">
                      {evt.description}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
