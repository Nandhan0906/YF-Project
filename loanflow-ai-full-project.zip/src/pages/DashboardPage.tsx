import React from 'react';
import { Link } from 'react-router-dom';
import {
  Users,
  FileSpreadsheet,
  CheckCircle2,
  XCircle,
  AlertCircle,
  DollarSign,
  TrendingUp,
  Percent,
  ArrowUpRight,
  ShieldAlert,
  Clock,
  ChevronRight,
  FileText,
  Activity
} from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import { Bar, Doughnut, Line, Pie } from 'react-chartjs-2';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { dbStore } from '@/services/dbStore';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface DashboardPageProps {
  onOpenNewApplication?: () => void;
  onOpenNewApplicant?: () => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  onOpenNewApplication,
  onOpenNewApplicant
}) => {
  const summary = dbStore.getDashboardSummary();
  const applications = Array.from(dbStore.applications.values());
  const applicants = Array.from(dbStore.applicants.values());
  const decisions = Array.from(dbStore.decisions.values());
  const events = dbStore.events.slice(0, 8);
  const issues = Array.from(dbStore.issues.values()).filter(i => i.resolution_status === 'OPEN').slice(0, 5);
  const pendingDocs = Array.from(dbStore.documents.values()).filter(d => d.status === 'PENDING').slice(0, 5);

  // Status Distribution Chart Data
  const statusLabels = Object.keys(summary.status_distribution);
  const statusValues = Object.values(summary.status_distribution);
  const statusChartData = {
    labels: statusLabels,
    datasets: [
      {
        data: statusValues,
        backgroundColor: [
          '#10B981', // APPROVED (emerald)
          '#059669', // DISBURSED (green)
          '#F59E0B', // MANUAL_REVIEW (amber)
          '#EF4444', // REJECTED (rose)
          '#3B82F6', // SUBMITTED (sky)
          '#64748B'  // DRAFT (slate)
        ],
        borderWidth: 2,
        borderColor: '#ffffff'
      }
    ]
  };

  // Product Distribution Chart Data
  const productLabels = Object.keys(summary.product_distribution);
  const productValues = Object.values(summary.product_distribution);
  const productChartData = {
    labels: productLabels.map(l => l.replace('Loan', '').replace('Financing', '').trim()),
    datasets: [
      {
        label: 'Applications',
        data: productValues,
        backgroundColor: '#2563EB',
        borderRadius: 6
      }
    ]
  };

  // Monthly Application Trends (Simulated 6-Month Trajectory)
  const monthlyTrendsData = {
    labels: ['May 2026', 'Jun 2026', 'Jul 2026', 'Aug 2026', 'Sep 2026', 'Oct 2026'],
    datasets: [
      {
        label: 'Origination Volume ($M)',
        data: [1.2, 1.8, 2.4, 3.1, 3.9, 4.6],
        borderColor: '#4F46E5',
        backgroundColor: 'rgba(79, 70, 229, 0.12)',
        fill: true,
        tension: 0.4
      },
      {
        label: 'Approved Applications',
        data: [12, 18, 26, 34, 41, 52],
        borderColor: '#10B981',
        backgroundColor: 'transparent',
        borderDash: [5, 5],
        tension: 0.3
      }
    ]
  };

  // Approval vs Rejection Analysis
  const approvalVsRejectionData = {
    labels: ['Standard Personal', 'Auto Financing', 'Home Mortgage', 'SME Working Cap'],
    datasets: [
      {
        label: 'Approved',
        data: [18, 22, 14, 12],
        backgroundColor: '#10B981',
        borderRadius: 4
      },
      {
        label: 'Rejected',
        data: [6, 4, 3, 5],
        backgroundColor: '#EF4444',
        borderRadius: 4
      },
      {
        label: 'Manual Review',
        data: [4, 3, 5, 2],
        backgroundColor: '#F59E0B',
        borderRadius: 4
      }
    ]
  };

  // Applicant Income Distribution
  const incomeDistributionData = {
    labels: ['<$3k', '$3k-$5k', '$5k-$8k', '$8k-$12k', '>$12k'],
    datasets: [
      {
        label: 'Applicant Count',
        data: [14, 38, 42, 19, 7],
        backgroundColor: '#6366F1',
        borderRadius: 4
      }
    ]
  };

  // Affordability Risk Distribution
  const riskLabels = Object.keys(summary.risk_distribution);
  const riskValues = Object.values(summary.risk_distribution);
  const riskDistributionData = {
    labels: riskLabels,
    datasets: [
      {
        data: riskValues,
        backgroundColor: ['#10B981', '#3B82F6', '#F59E0B', '#EF4444'],
        borderWidth: 2,
        borderColor: '#ffffff'
      }
    ]
  };

  const recentApps = applications.slice(0, 6);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'APPROVED':
      case 'DISBURSED':
        return <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30">Approved</Badge>;
      case 'REJECTED':
        return <Badge variant="destructive" className="bg-rose-500/15 text-rose-700 dark:text-rose-400 border-rose-500/30">Rejected</Badge>;
      case 'MANUAL_REVIEW':
        return <Badge className="bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30">Manual Review</Badge>;
      case 'SUBMITTED':
      case 'UNDER_REVIEW':
        return <Badge className="bg-blue-500/15 text-blue-700 dark:text-blue-400 border-blue-500/30">In Review</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Welcome Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-xl bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-950 text-white shadow-md">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">LoanFlow AI Portfolio Command Center</h1>
          <p className="text-sm text-slate-300 mt-1">
            Deterministic loan origination, real-time affordability telemetry, and automated credit decisioning.
          </p>
        </div>
        <div className="flex items-center gap-2.5">
          <Button
            onClick={onOpenNewApplication}
            size="sm"
            className="bg-blue-600 hover:bg-blue-500 text-white font-medium shadow-sm"
          >
            <FileSpreadsheet className="w-4 h-4 mr-2" />
            New Application
          </Button>
          <Button
            onClick={onOpenNewApplicant}
            size="sm"
            variant="ghost"
            className="border border-white/40 text-white hover:bg-white/10 font-medium"
          >
            <Users className="w-4 h-4 mr-2" />
            Register Applicant
          </Button>
        </div>
      </div>

      {/* 8 KPI METRIC CARDS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5 md:gap-4">
        {/* KPI 1 */}
        <div className="p-4 rounded-xl bg-card border border-border shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-muted-foreground text-xs font-medium">
            <span>Total Applicants</span>
            <Users className="w-4 h-4 text-blue-500" />
          </div>
          <div className="mt-3">
            <span className="text-2xl md:text-3xl font-bold text-foreground">
              {summary.total_applicants.toLocaleString()}
            </span>
            <span className="text-[11px] text-emerald-600 dark:text-emerald-400 block mt-0.5 font-medium flex items-center">
              <TrendingUp className="w-3 h-3 mr-1 inline" /> Registered Borrowers
            </span>
          </div>
        </div>

        {/* KPI 2 */}
        <div className="p-4 rounded-xl bg-card border border-border shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-muted-foreground text-xs font-medium">
            <span>Total Applications</span>
            <FileSpreadsheet className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="mt-3">
            <span className="text-2xl md:text-3xl font-bold text-foreground">
              {summary.total_loan_applications.toLocaleString()}
            </span>
            <span className="text-[11px] text-blue-600 dark:text-blue-400 block mt-0.5 font-medium">
              Pipeline Submissions
            </span>
          </div>
        </div>

        {/* KPI 3 */}
        <div className="p-4 rounded-xl bg-card border border-border shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-muted-foreground text-xs font-medium">
            <span>Approved Applications</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="mt-3">
            <span className="text-2xl md:text-3xl font-bold text-emerald-600 dark:text-emerald-400">
              {summary.approved_applications.toLocaleString()}
            </span>
            <span className="text-[11px] text-muted-foreground block mt-0.5 font-medium">
              {summary.total_loan_applications > 0
                ? `${Math.round((summary.approved_applications / summary.total_loan_applications) * 100)}% Approval Rate`
                : '0%'}
            </span>
          </div>
        </div>

        {/* KPI 4 */}
        <div className="p-4 rounded-xl bg-card border border-border shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-muted-foreground text-xs font-medium">
            <span>Rejected Applications</span>
            <XCircle className="w-4 h-4 text-rose-500" />
          </div>
          <div className="mt-3">
            <span className="text-2xl md:text-3xl font-bold text-rose-600 dark:text-rose-400">
              {summary.rejected_applications.toLocaleString()}
            </span>
            <span className="text-[11px] text-muted-foreground block mt-0.5 font-medium">
              Policy or DTI Breaches
            </span>
          </div>
        </div>

        {/* KPI 5 */}
        <div className="p-4 rounded-xl bg-card border border-border shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-muted-foreground text-xs font-medium">
            <span>Manual Review Queue</span>
            <AlertCircle className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-3">
            <span className="text-2xl md:text-3xl font-bold text-amber-600 dark:text-amber-400">
              {summary.manual_review_applications.toLocaleString()}
            </span>
            <span className="text-[11px] text-amber-700 dark:text-amber-300 block mt-0.5 font-medium">
              Pending Underwriter Review
            </span>
          </div>
        </div>

        {/* KPI 6 */}
        <div className="p-4 rounded-xl bg-card border border-border shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-muted-foreground text-xs font-medium">
            <span>Requested Loan Volume</span>
            <DollarSign className="w-4 h-4 text-blue-600" />
          </div>
          <div className="mt-3">
            <span className="text-2xl md:text-3xl font-bold text-foreground">
              ${(summary.total_loan_amount_requested / 1000000).toFixed(2)}M
            </span>
            <span className="text-[11px] text-muted-foreground block mt-0.5 font-medium">
              Total Borrower Inquiries
            </span>
          </div>
        </div>

        {/* KPI 7 */}
        <div className="p-4 rounded-xl bg-card border border-border shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-muted-foreground text-xs font-medium">
            <span>Approved Loan Volume</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-3">
            <span className="text-2xl md:text-3xl font-bold text-emerald-600 dark:text-emerald-400">
              ${(summary.total_approved_loan_amount / 1000000).toFixed(2)}M
            </span>
            <span className="text-[11px] text-muted-foreground block mt-0.5 font-medium">
              Committed Underwriting Capital
            </span>
          </div>
        </div>

        {/* KPI 8 */}
        <div className="p-4 rounded-xl bg-card border border-border shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-muted-foreground text-xs font-medium">
            <span>Average DTI Ratio</span>
            <Percent className="w-4 h-4 text-purple-600" />
          </div>
          <div className="mt-3">
            <span className="text-2xl md:text-3xl font-bold text-foreground">
              {summary.average_dti_ratio}%
            </span>
            <span className="text-[11px] text-emerald-600 dark:text-emerald-400 block mt-0.5 font-medium">
              Healthy &lt; 45% Benchmark
            </span>
          </div>
        </div>
      </div>

      {/* 6 INTERACTIVE CHARTS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {/* Chart 1: Status Distribution */}
        <div className="p-5 rounded-xl bg-card border border-border shadow-sm flex flex-col">
          <h3 className="font-semibold text-sm text-foreground mb-3 flex items-center justify-between">
            <span>Application Status Distribution</span>
            <Badge variant="outline" className="text-[10px]">Real-Time</Badge>
          </h3>
          <div className="h-56 relative flex items-center justify-center">
            <Doughnut
              data={statusChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, font: { size: 11 } } } }
              }}
            />
          </div>
        </div>

        {/* Chart 2: Product Volume Distribution */}
        <div className="p-5 rounded-xl bg-card border border-border shadow-sm flex flex-col">
          <h3 className="font-semibold text-sm text-foreground mb-3 flex items-center justify-between">
            <span>Loan Product Distribution</span>
            <Badge variant="outline" className="text-[10px]">Active Products</Badge>
          </h3>
          <div className="h-56 relative">
            <Bar
              data={productChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' } }, x: { grid: { display: false } } }
              }}
            />
          </div>
        </div>

        {/* Chart 3: Monthly Application Trends */}
        <div className="p-5 rounded-xl bg-card border border-border shadow-sm flex flex-col">
          <h3 className="font-semibold text-sm text-foreground mb-3 flex items-center justify-between">
            <span>Monthly Application Trends</span>
            <Badge variant="outline" className="text-[10px]">6 Months</Badge>
          </h3>
          <div className="h-56 relative">
            <Line
              data={monthlyTrendsData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, font: { size: 10 } } } },
                scales: { y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' } }, x: { grid: { display: false } } }
              }}
            />
          </div>
        </div>

        {/* Chart 4: Approval vs Rejection Analysis */}
        <div className="p-5 rounded-xl bg-card border border-border shadow-sm flex flex-col">
          <h3 className="font-semibold text-sm text-foreground mb-3 flex items-center justify-between">
            <span>Approval vs. Rejection by Product</span>
            <Badge variant="outline" className="text-[10px]">Product Risk</Badge>
          </h3>
          <div className="h-56 relative">
            <Bar
              data={approvalVsRejectionData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom', labels: { boxWidth: 8, font: { size: 10 } } } },
                scales: { x: { stacked: true, grid: { display: false } }, y: { stacked: true, beginAtZero: true } }
              }}
            />
          </div>
        </div>

        {/* Chart 5: Applicant Income Distribution */}
        <div className="p-5 rounded-xl bg-card border border-border shadow-sm flex flex-col">
          <h3 className="font-semibold text-sm text-foreground mb-3 flex items-center justify-between">
            <span>Applicant Monthly Income Distribution</span>
            <Badge variant="outline" className="text-[10px]">Cohorts</Badge>
          </h3>
          <div className="h-56 relative">
            <Bar
              data={incomeDistributionData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true }, x: { grid: { display: false } } }
              }}
            />
          </div>
        </div>

        {/* Chart 6: Risk Rating Distribution */}
        <div className="p-5 rounded-xl bg-card border border-border shadow-sm flex flex-col">
          <h3 className="font-semibold text-sm text-foreground mb-3 flex items-center justify-between">
            <span>Affordability Risk Distribution</span>
            <Badge variant="outline" className="text-[10px]">Credit Tiers</Badge>
          </h3>
          <div className="h-56 relative flex items-center justify-center">
            <Pie
              data={riskDistributionData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, font: { size: 11 } } } }
              }}
            />
          </div>
        </div>
      </div>

      {/* OPERATIONAL FEEDS SECTION: RECENT APPLICATIONS & LATEST DECISIONS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Recent Applications Table (2 Cols) */}
        <div className="lg:col-span-2 p-5 rounded-xl bg-card border border-border shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-base text-foreground">Recent Loan Applications</h3>
              <p className="text-xs text-muted-foreground">Latest originated requests in the pipeline</p>
            </div>
            <Link to="/applications">
              <Button variant="ghost" size="sm" className="text-xs text-primary gap-1">
                View Pipeline <ArrowUpRight className="w-3.5 h-3.5" />
              </Button>
            </Link>
          </div>

          <div className="overflow-x-auto w-full">
            <table className="w-full text-left text-xs whitespace-nowrap">
              <thead>
                <tr className="border-b border-border text-muted-foreground">
                  <th className="pb-2.5 font-semibold">Application #</th>
                  <th className="pb-2.5 font-semibold">Borrower</th>
                  <th className="pb-2.5 font-semibold">Product</th>
                  <th className="pb-2.5 font-semibold">Amount</th>
                  <th className="pb-2.5 font-semibold">Status</th>
                  <th className="pb-2.5 font-semibold text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/60">
                {recentApps.map((app) => {
                  const applicant = dbStore.applicants.get(app.applicant_id);
                  const product = dbStore.products.get(app.product_id);
                  return (
                    <tr key={app.id} className="hover:bg-muted/40 transition-colors">
                      <td className="py-3 font-mono font-medium text-foreground">{app.application_number}</td>
                      <td className="py-3 text-foreground font-medium">
                        {applicant ? `${applicant.first_name} ${applicant.last_name}` : 'Unknown'}
                      </td>
                      <td className="py-3 text-muted-foreground">{product ? product.name : 'Loan'}</td>
                      <td className="py-3 font-semibold text-foreground">${app.requested_principal.toLocaleString()}</td>
                      <td className="py-3">{getStatusBadge(app.status)}</td>
                      <td className="py-3 text-right">
                        <Link to={`/applications?id=${app.id}`}>
                          <Button variant="ghost" size="sm" className="h-7 px-2 text-xs text-primary">
                            Inspect
                          </Button>
                        </Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right: Recent Decisions & High-Risk Alerts (1 Col) */}
        <div className="space-y-6">
          {/* Latest Decisions Feed */}
          <div className="p-5 rounded-xl bg-card border border-border shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-sm text-foreground flex items-center gap-2">
                <Activity className="w-4 h-4 text-primary" />
                Latest Decision Outcomes
              </h3>
              <Link to="/decisions" className="text-xs text-primary hover:underline font-medium">
                All
              </Link>
            </div>
            <div className="space-y-2.5">
              {decisions.slice(0, 4).map((d) => {
                const app = dbStore.applications.get(d.application_id);
                return (
                  <div key={d.id} className="p-2.5 rounded-lg border border-border bg-muted/20 text-xs space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-medium text-foreground">
                        {app ? app.application_number : d.application_id}
                      </span>
                      {getStatusBadge(d.outcome)}
                    </div>
                    <p className="text-muted-foreground text-[11px] line-clamp-2 leading-relaxed">
                      {d.explanation}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* High-Risk Application Alerts & Open Exceptions */}
          <div className="p-5 rounded-xl bg-card border border-border shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-sm text-destructive flex items-center gap-2">
                <ShieldAlert className="w-4 h-4" />
                Exceptions & Integrity Alerts
              </h3>
              <Link to="/exceptions" className="text-xs text-primary hover:underline font-medium">
                Resolve
              </Link>
            </div>
            {issues.length === 0 ? (
              <p className="text-xs text-muted-foreground py-2">No critical unresolved exceptions.</p>
            ) : (
              <div className="space-y-2">
                {issues.map((iss) => (
                  <div
                    key={iss.id}
                    className="p-2.5 rounded-lg border border-rose-500/20 bg-rose-500/5 text-xs text-rose-950 dark:text-rose-200"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[11px]">{iss.issue_type.replace(/_/g, ' ')}</span>
                      <Badge variant="destructive" className="text-[9px] h-4 px-1.5 uppercase">
                        {iss.severity}
                      </Badge>
                    </div>
                    <p className="text-[11px] text-muted-foreground mt-1 line-clamp-1">{iss.description}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* AUDIT LOG PREVIEW & PENDING VERIFICATIONS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Pending Document Verifications */}
        <div className="p-5 rounded-xl bg-card border border-border shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-sm text-foreground flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-500" />
              Pending Document Verifications
            </h3>
            <Link to="/documents" className="text-xs text-primary hover:underline font-medium">
              Review Queue
            </Link>
          </div>
          <div className="space-y-2">
            {pendingDocs.map((doc) => {
              const app = dbStore.applications.get(doc.application_id);
              return (
                <div key={doc.id} className="flex items-center justify-between p-2.5 rounded bg-muted/30 border border-border text-xs">
                  <div>
                    <p className="font-semibold text-foreground">{doc.document_name}</p>
                    <p className="text-[11px] text-muted-foreground">App: {app ? app.application_number : doc.application_id}</p>
                  </div>
                  <Badge variant="outline" className="bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/30 text-[10px]">
                    Pending Verification
                  </Badge>
                </div>
              );
            })}
          </div>
        </div>

        {/* System Audit Events Stream */}
        <div className="p-5 rounded-xl bg-card border border-border shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-sm text-foreground flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-500" />
              Latest System Events
            </h3>
            <Link to="/audit-logs" className="text-xs text-primary hover:underline font-medium">
              View Audit Trail
            </Link>
          </div>
          <div className="space-y-2.5">
            {events.slice(0, 5).map((evt) => (
              <div key={evt.id} className="flex items-start gap-2.5 text-xs text-muted-foreground">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-foreground font-medium line-clamp-1">{evt.description}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">
                    {evt.actor} • {new Date(evt.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
