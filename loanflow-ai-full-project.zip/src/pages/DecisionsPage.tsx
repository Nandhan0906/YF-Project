import React, { useState } from 'react';
import {
  Scale,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  AlertCircle,
  RotateCcw,
  ChevronRight,
  ShieldCheck,
  FileText
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { dbStore } from '@/services/dbStore';
import { Decision, DecisionOutcome } from '@/types/loanflow';

export const DecisionsPage: React.FC = () => {
  const [search, setSearch] = useState('');
  const [outcomeFilter, setOutcomeFilter] = useState('all');
  const [selectedDecision, setSelectedDecision] = useState<Decision | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [overrideOpen, setOverrideOpen] = useState(false);
  const [overrideOutcome, setOverrideOutcome] = useState<DecisionOutcome>('APPROVED');
  const [overrideReason, setOverrideReason] = useState('');

  const decisions = Array.from(dbStore.decisions.values());

  const filtered = decisions.filter((d) => {
    const app = dbStore.applications.get(d.application_id);
    const applicant = app ? dbStore.applicants.get(app.applicant_id) : null;
    const name = applicant ? `${applicant.first_name} ${applicant.last_name}` : '';
    const appNum = app ? app.application_number : d.application_id;

    const matchesSearch =
      search === '' ||
      appNum.toLowerCase().includes(search.toLowerCase()) ||
      name.toLowerCase().includes(search.toLowerCase());

    const matchesOutcome = outcomeFilter === 'all' || d.outcome === outcomeFilter;

    return matchesSearch && matchesOutcome;
  });

  const handleOverride = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDecision || !overrideReason.trim()) {
      toast.error('Please enter justification for underwriter override.');
      return;
    }

    try {
      dbStore.overrideDecision(selectedDecision.application_id, overrideOutcome, overrideReason);
      toast.success(`Application decision overridden to ${overrideOutcome}`);
      setOverrideOpen(false);
      setDetailOpen(false);
      setOverrideReason('');
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const getOutcomeBadge = (outcome: DecisionOutcome) => {
    switch (outcome) {
      case 'APPROVED':
        return <Badge className="bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border-none">Approved</Badge>;
      case 'REJECTED':
        return <Badge variant="destructive">Rejected</Badge>;
      case 'MANUAL_REVIEW':
        return <Badge className="bg-amber-500/20 text-amber-700 dark:text-amber-400 border-amber-500/30">Manual Review</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
          <Scale className="w-6 h-6 text-primary" />
          Deterministic Loan Decision Queue
        </h1>
        <p className="text-xs text-muted-foreground mt-1">
          Explainable, rule-based credit decisions with Adverse Action reason codes and underwriter override governance.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-xl bg-card border border-border shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by app #, borrower name..."
            className="pl-9 h-9 text-xs"
          />
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <Select value={outcomeFilter} onValueChange={setOutcomeFilter}>
            <SelectTrigger className="h-9 w-44 text-xs">
              <SelectValue placeholder="Filter by Outcome" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Outcomes</SelectItem>
              <SelectItem value="APPROVED">APPROVED</SelectItem>
              <SelectItem value="REJECTED">REJECTED</SelectItem>
              <SelectItem value="MANUAL_REVIEW">MANUAL_REVIEW</SelectItem>
            </SelectContent>
          </Select>

          <span className="text-xs text-muted-foreground whitespace-nowrap">
            Showing {filtered.length} decisions
          </span>
        </div>
      </div>

      {/* Decisions Table */}
      <div className="rounded-xl bg-card border border-border shadow-sm overflow-hidden">
        <div className="overflow-x-auto w-full">
          <table className="w-full text-left text-xs whitespace-nowrap">
            <thead className="bg-muted/40 border-b border-border text-muted-foreground">
              <tr>
                <th className="py-3 px-4 font-semibold">Application #</th>
                <th className="py-3 px-4 font-semibold">Borrower</th>
                <th className="py-3 px-4 font-semibold">Outcome</th>
                <th className="py-3 px-4 font-semibold">Decided By</th>
                <th className="py-3 px-4 font-semibold">Rule Version</th>
                <th className="py-3 px-4 font-semibold">Reason Codes</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-muted-foreground">
                    No decisions recorded matching search.
                  </td>
                </tr>
              ) : (
                filtered.map((d) => {
                  const app = dbStore.applications.get(d.application_id);
                  const applicant = app ? dbStore.applicants.get(app.applicant_id) : null;
                  return (
                    <tr
                      key={d.id}
                      onClick={() => {
                        setSelectedDecision(d);
                        setDetailOpen(true);
                      }}
                      className="hover:bg-muted/40 cursor-pointer transition-colors"
                    >
                      <td className="py-3.5 px-4 font-mono font-medium text-foreground">
                        {app ? app.application_number : d.application_id}
                      </td>
                      <td className="py-3.5 px-4 font-medium text-foreground">
                        {applicant ? `${applicant.first_name} ${applicant.last_name}` : 'Unknown'}
                      </td>
                      <td className="py-3.5 px-4">{getOutcomeBadge(d.outcome)}</td>
                      <td className="py-3.5 px-4 text-muted-foreground">{d.decided_by}</td>
                      <td className="py-3.5 px-4 font-mono text-[11px] text-muted-foreground">{d.rule_version}</td>
                      <td className="py-3.5 px-4">
                        <div className="flex gap-1 max-w-xs truncate">
                          {d.reason_codes.slice(0, 2).map((rc, idx) => (
                            <Badge key={idx} variant="outline" className="text-[9px] font-mono">
                              {rc}
                            </Badge>
                          ))}
                          {d.reason_codes.length > 2 && (
                            <span className="text-[10px] text-muted-foreground">+{d.reason_codes.length - 2}</span>
                          )}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedDecision(d);
                            setDetailOpen(true);
                          }}
                          className="h-7 px-2.5 text-xs text-primary"
                        >
                          Audit Rules <ChevronRight className="w-3.5 h-3.5 ml-1" />
                        </Button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Decision Detail Modal */}
      {selectedDecision && (
        <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
          <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-2xl bg-card border-border">
            <DialogHeader className="border-b border-border pb-3">
              <div className="flex justify-between items-center">
                <DialogTitle className="text-base font-bold flex items-center gap-2">
                  <span>Decision Audit: {selectedDecision.application_id}</span>
                  {getOutcomeBadge(selectedDecision.outcome)}
                </DialogTitle>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setOverrideOpen(true)}
                  className="h-7 text-xs gap-1"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Override
                </Button>
              </div>
            </DialogHeader>

            <div className="space-y-4 pt-2 text-xs">
              <div className="p-3.5 rounded-lg bg-muted/30 border border-border space-y-1.5">
                <p className="font-semibold text-foreground">Explainable Decision Summary:</p>
                <p className="text-muted-foreground leading-relaxed">{selectedDecision.explanation}</p>
                {selectedDecision.underwriter_override && (
                  <div className="mt-2 p-2 rounded bg-amber-500/10 border border-amber-500/20 text-amber-900 dark:text-amber-200">
                    <span className="font-bold">Manual Underwriter Override Active:</span>
                    <p className="mt-0.5">{selectedDecision.override_reason}</p>
                  </div>
                )}
              </div>

              <div>
                <p className="font-semibold text-foreground mb-1.5">Evaluated Business Reason Codes:</p>
                <div className="space-y-1">
                  {selectedDecision.reason_codes.map((rc, i) => (
                    <div key={i} className="p-2 rounded bg-muted/40 border border-border font-mono text-[11px] flex items-center justify-between">
                      <span>{rc}</span>
                      <Badge variant="outline" className="text-[9px]">EVALUATED</Badge>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-3 rounded-lg border border-border bg-muted/10 text-muted-foreground space-y-1 text-[11px]">
                <p>Rule Engine Architecture: {selectedDecision.rule_version}</p>
                <p>Decision Generated At: {new Date(selectedDecision.created_at).toLocaleString()}</p>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Override Dialog */}
      <Dialog open={overrideOpen} onOpenChange={setOverrideOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-sm font-bold">Underwriter Decision Override</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleOverride} className="space-y-3 pt-2 text-xs">
            <div className="space-y-1">
              <Label>Target Outcome</Label>
              <select
                value={overrideOutcome}
                onChange={(e: any) => setOverrideOutcome(e.target.value)}
                className="w-full h-8 rounded border border-border bg-background px-2 text-xs"
              >
                <SelectItem value="APPROVED">APPROVED</SelectItem>
                <SelectItem value="REJECTED">REJECTED</SelectItem>
                <SelectItem value="MANUAL_REVIEW">MANUAL_REVIEW</SelectItem>
              </select>
            </div>
            <div className="space-y-1">
              <Label>Mandatory Underwriting Rationale *</Label>
              <Input
                value={overrideReason}
                onChange={(e) => setOverrideReason(e.target.value)}
                placeholder="Explain the business or risk reason for overriding..."
                required
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="ghost" onClick={() => setOverrideOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90">
                Confirm Override
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};
