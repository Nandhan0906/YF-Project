import React, { useState } from 'react';
import {
  FileCheck2,
  Search,
  Filter,
  CheckCircle,
  XCircle,
  Clock,
  AlertCircle,
  FileText,
  UploadCloud,
  Check
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { toast } from 'sonner';
import { dbStore } from '@/services/dbStore';
import { DocumentRecord, DocumentStatus } from '@/types/loanflow';

export const DocumentsPage: React.FC = () => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [refreshKey, setRefreshKey] = useState(0);

  const docs = Array.from(dbStore.documents.values());

  const filtered = docs.filter((d) => {
    const app = dbStore.applications.get(d.application_id);
    const applicant = app ? dbStore.applicants.get(app.applicant_id) : null;
    const name = applicant ? `${applicant.first_name} ${applicant.last_name}` : '';
    const appNum = app ? app.application_number : d.application_id;

    const matchesSearch =
      search === '' ||
      d.document_name.toLowerCase().includes(search.toLowerCase()) ||
      appNum.toLowerCase().includes(search.toLowerCase()) ||
      name.toLowerCase().includes(search.toLowerCase());

    const matchesStatus = statusFilter === 'all' || d.status === statusFilter;
    const matchesType = typeFilter === 'all' || d.document_type === typeFilter;

    return matchesSearch && matchesStatus && matchesType;
  });

  const handleVerify = (doc: DocumentRecord) => {
    dbStore.updateDocumentStatus(doc.id, 'VERIFIED', 'Verified against official repository');
    toast.success(`${doc.document_name} verified successfully!`);
    setRefreshKey(k => k + 1);
  };

  const handleReject = (doc: DocumentRecord) => {
    dbStore.updateDocumentStatus(doc.id, 'REJECTED', 'Illegible or unverified metadata');
    toast.error(`${doc.document_name} rejected`);
    setRefreshKey(k => k + 1);
  };

  const getStatusBadge = (status: DocumentStatus) => {
    switch (status) {
      case 'VERIFIED':
        return <Badge className="bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border-none">Verified</Badge>;
      case 'REJECTED':
        return <Badge variant="destructive">Rejected</Badge>;
      case 'PENDING':
        return <Badge className="bg-amber-500/20 text-amber-700 dark:text-amber-400 border-amber-500/30">Pending</Badge>;
      case 'MISSING':
        return <Badge variant="outline" className="text-rose-600 border-rose-300">Missing</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
          <FileCheck2 className="w-6 h-6 text-primary" />
          Document Verification Workspace
        </h1>
        <p className="text-xs text-muted-foreground mt-1">
          Review borrower proof of identity, income stubs, bank statements, and address verification.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-xl bg-card border border-border shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by document, app #, borrower..."
            className="pl-9 h-9 text-xs"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="h-9 w-36 text-xs">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="PENDING">PENDING</SelectItem>
              <SelectItem value="VERIFIED">VERIFIED</SelectItem>
              <SelectItem value="REJECTED">REJECTED</SelectItem>
              <SelectItem value="MISSING">MISSING</SelectItem>
            </SelectContent>
          </Select>

          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="h-9 w-40 text-xs">
              <SelectValue placeholder="Document Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="IDENTITY_PROOF">Identity Proof</SelectItem>
              <SelectItem value="INCOME_PROOF">Income Proof</SelectItem>
              <SelectItem value="EMPLOYMENT_PROOF">Employment Proof</SelectItem>
              <SelectItem value="BANK_STATEMENT">Bank Statement</SelectItem>
              <SelectItem value="ADDRESS_PROOF">Address Proof</SelectItem>
            </SelectContent>
          </Select>

          <span className="text-xs text-muted-foreground whitespace-nowrap">
            Showing {filtered.length} documents
          </span>
        </div>
      </div>

      {/* Documents Table */}
      <div className="rounded-xl bg-card border border-border shadow-sm overflow-hidden">
        <div className="overflow-x-auto w-full">
          <table className="w-full text-left text-xs whitespace-nowrap">
            <thead className="bg-muted/40 border-b border-border text-muted-foreground">
              <tr>
                <th className="py-3 px-4 font-semibold">Document Name</th>
                <th className="py-3 px-4 font-semibold">Type</th>
                <th className="py-3 px-4 font-semibold">Application #</th>
                <th className="py-3 px-4 font-semibold">Borrower</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold">Verification Notes</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-muted-foreground">
                    No documents matching criteria.
                  </td>
                </tr>
              ) : (
                filtered.map((d) => {
                  const app = dbStore.applications.get(d.application_id);
                  const applicant = app ? dbStore.applicants.get(app.applicant_id) : null;
                  return (
                    <tr key={d.id} className="hover:bg-muted/40 transition-colors">
                      <td className="py-3.5 px-4 font-medium text-foreground flex items-center gap-2">
                        <FileText className="w-4 h-4 text-blue-500" />
                        <span>{d.document_name}</span>
                      </td>
                      <td className="py-3.5 px-4 text-muted-foreground">
                        {d.document_type.replace(/_/g, ' ')}
                      </td>
                      <td className="py-3.5 px-4 font-mono font-medium text-foreground">
                        {app ? app.application_number : d.application_id}
                      </td>
                      <td className="py-3.5 px-4 text-foreground">
                        {applicant ? `${applicant.first_name} ${applicant.last_name}` : 'Unknown'}
                      </td>
                      <td className="py-3.5 px-4">{getStatusBadge(d.status)}</td>
                      <td className="py-3.5 px-4 text-muted-foreground max-w-xs truncate">
                        {d.verification_notes || d.rejection_reason || '—'}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        {d.status === 'PENDING' ? (
                          <div className="flex justify-end gap-1.5">
                            <Button
                              size="sm"
                              onClick={() => handleVerify(d)}
                              className="h-7 px-2.5 text-xs bg-emerald-600 hover:bg-emerald-500 text-white"
                            >
                              Verify
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleReject(d)}
                              className="h-7 px-2.5 text-xs text-rose-600 hover:bg-rose-50"
                            >
                              Reject
                            </Button>
                          </div>
                        ) : (
                          <span className="text-muted-foreground text-[11px]">—</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
