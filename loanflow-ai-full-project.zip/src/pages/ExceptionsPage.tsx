import React, { useState } from 'react';
import {
  AlertTriangle,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  ShieldAlert,
  UserCheck,
  Check
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { dbStore } from '@/services/dbStore';
import { IssueRecord, IssueSeverity, IssueStatus } from '@/types/loanflow';

export const ExceptionsPage: React.FC = () => {
  const [search, setSearch] = useState('');
  const [severityFilter, setSeverityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedIssue, setSelectedIssue] = useState<IssueRecord | null>(null);
  const [resolveModalOpen, setResolveModalOpen] = useState(false);
  const [resolutionStatus, setResolutionStatus] = useState<IssueStatus>('RESOLVED');
  const [resolutionRemarks, setResolutionRemarks] = useState('');
  const [refreshKey, setRefreshKey] = useState(0);

  const issues = Array.from(dbStore.issues.values());

  const filtered = issues.filter((iss) => {
    const app = iss.application_id ? dbStore.applications.get(iss.application_id) : undefined;
    const appNum = app ? app.application_number : (iss.application_id || 'N/A');

    const matchesSearch =
      search === '' ||
      iss.description.toLowerCase().includes(search.toLowerCase()) ||
      iss.issue_type.toLowerCase().includes(search.toLowerCase()) ||
      appNum.toLowerCase().includes(search.toLowerCase());

    const matchesSeverity = severityFilter === 'all' || iss.severity === severityFilter;
    const matchesStatus = statusFilter === 'all' || iss.resolution_status === statusFilter;

    return matchesSearch && matchesSeverity && matchesStatus;
  });

  const handleResolveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedIssue || !resolutionRemarks.trim()) {
      toast.error('Resolution audit remarks are mandatory.');
      return;
    }

    try {
      dbStore.resolveIssue(selectedIssue.id, resolutionStatus, resolutionRemarks);
      toast.success(`Exception ${selectedIssue.id} updated to ${resolutionStatus}`);
      setResolveModalOpen(false);
      setResolutionRemarks('');
      setRefreshKey(k => k + 1);
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const getSeverityBadge = (sev: IssueSeverity) => {
    switch (sev) {
      case 'CRITICAL':
        return <Badge variant="destructive">CRITICAL</Badge>;
      case 'HIGH':
        return <Badge className="bg-rose-500/20 text-rose-700 dark:text-rose-400 border-none">HIGH</Badge>;
      case 'MEDIUM':
        return <Badge className="bg-amber-500/20 text-amber-700 dark:text-amber-400 border-none">MEDIUM</Badge>;
      default:
        return <Badge variant="outline">LOW</Badge>;
    }
  };

  const getStatusBadge = (st: IssueStatus) => {
    switch (st) {
      case 'RESOLVED':
      case 'WAIVED':
        return <Badge className="bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border-none">{st}</Badge>;
      case 'IN_PROGRESS':
        return <Badge className="bg-blue-500/20 text-blue-700 dark:text-blue-400 border-none">IN PROGRESS</Badge>;
      default:
        return <Badge variant="outline" className="text-rose-600 border-rose-300">OPEN</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
          <AlertTriangle className="w-6 h-6 text-destructive" />
          Exception & Data Inconsistency Register
        </h1>
        <p className="text-xs text-muted-foreground mt-1">
          Centralized register of policy violations, missing income verifications, duplicate submissions, and data conflicts.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-xl bg-card border border-border shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search exceptions, app #, issue type..."
            className="pl-9 h-9 text-xs"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
          <Select value={severityFilter} onValueChange={setSeverityFilter}>
            <SelectTrigger className="h-9 w-36 text-xs">
              <SelectValue placeholder="Severity" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Severities</SelectItem>
              <SelectItem value="CRITICAL">CRITICAL</SelectItem>
              <SelectItem value="HIGH">HIGH</SelectItem>
              <SelectItem value="MEDIUM">MEDIUM</SelectItem>
              <SelectItem value="LOW">LOW</SelectItem>
            </SelectContent>
          </Select>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="h-9 w-36 text-xs">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="OPEN">OPEN</SelectItem>
              <SelectItem value="IN_PROGRESS">IN_PROGRESS</SelectItem>
              <SelectItem value="RESOLVED">RESOLVED</SelectItem>
              <SelectItem value="WAIVED">WAIVED</SelectItem>
            </SelectContent>
          </Select>

          <span className="text-xs text-muted-foreground whitespace-nowrap">
            Showing {filtered.length} exceptions
          </span>
        </div>
      </div>

      {/* Issues Table */}
      <div className="rounded-xl bg-card border border-border shadow-sm overflow-hidden">
        <div className="overflow-x-auto w-full">
          <table className="w-full text-left text-xs whitespace-nowrap">
            <thead className="bg-muted/40 border-b border-border text-muted-foreground">
              <tr>
                <th className="py-3 px-4 font-semibold">Issue Type</th>
                <th className="py-3 px-4 font-semibold">Application #</th>
                <th className="py-3 px-4 font-semibold">Severity</th>
                <th className="py-3 px-4 font-semibold">Description</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold">Resolution Remarks</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-muted-foreground">
                    No exceptions matching search criteria.
                  </td>
                </tr>
              ) : (
                filtered.map((iss) => {
                  const app = iss.application_id ? dbStore.applications.get(iss.application_id) : undefined;
                  return (
                    <tr key={iss.id} className="hover:bg-muted/40 transition-colors">
                      <td className="py-3.5 px-4 font-semibold text-foreground">
                        {iss.issue_type.replace(/_/g, ' ')}
                      </td>
                      <td className="py-3.5 px-4 font-mono font-medium text-foreground">
                        {app ? app.application_number : iss.application_id}
                      </td>
                      <td className="py-3.5 px-4">{getSeverityBadge(iss.severity)}</td>
                      <td className="py-3.5 px-4 text-muted-foreground max-w-sm truncate">
                        {iss.description}
                      </td>
                      <td className="py-3.5 px-4">{getStatusBadge(iss.resolution_status)}</td>
                      <td className="py-3.5 px-4 text-muted-foreground max-w-xs truncate">
                        {iss.resolution_remarks || iss.resolution_notes || '—'}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        {iss.resolution_status !== 'RESOLVED' && iss.resolution_status !== 'WAIVED' ? (
                          <Button
                            size="sm"
                            onClick={() => {
                              setSelectedIssue(iss);
                              setResolveModalOpen(true);
                            }}
                            className="h-7 px-2.5 text-xs bg-primary text-primary-foreground hover:bg-primary/90"
                          >
                            Resolve Issue
                          </Button>
                        ) : (
                          <span className="text-muted-foreground text-[11px]">Completed</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Resolution Dialog */}
      {selectedIssue && (
        <Dialog open={resolveModalOpen} onOpenChange={setResolveModalOpen}>
          <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md bg-card border-border">
            <DialogHeader>
              <DialogTitle className="text-base font-bold">
                Resolve Exception: {selectedIssue.issue_type.replace(/_/g, ' ')}
              </DialogTitle>
            </DialogHeader>

            <form onSubmit={handleResolveSubmit} className="space-y-3 pt-2 text-xs">
              <div className="p-3 rounded-lg bg-muted/40 border border-border">
                <span className="text-[11px] text-muted-foreground block">Issue Description:</span>
                <p className="font-medium text-foreground mt-0.5">{selectedIssue.description}</p>
              </div>

              <div className="space-y-1">
                <Label>Resolution Decision</Label>
                <select
                  value={resolutionStatus}
                  onChange={(e: any) => setResolutionStatus(e.target.value)}
                  className="w-full h-8 rounded border border-border bg-background px-2 text-xs"
                >
                  <SelectItem value="RESOLVED">RESOLVED (Remediation completed)</SelectItem>
                  <SelectItem value="WAIVED">WAIVED (Risk accepted by Senior Officer)</SelectItem>
                  <SelectItem value="IN_PROGRESS">IN_PROGRESS (Investigating)</SelectItem>
                </select>
              </div>

              <div className="space-y-1">
                <Label>Resolution Remarks & Compliance Audit Notes *</Label>
                <Input
                  value={resolutionRemarks}
                  onChange={(e) => setResolutionRemarks(e.target.value)}
                  placeholder="Detail how the issue was verified, corrected, or waived..."
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-border">
                <Button type="button" variant="ghost" onClick={() => setResolveModalOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90">
                  Record Resolution
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};
