import React, { useState } from 'react';
import {
  PackageCheck,
  Plus,
  Percent,
  Calendar,
  DollarSign,
  ShieldAlert,
  CheckCircle2,
  Sliders,
  Power
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { dbStore } from '@/services/dbStore';
import { LoanProduct } from '@/types/loanflow';

export const ProductsPage: React.FC = () => {
  const [products, setProducts] = useState<LoanProduct[]>(Array.from(dbStore.products.values()));
  const [editingProduct, setEditingProduct] = useState<LoanProduct | null>(null);
  const [editModalOpen, setEditModalOpen] = useState(false);

  const handleToggleStatus = (prod: LoanProduct) => {
    const newStatus = prod.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    prod.status = newStatus;
    dbStore.products.set(prod.id, { ...prod });
    dbStore.saveToStorage();
    setProducts(Array.from(dbStore.products.values()));
    toast.success(`Product ${prod.name} marked as ${newStatus}`);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;

    dbStore.products.set(editingProduct.id, { ...editingProduct });
    dbStore.saveToStorage();
    setProducts(Array.from(dbStore.products.values()));
    setEditModalOpen(false);
    toast.success(`Product ${editingProduct.name} parameters updated successfully!`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <PackageCheck className="w-6 h-6 text-primary" />
            Loan Products & Credit Policies
          </h1>
          <p className="text-xs text-muted-foreground mt-1">
            Configure interest rates, principal bounds, tenure limits, DTI thresholds, and underwriting criteria.
          </p>
        </div>
      </div>

      {/* 4 Loan Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {products.map((prod) => (
          <div
            key={prod.id}
            className="p-5 rounded-xl bg-card border border-border shadow-sm flex flex-col justify-between space-y-4 hover:border-primary/40 transition-colors"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-base text-foreground">{prod.name}</h3>
                    <Badge variant="outline" className="font-mono text-[10px]">
                      {prod.code}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                    {prod.description}
                  </p>
                </div>
                <Badge
                  className={
                    prod.status === 'ACTIVE'
                      ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border-none'
                      : 'bg-muted text-muted-foreground border-none'
                  }
                >
                  {prod.status}
                </Badge>
              </div>

              {/* Core Parameters Matrix */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mt-4 text-xs">
                <div className="p-2.5 rounded-lg bg-muted/40 border border-border">
                  <span className="text-muted-foreground text-[10px] block flex items-center gap-1">
                    <Percent className="w-3 h-3 text-blue-500" /> Annual APR
                  </span>
                  <span className="font-bold text-sm text-foreground">{prod.annual_interest_rate}%</span>
                </div>

                <div className="p-2.5 rounded-lg bg-muted/40 border border-border">
                  <span className="text-muted-foreground text-[10px] block flex items-center gap-1">
                    <DollarSign className="w-3 h-3 text-emerald-500" /> Principal Range
                  </span>
                  <span className="font-bold text-xs text-foreground">
                    ${(prod.min_principal / 1000).toFixed(0)}k - ${(prod.max_principal / 1000).toFixed(0)}k
                  </span>
                </div>

                <div className="p-2.5 rounded-lg bg-muted/40 border border-border">
                  <span className="text-muted-foreground text-[10px] block flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-indigo-500" /> Tenure Bounds
                  </span>
                  <span className="font-bold text-xs text-foreground">
                    {prod.min_tenure_months} - {prod.max_tenure_months} mo
                  </span>
                </div>

                <div className="p-2.5 rounded-lg bg-muted/40 border border-border">
                  <span className="text-muted-foreground text-[10px] block">Max Allowed DTI</span>
                  <span className="font-bold text-xs text-foreground">{prod.max_dti_ratio}%</span>
                </div>

                <div className="p-2.5 rounded-lg bg-muted/40 border border-border">
                  <span className="text-muted-foreground text-[10px] block">Min Monthly Income</span>
                  <span className="font-bold text-xs text-foreground">${(prod.min_income_requirement || 2500).toLocaleString()}</span>
                </div>

                <div className="p-2.5 rounded-lg bg-muted/40 border border-border">
                  <span className="text-muted-foreground text-[10px] block">Required Employment</span>
                  <span className="font-bold text-xs text-foreground">{prod.required_employment_status || 'PERMANENT'}</span>
                </div>
              </div>

              {/* Document Checklist */}
              <div className="mt-3.5 pt-3 border-t border-border">
                <span className="text-[11px] font-semibold text-muted-foreground block mb-1.5">
                  Mandatory Document Checklist:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {(prod.required_documents || ['IDENTITY_PROOF', 'INCOME_PROOF', 'BANK_STATEMENTS']).map((doc: string, i: number) => (
                    <Badge key={i} variant="outline" className="text-[10px] bg-muted/20">
                      {doc.replace(/_/g, ' ')}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between pt-3 border-t border-border">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleToggleStatus(prod)}
                className={`text-xs gap-1.5 h-8 ${
                  prod.status === 'ACTIVE' ? 'text-rose-600 hover:text-rose-700' : 'text-emerald-600'
                }`}
              >
                <Power className="w-3.5 h-3.5" />
                {prod.status === 'ACTIVE' ? 'Deactivate Product' : 'Activate Product'}
              </Button>

              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  setEditingProduct({ ...prod });
                  setEditModalOpen(true);
                }}
                className="text-xs h-8 gap-1.5"
              >
                <Sliders className="w-3.5 h-3.5" /> Edit Parameters
              </Button>
            </div>
          </div>
        ))}
      </div>

      {/* Edit Product Dialog */}
      <Dialog open={editModalOpen} onOpenChange={setEditModalOpen}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-base font-bold">
              Edit Product: {editingProduct?.name}
            </DialogTitle>
          </DialogHeader>

          {editingProduct && (
            <form onSubmit={handleSaveEdit} className="space-y-3 pt-2 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Annual APR (%)</Label>
                  <Input
                    type="number"
                    step="0.05"
                    value={editingProduct.annual_interest_rate}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        annual_interest_rate: Number(e.target.value)
                      })
                    }
                  />
                </div>
                <div className="space-y-1">
                  <Label>Max DTI Ratio (%)</Label>
                  <Input
                    type="number"
                    value={editingProduct.max_dti_ratio}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        max_dti_ratio: Number(e.target.value)
                      })
                    }
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Min Principal ($)</Label>
                  <Input
                    type="number"
                    value={editingProduct.min_principal}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        min_principal: Number(e.target.value)
                      })
                    }
                  />
                </div>
                <div className="space-y-1">
                  <Label>Max Principal ($)</Label>
                  <Input
                    type="number"
                    value={editingProduct.max_principal}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        max_principal: Number(e.target.value)
                      })
                    }
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Min Tenure (mo)</Label>
                  <Input
                    type="number"
                    value={editingProduct.min_tenure_months}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        min_tenure_months: Number(e.target.value)
                      })
                    }
                  />
                </div>
                <div className="space-y-1">
                  <Label>Max Tenure (mo)</Label>
                  <Input
                    type="number"
                    value={editingProduct.max_tenure_months}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        max_tenure_months: Number(e.target.value)
                      })
                    }
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-border">
                <Button type="button" variant="ghost" onClick={() => setEditModalOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90">
                  Save Changes
                </Button>
              </div>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};
