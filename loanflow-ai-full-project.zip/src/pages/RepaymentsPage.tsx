import React, { useState } from 'react';
import {
  CalendarDays,
  Search,
  Download,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
  ArrowDown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { toast } from 'sonner';
import { dbStore } from '@/services/dbStore';
import { RepaymentInstallment } from '@/types/loanflow';

export const RepaymentsPage: React.FC = () => {
  const approvedApps = Array.from(dbStore.applications.values()).filter(
    (a) => a.status === 'APPROVED' || a.status === 'DISBURSED'
  );

  const [selectedAppId, setSelectedAppId] = useState<string>(
    approvedApps.length > 0 ? approvedApps[0].id : ''
  );

  const app = dbStore.applications.get(selectedAppId);
  const applicant = app ? dbStore.applicants.get(app.applicant_id) : null;
  const product = app ? dbStore.products.get(app.product_id) : null;
  const schedule: RepaymentInstallment[] = selectedAppId
    ? dbStore.repaymentSchedules.get(selectedAppId) || []
    : [];

  const totalPrincipalPaid = schedule.reduce((s, i) => s + i.principal_component, 0);
  const totalInterestPaid = schedule.reduce((s, i) => s + i.interest_component, 0);
  const totalRepayment = totalPrincipalPaid + totalInterestPaid;
  const finalEndingBalance = schedule.length > 0 ? schedule[schedule.length - 1].outstanding_principal : 0;
  const isReconciled = Math.abs(finalEndingBalance) <= 0.05;

  const handleExportCSV = () => {
    if (schedule.length === 0) {
      toast.error('No schedule data to export.');
      return;
    }

    const headers = 'Installment Number,Due Date,Principal Component,Interest Component,Total Installment,Outstanding Principal\n';
    const rows = schedule
      .map(
        (i) =>
          `${i.installment_number},${i.due_date},${i.principal_component},${i.interest_component},${i.total_installment},${i.outstanding_principal}`
      )
      .join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `repayment_schedule_${app ? app.application_number : selectedAppId}.csv`;
    a.click();
    toast.success('Repayment schedule CSV exported');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <CalendarDays className="w-6 h-6 text-primary" />
            Amortization & Repayment Schedules
          </h1>
          <p className="text-xs text-muted-foreground mt-1">
            Reducing-balance monthly installments with principal/interest amortization and penny-reconciliation validation.
          </p>
        </div>
        <Button
          onClick={handleExportCSV}
          variant="outline"
          disabled={schedule.length === 0}
          className="h-9 gap-1.5 text-xs font-semibold"
        >
          <Download className="w-4 h-4" /> Export CSV Schedule
        </Button>
      </div>

      {/* Select Application Header Bar */}
      <div className="p-4 rounded-xl bg-card border border-border shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <span className="text-xs font-semibold text-muted-foreground whitespace-nowrap">
            Select Approved Loan:
          </span>
          <Select value={selectedAppId} onValueChange={setSelectedAppId}>
            <SelectTrigger className="h-9 w-full sm:w-80 text-xs">
              <SelectValue placeholder="Choose loan application" />
            </SelectTrigger>
            <SelectContent>
              {approvedApps.map((a) => {
                const bor = dbStore.applicants.get(a.applicant_id);
                return (
                  <SelectItem key={a.id} value={a.id}>
                    {a.application_number} - {bor ? `${bor.first_name} ${bor.last_name}` : 'Borrower'} (${a.requested_principal.toLocaleString()})
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        </div>

        {isReconciled ? (
          <Badge className="bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border-none gap-1 py-1 px-3">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Reconciled: Ending Balance $0.00
          </Badge>
        ) : (
          <Badge variant="destructive" className="gap-1 py-1 px-3">
            <AlertCircle className="w-3.5 h-3.5" />
            Reconciliation Mismatch (${finalEndingBalance})
          </Badge>
        )}
      </div>

      {/* Summary KPI Ribbon */}
      {app && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3.5 rounded-xl bg-card border border-border shadow-sm">
            <span className="text-[11px] text-muted-foreground block">Disbursed Principal</span>
            <span className="text-xl font-bold text-foreground mt-0.5 block">
              ${totalPrincipalPaid.toLocaleString()}
            </span>
            <span className="text-[10px] text-muted-foreground">{app.requested_tenure_months} months tenure</span>
          </div>

          <div className="p-3.5 rounded-xl bg-card border border-border shadow-sm">
            <span className="text-[11px] text-muted-foreground block">Total Interest Accrual</span>
            <span className="text-xl font-bold text-amber-600 dark:text-amber-400 mt-0.5 block">
              ${Math.round(totalInterestPaid).toLocaleString()}
            </span>
            <span className="text-[10px] text-muted-foreground">@ {product?.annual_interest_rate}% APR</span>
          </div>

          <div className="p-3.5 rounded-xl bg-card border border-border shadow-sm">
            <span className="text-[11px] text-muted-foreground block">Total Lifetime Repayment</span>
            <span className="text-xl font-bold text-primary mt-0.5 block">
              ${Math.round(totalRepayment).toLocaleString()}
            </span>
            <span className="text-[10px] text-muted-foreground">Principal + Interest</span>
          </div>

          <div className="p-3.5 rounded-xl bg-card border border-border shadow-sm">
            <span className="text-[11px] text-muted-foreground block">Monthly Installment (EMI)</span>
            <span className="text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-0.5 block">
              ${schedule.length > 0 ? schedule[0].total_installment.toLocaleString() : '0'}
            </span>
            <span className="text-[10px] text-muted-foreground">Standard monthly due</span>
          </div>
        </div>
      )}

      {/* Amortization Schedule Table */}
      <div className="rounded-xl bg-card border border-border shadow-sm overflow-hidden">
        <div className="overflow-x-auto w-full">
          <table className="w-full text-left text-xs whitespace-nowrap">
            <thead className="bg-muted/40 border-b border-border text-muted-foreground">
              <tr>
                <th className="py-3 px-4 font-semibold">Period #</th>
                <th className="py-3 px-4 font-semibold">Due Date</th>
                <th className="py-3 px-4 font-semibold">Principal Component</th>
                <th className="py-3 px-4 font-semibold">Interest Component</th>
                <th className="py-3 px-4 font-semibold">Total Installment (EMI)</th>
                <th className="py-3 px-4 font-semibold text-right">Ending Balance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60 font-mono text-[11px]">
              {schedule.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-muted-foreground font-sans text-xs">
                    No approved repayment schedule found for this application.
                  </td>
                </tr>
              ) : (
                schedule.map((inst) => (
                  <tr key={inst.id} className="hover:bg-muted/40 transition-colors">
                    <td className="py-3 px-4 font-semibold text-foreground">
                      #{inst.installment_number}
                    </td>
                    <td className="py-3 px-4 text-muted-foreground font-sans text-xs">{inst.due_date}</td>
                    <td className="py-3 px-4 font-medium text-emerald-600 dark:text-emerald-400">
                      ${inst.principal_component.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-amber-600 dark:text-amber-400">
                      ${inst.interest_component.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 font-bold text-foreground">
                      ${inst.total_installment.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right text-foreground font-medium">
                      ${inst.outstanding_principal.toLocaleString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
