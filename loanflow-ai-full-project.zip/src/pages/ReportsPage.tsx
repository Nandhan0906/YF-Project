import React, { useState } from 'react';
import {
  BarChart3,
  Download,
  Calendar,
  FileSpreadsheet,
  FileText,
  Filter,
  CheckCircle2,
  TrendingUp,
  Percent,
  Layers
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { dbStore } from '@/services/dbStore';

export const ReportsPage: React.FC = () => {
  const summary = dbStore.getDashboardSummary();
  const applications = Array.from(dbStore.applications.values());
  const applicants = Array.from(dbStore.applicants.values());
  const decisions = Array.from(dbStore.decisions.values());
  const products = Array.from(dbStore.products.values());

  const handleExportCSV = () => {
    const headers = 'Application Number,Borrower Name,National ID,Product Name,Principal,Tenure,Status,Created Date\n';
    const rows = applications
      .map((app) => {
        const applicant = dbStore.applicants.get(app.applicant_id);
        const name = applicant ? `"${applicant.first_name} ${applicant.last_name}"` : 'Unknown';
        const natId = applicant ? applicant.national_id : '';
        const prod = dbStore.products.get(app.product_id);
        const prodName = prod ? `"${prod.name}"` : 'Loan';
        return `${app.application_number},${name},${natId},${prodName},${app.requested_principal},${app.requested_tenure_months},${app.status},${app.created_at.slice(0, 10)}`;
      })
      .join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `loanflow_origination_report_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    toast.success('Applications portfolio CSV exported');
  };

  const handleExportJSON = () => {
    const data = {
      generated_at: new Date().toISOString(),
      summary,
      applications: applications.map(a => {
        const d = Array.from(dbStore.decisions.values()).reverse().find(dec => dec.application_id === a.id);
        const aff = Array.from(dbStore.affordabilityChecks.values()).reverse().find(c => c.application_id === a.id);
        return {
          ...a,
          decision: d,
          affordability: aff
        };
      })
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `loanflow_portfolio_dump_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    toast.success('Complete portfolio JSON package exported');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-primary" />
            Executive Portfolio Analytics & Reporting
          </h1>
          <p className="text-xs text-muted-foreground mt-1">
            Aggregate portfolio performance, risk concentrations, and structured data exports.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button onClick={handleExportCSV} variant="outline" className="h-9 gap-1.5 text-xs font-semibold">
            <Download className="w-4 h-4" /> Export CSV Report
          </Button>
          <Button onClick={handleExportJSON} className="bg-primary text-primary-foreground hover:bg-primary/90 h-9 gap-1.5 text-xs font-semibold">
            <Download className="w-4 h-4" /> Export Full JSON
          </Button>
        </div>
      </div>

      {/* Metric Highlights */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-card border border-border shadow-sm">
          <span className="text-[11px] text-muted-foreground block">Origination Volume</span>
          <span className="text-2xl font-bold text-foreground mt-1 block">
            ${(summary.total_loan_amount_requested / 1000000).toFixed(2)}M
          </span>
          <span className="text-[10px] text-emerald-600 block mt-0.5">Across all 4 active products</span>
        </div>

        <div className="p-4 rounded-xl bg-card border border-border shadow-sm">
          <span className="text-[11px] text-muted-foreground block">Committed Capital</span>
          <span className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 mt-1 block">
            ${(summary.total_approved_loan_amount / 1000000).toFixed(2)}M
          </span>
          <span className="text-[10px] text-muted-foreground block mt-0.5">Approved & Disbursed</span>
        </div>

        <div className="p-4 rounded-xl bg-card border border-border shadow-sm">
          <span className="text-[11px] text-muted-foreground block">System Approval Rate</span>
          <span className="text-2xl font-bold text-primary mt-1 block">
            {summary.total_loan_applications > 0
              ? `${Math.round((summary.approved_applications / summary.total_loan_applications) * 100)}%`
              : '0%'}
          </span>
          <span className="text-[10px] text-muted-foreground block mt-0.5">Rule-engine evaluated</span>
        </div>

        <div className="p-4 rounded-xl bg-card border border-border shadow-sm">
          <span className="text-[11px] text-muted-foreground block">Avg Portfolio DTI</span>
          <span className="text-2xl font-bold text-purple-600 mt-1 block">
            {summary.average_dti_ratio}%
          </span>
          <span className="text-[10px] text-emerald-600 block mt-0.5">Within prime benchmark</span>
        </div>
      </div>

      {/* Product Breakdown Performance Table */}
      <div className="p-5 rounded-xl bg-card border border-border shadow-sm space-y-3">
        <h3 className="font-bold text-sm text-foreground">Loan Product Origination Breakdown</h3>
        <div className="overflow-x-auto w-full">
          <table className="w-full text-left text-xs whitespace-nowrap">
            <thead className="bg-muted/40 border-b border-border text-muted-foreground">
              <tr>
                <th className="py-2.5 px-3">Product Name</th>
                <th className="py-2.5 px-3">Interest Rate</th>
                <th className="py-2.5 px-3">Tenure Limits</th>
                <th className="py-2.5 px-3">Max Allowed DTI</th>
                <th className="py-2.5 px-3">Applications</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {products.map((prod) => {
                const count = summary.product_distribution[prod.name] || 0;
                return (
                  <tr key={prod.id}>
                    <td className="py-3 px-3 font-semibold text-foreground">{prod.name}</td>
                    <td className="py-3 px-3">{prod.annual_interest_rate}% APR</td>
                    <td className="py-3 px-3 text-muted-foreground">{prod.min_tenure_months} - {prod.max_tenure_months} mo</td>
                    <td className="py-3 px-3">{prod.max_dti_ratio}%</td>
                    <td className="py-3 px-3 font-bold text-primary">{count}</td>
                    <td className="py-3 px-3">
                      <Badge className="bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border-none">
                        {prod.status}
                      </Badge>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
