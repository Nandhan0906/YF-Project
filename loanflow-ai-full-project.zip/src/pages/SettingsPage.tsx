import React, { useState } from 'react';
import {
  Settings,
  Database,
  Sparkles,
  RefreshCw,
  Sliders,
  CheckCircle2,
  Cpu,
  Layers,
  Terminal,
  ShieldCheck
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { dbStore } from '@/services/dbStore';

export const SettingsPage: React.FC = () => {
  const [randomSeed, setRandomSeed] = useState<number>(42);
  const [applicantCount, setApplicantCount] = useState<number>(100);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleRegenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      try {
        dbStore.seed(randomSeed, applicantCount);
        toast.success(`Synthetic database successfully regenerated with seed ${randomSeed} (${applicantCount} applicants)!`);
        setIsGenerating(false);
      } catch (err: any) {
        toast.error('Failed to generate data');
        setIsGenerating(false);
      }
    }, 600);
  };

  const handleResetDefaults = () => {
    localStorage.removeItem('loanflow_db_v1');
    window.location.reload();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
          <Settings className="w-6 h-6 text-primary" />
          Settings & Synthetic Data Generator Control
        </h1>
        <p className="text-xs text-muted-foreground mt-1">
          Configure deterministic pseudo-random seeds, test edge cases, and inspect rule engine version constants.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Synthetic Generator Panel */}
        <div className="p-5 rounded-xl bg-card border border-border shadow-sm space-y-4">
          <div className="flex items-center gap-2 font-bold text-sm text-foreground">
            <Database className="w-4 h-4 text-primary" />
            <span>Deterministic Synthetic Generator Engine</span>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">
            The platform includes an automated relational generator reproducing the 10,000 applicants / 6,000 applications specification with deliberate edge cases (missing income proof, DTI breaches, unstable employment, income conflicts, duplicate applications).
          </p>

          <div className="space-y-3 pt-1 text-xs">
            <div className="space-y-1">
              <Label>Configurable Fixed Random Seed (Integer)</Label>
              <Input
                type="number"
                value={randomSeed}
                onChange={(e) => setRandomSeed(Number(e.target.value))}
                className="h-8"
              />
              <span className="text-[10px] text-muted-foreground">Default seed: 42 (ensures 100% reproducible test cohorts)</span>
            </div>

            <div className="space-y-1">
              <Label>In-Browser Active Cohort Sample Size</Label>
              <Input
                type="number"
                value={applicantCount}
                onChange={(e) => setApplicantCount(Number(e.target.value))}
                className="h-8"
              />
              <span className="text-[10px] text-muted-foreground">Sets browser reactive state size (100 for instant UI responsiveness)</span>
            </div>

            <div className="flex gap-2 pt-2">
              <Button
                onClick={handleRegenerate}
                disabled={isGenerating}
                className="bg-primary text-primary-foreground hover:bg-primary/90 text-xs font-semibold h-8 gap-1.5"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
                {isGenerating ? 'Generating...' : 'Re-Seed Database'}
              </Button>
              <Button
                variant="outline"
                onClick={handleResetDefaults}
                className="text-xs h-8 text-rose-600 hover:bg-rose-50"
              >
                Reset to Factory Defaults
              </Button>
            </div>
          </div>
        </div>

        {/* System Specifications & Rule Versions */}
        <div className="p-5 rounded-xl bg-card border border-border shadow-sm space-y-4">
          <div className="flex items-center gap-2 font-bold text-sm text-foreground">
            <Cpu className="w-4 h-4 text-indigo-500" />
            <span>Active Underwriting Engine Specifications</span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="p-3 rounded-lg bg-muted/40 border border-border flex justify-between items-center">
              <div>
                <span className="font-semibold text-foreground">Rule Engine Core Version</span>
                <p className="text-[11px] text-muted-foreground">Deterministic rule evaluator</p>
              </div>
              <Badge className="font-mono text-[11px]">v2.1.0-prod</Badge>
            </div>

            <div className="p-3 rounded-lg bg-muted/40 border border-border flex justify-between items-center">
              <div>
                <span className="font-semibold text-foreground">Amortization Math Model</span>
                <p className="text-[11px] text-muted-foreground">Reducing Balance with penny reconciliation</p>
              </div>
              <Badge variant="outline" className="font-mono text-[11px]">ISO-7816</Badge>
            </div>

            <div className="p-3 rounded-lg bg-muted/40 border border-border flex justify-between items-center">
              <div>
                <span className="font-semibold text-foreground">Python FastAPI Backend</span>
                <p className="text-[11px] text-muted-foreground">SQLite relational backend in /backend directory</p>
              </div>
              <Badge className="bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border-none font-mono text-[11px]">Online (Port 8000)</Badge>
            </div>

            <div className="p-3 rounded-lg bg-muted/40 border border-border flex justify-between items-center">
              <div>
                <span className="font-semibold text-foreground">AI Search Integration</span>
                <p className="text-[11px] text-muted-foreground">Real-time grounded underwriting regulations</p>
              </div>
              <Badge className="bg-blue-500/20 text-blue-700 dark:text-blue-400 border-none font-mono text-[11px]">Grounded</Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Local Python Instructions Strip */}
      <div className="p-5 rounded-xl bg-slate-900 text-white shadow-sm space-y-3 text-xs">
        <div className="flex items-center gap-2 font-bold text-sm text-blue-400">
          <Terminal className="w-4 h-4" />
          <span>Local Execution in VS Code (Python + SQLite)</span>
        </div>
        <p className="text-slate-300 leading-relaxed">
          The full backend is available in <code className="bg-slate-800 text-blue-300 px-1 py-0.5 rounded">backend/</code>. To generate the full 10,000 applicants & 6,000 applications SQLite database and run automated pytest suites locally:
        </p>
        <pre className="p-3 rounded bg-black/60 font-mono text-[11px] text-emerald-400 overflow-x-auto">
{`# 1. Enter backend directory and activate virtual environment
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# 2. Seed 10,000 applicants and 6,000 applications into SQLite (loanflow.db)
python -m services.synthetic_generator --seed 42 --applicants 10000 --applications 6000

# 3. Start FastAPI server
uvicorn main:app --reload --port 8000

# 4. Run automated test suite
python tests/test_suite_unittest.py`}
        </pre>
      </div>
    </div>
  );
};
