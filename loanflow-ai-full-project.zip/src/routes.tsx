import React from 'react';
import type { ReactNode } from 'react';
import { DashboardPage } from '@/pages/DashboardPage';
import { ApplicantsPage } from '@/pages/ApplicantsPage';
import { ApplicationsPage } from '@/pages/ApplicationsPage';
import { ProductsPage } from '@/pages/ProductsPage';
import { AffordabilityPage } from '@/pages/AffordabilityPage';
import { DecisionsPage } from '@/pages/DecisionsPage';
import { DocumentsPage } from '@/pages/DocumentsPage';
import { RepaymentsPage } from '@/pages/RepaymentsPage';
import { ExceptionsPage } from '@/pages/ExceptionsPage';
import { AuditLogsPage } from '@/pages/AuditLogsPage';
import { ReportsPage } from '@/pages/ReportsPage';
import { SettingsPage } from '@/pages/SettingsPage';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  public?: boolean;
}

export const routes: RouteConfig[] = [
  {
    name: 'Dashboard',
    path: '/',
    element: <DashboardPage />,
    public: true,
  },
  {
    name: 'Applicants',
    path: '/applicants',
    element: <ApplicantsPage />,
    public: true,
  },
  {
    name: 'Loan Applications',
    path: '/applications',
    element: <ApplicationsPage />,
    public: true,
  },
  {
    name: 'Loan Products',
    path: '/products',
    element: <ProductsPage />,
    public: true,
  },
  {
    name: 'Affordability Analysis',
    path: '/affordability',
    element: <AffordabilityPage />,
    public: true,
  },
  {
    name: 'Loan Decisions',
    path: '/decisions',
    element: <DecisionsPage />,
    public: true,
  },
  {
    name: 'Document Verification',
    path: '/documents',
    element: <DocumentsPage />,
    public: true,
  },
  {
    name: 'Repayment Schedules',
    path: '/repayments',
    element: <RepaymentsPage />,
    public: true,
  },
  {
    name: 'Exception Management',
    path: '/exceptions',
    element: <ExceptionsPage />,
    public: true,
  },
  {
    name: 'Audit Logs',
    path: '/audit-logs',
    element: <AuditLogsPage />,
    public: true,
  },
  {
    name: 'Reports & Analytics',
    path: '/reports',
    element: <ReportsPage />,
    public: true,
  },
  {
    name: 'Settings & System Seed',
    path: '/settings',
    element: <SettingsPage />,
    public: true,
  }
];
