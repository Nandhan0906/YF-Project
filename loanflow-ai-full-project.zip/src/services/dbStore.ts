import {
  Applicant,
  Employment,
  IncomeRecord,
  CreditFacility,
  LoanProduct,
  LoanApplication,
  DocumentRecord,
  AffordabilityCheck,
  Decision,
  RepaymentInstallment,
  LoanEvent,
  IssueRecord,
  DashboardSummary,
  ApplicationStatus,
  DecisionOutcome
} from '../types/loanflow';

const STORAGE_KEY_PREFIX = 'loanflow_v1_';

export const DEFAULT_LOAN_PRODUCTS: LoanProduct[] = [
  {
    id: 'prod-personal-01',
    code: 'PERS_LOAN_01',
    name: 'Standard Personal Loan',
    description: 'Flexible unsecured installment loan for debt consolidation or personal expenses.',
    min_principal: 5000,
    max_principal: 50000,
    min_tenure_months: 12,
    max_tenure_months: 60,
    annual_interest_rate: 8.75,
    min_income_requirement: 2500,
    max_dti_ratio: 45.0,
    required_employment_status: 'PERMANENT',
    status: 'ACTIVE',
    created_at: '2026-01-01T00:00:00Z'
  },
  {
    id: 'prod-auto-01',
    code: 'AUTO_LOAN_01',
    name: 'Prime Auto Financing',
    description: 'Secured vehicle financing loan for new and certified pre-owned automobiles.',
    min_principal: 10000,
    max_principal: 85000,
    min_tenure_months: 24,
    max_tenure_months: 84,
    annual_interest_rate: 6.25,
    min_income_requirement: 3000,
    max_dti_ratio: 50.0,
    required_employment_status: 'PERMANENT',
    status: 'ACTIVE',
    created_at: '2026-01-01T00:00:00Z'
  },
  {
    id: 'prod-mortgage-01',
    code: 'MORT_LOAN_01',
    name: 'Residential Home Mortgage',
    description: 'First-lien residential real estate purchase and refinancing mortgage.',
    min_principal: 100000,
    max_principal: 1200000,
    min_tenure_months: 120,
    max_tenure_months: 360,
    annual_interest_rate: 5.85,
    min_income_requirement: 5500,
    max_dti_ratio: 43.0,
    required_employment_status: 'PERMANENT',
    status: 'ACTIVE',
    created_at: '2026-01-01T00:00:00Z'
  },
  {
    id: 'prod-sme-01',
    code: 'SME_MICRO_01',
    name: 'SME Working Capital Loan',
    description: 'Short-to-medium term growth financing for small business owners and contractors.',
    min_principal: 15000,
    max_principal: 250000,
    min_tenure_months: 12,
    max_tenure_months: 72,
    annual_interest_rate: 10.50,
    min_income_requirement: 4000,
    max_dti_ratio: 55.0,
    required_employment_status: 'SELF_EMPLOYED',
    status: 'ACTIVE',
    created_at: '2026-01-01T00:00:00Z'
  }
];

export function calculateReducingBalanceEMI(principal: number, annualRatePct: number, tenureMonths: number): number {
  if (principal <= 0 || tenureMonths <= 0) return 0;
  if (annualRatePct <= 0) return Number((principal / tenureMonths).toFixed(2));
  const monthlyRate = (annualRatePct / 100) / 12;
  const factor = Math.pow(1 + monthlyRate, tenureMonths);
  const emi = (principal * monthlyRate * factor) / (factor - 1);
  return Number(emi.toFixed(2));
}

export const calculateReducingBalanceEmi = calculateReducingBalanceEMI;

export function calculateAffordability(
  monthlyIncome: number,
  existingMonthlyDebt: number,
  principal: number,
  annualRatePct: number,
  tenureMonths: number,
  maxDtiPct: number = 50.0
) {
  const safeIncome = Math.max(0, monthlyIncome);
  const safeDebt = Math.max(0, existingMonthlyDebt);
  const safePrincipal = Math.max(0, principal);
  const safeTenure = Math.max(1, tenureMonths);
  const safeRate = Math.max(0, annualRatePct);

  const proposedEmi = calculateReducingBalanceEMI(safePrincipal, safeRate, safeTenure);
  const totalMonthlyDebt = Number((safeDebt + proposedEmi).toFixed(2));

  let dtiRatio = 999.99;
  let disposableIncome = -totalMonthlyDebt;
  let isAffordable = false;

  if (safeIncome > 0) {
    dtiRatio = Number(((totalMonthlyDebt / safeIncome) * 100).toFixed(2));
    disposableIncome = Number((safeIncome - totalMonthlyDebt).toFixed(2));
    isAffordable = dtiRatio <= maxDtiPct && disposableIncome > 0;
  }

  // Max affordable principal
  const maxAllowableDebt = safeIncome * (maxDtiPct / 100);
  const maxAllowableEmi = Math.max(0, maxAllowableDebt - safeDebt);
  let maxAffordablePrincipal = 0;
  if (safeRate > 0 && maxAllowableEmi > 0) {
    const monthlyRate = (safeRate / 100) / 12;
    const factor = Math.pow(1 + monthlyRate, safeTenure);
    maxAffordablePrincipal = Number(((maxAllowableEmi * (factor - 1)) / (monthlyRate * factor)).toFixed(2));
  } else if (maxAllowableEmi > 0) {
    maxAffordablePrincipal = Number((maxAllowableEmi * safeTenure).toFixed(2));
  }

  const formulaExplanation = `EMI reducing-balance: P=$${safePrincipal.toLocaleString()}, APR=${safeRate}%, Tenure=${safeTenure}m => Proposed EMI=$${proposedEmi.toLocaleString()}. DTI = ($${safeDebt.toLocaleString()} + $${proposedEmi.toLocaleString()}) / $${safeIncome.toLocaleString()} = ${dtiRatio}%. Policy Max=${maxDtiPct}%.`;

  return {
    monthly_income: safeIncome,
    existing_monthly_debt: safeDebt,
    proposed_emi: proposedEmi,
    total_monthly_debt: totalMonthlyDebt,
    dti_ratio: dtiRatio,
    disposable_income: disposableIncome,
    is_affordable: isAffordable,
    formula_explanation: formulaExplanation,
    notes: formulaExplanation,
    max_affordable_principal: maxAffordablePrincipal
  };
}

export function evaluateLoanDecision(
  applicant: Applicant,
  product: LoanProduct,
  application: { requested_principal: number; requested_tenure_months: number },
  affordability: ReturnType<typeof calculateAffordability>,
  documents: DocumentRecord[],
  issues: IssueRecord[],
  employments: Employment[]
) {
  const reasonCodes: string[] = [];
  const explanations: string[] = [];
  const ruleEvaluations: { rule: string; passed: boolean; details: string }[] = [];

  // 1. Principal limits
  if (application.requested_principal < product.min_principal) {
    reasonCodes.push('RULE_PRINCIPAL_BELOW_MIN');
    explanations.push(`Requested amount ($${application.requested_principal.toLocaleString()}) is below product minimum ($${product.min_principal.toLocaleString()}).`);
    ruleEvaluations.push({ rule: 'MIN_PRINCIPAL', passed: false, details: `$${application.requested_principal} < $${product.min_principal}` });
  } else if (application.requested_principal > product.max_principal) {
    reasonCodes.push('RULE_PRINCIPAL_EXCEEDS_MAX');
    explanations.push(`Requested amount ($${application.requested_principal.toLocaleString()}) exceeds product limit ($${product.max_principal.toLocaleString()}).`);
    ruleEvaluations.push({ rule: 'MAX_PRINCIPAL', passed: false, details: `$${application.requested_principal} > $${product.max_principal}` });
  } else {
    ruleEvaluations.push({ rule: 'PRINCIPAL_BOUNDS', passed: true, details: `$${product.min_principal} <= $${application.requested_principal} <= $${product.max_principal}` });
  }

  // 2. Tenure limits
  if (application.requested_tenure_months < product.min_tenure_months || application.requested_tenure_months > product.max_tenure_months) {
    reasonCodes.push('RULE_TENURE_OUT_OF_BOUNDS');
    explanations.push(`Requested tenure (${application.requested_tenure_months}m) outside product range (${product.min_tenure_months}-${product.max_tenure_months}m).`);
    ruleEvaluations.push({ rule: 'TENURE_BOUNDS', passed: false, details: `${application.requested_tenure_months}m not in [${product.min_tenure_months}, ${product.max_tenure_months}]` });
  } else {
    ruleEvaluations.push({ rule: 'TENURE_BOUNDS', passed: true, details: `${product.min_tenure_months}m <= ${application.requested_tenure_months}m <= ${product.max_tenure_months}m` });
  }

  // 3. Income
  if (affordability.monthly_income < product.min_income_requirement) {
    reasonCodes.push('RULE_INSUFFICIENT_INCOME');
    explanations.push(`Monthly income ($${affordability.monthly_income.toLocaleString()}) does not meet product minimum ($${product.min_income_requirement.toLocaleString()}).`);
    ruleEvaluations.push({ rule: 'MIN_INCOME', passed: false, details: `$${affordability.monthly_income} < $${product.min_income_requirement}` });
  } else {
    ruleEvaluations.push({ rule: 'MIN_INCOME', passed: true, details: `$${affordability.monthly_income} >= $${product.min_income_requirement}` });
  }

  // 4. DTI & Disposable income
  if (affordability.dti_ratio > product.max_dti_ratio) {
    reasonCodes.push('RULE_DTI_EXCEEDED');
    explanations.push(`Debt-to-Income (${affordability.dti_ratio}%) exceeds max threshold (${product.max_dti_ratio}%).`);
    ruleEvaluations.push({ rule: 'MAX_DTI', passed: false, details: `${affordability.dti_ratio}% > ${product.max_dti_ratio}%` });
  } else if (affordability.dti_ratio >= product.max_dti_ratio - 5.0) {
    reasonCodes.push('RULE_BORDERLINE_DTI');
    explanations.push(`DTI (${affordability.dti_ratio}%) is borderline within 5% buffer of threshold (${product.max_dti_ratio}%).`);
    ruleEvaluations.push({ rule: 'BORDERLINE_DTI', passed: false, details: `${affordability.dti_ratio}% in [${product.max_dti_ratio - 5}%, ${product.max_dti_ratio}%]` });
  } else {
    ruleEvaluations.push({ rule: 'DTI_RATIO', passed: true, details: `${affordability.dti_ratio}% <= ${product.max_dti_ratio}%` });
  }

  if (affordability.disposable_income <= 0) {
    reasonCodes.push('RULE_NEGATIVE_DISPOSABLE_INCOME');
    explanations.push(`Net disposable income ($${affordability.disposable_income.toLocaleString()}) is zero or negative.`);
    ruleEvaluations.push({ rule: 'DISPOSABLE_INCOME', passed: false, details: `$${affordability.disposable_income} <= 0` });
  } else {
    ruleEvaluations.push({ rule: 'DISPOSABLE_INCOME', passed: true, details: `$${affordability.disposable_income} > 0` });
  }

  // 5. Employment stability
  const primaryEmp = employments.find(e => e.is_current);
  const empTenure = primaryEmp ? primaryEmp.tenure_months : 0;
  const empType = primaryEmp ? primaryEmp.employment_type : 'UNEMPLOYED';

  if (empType === 'UNEMPLOYED') {
    reasonCodes.push('RULE_UNEMPLOYED');
    explanations.push('Applicant has no active employment records.');
    ruleEvaluations.push({ rule: 'EMPLOYMENT_STATUS', passed: false, details: 'Unemployed' });
  } else if (product.required_employment_status === 'PERMANENT' && empType !== 'PERMANENT' && empType !== 'CONTRACT') {
    reasonCodes.push('RULE_EMPLOYMENT_TYPE_MISMATCH');
    explanations.push(`Employment type '${empType}' does not satisfy required '${product.required_employment_status}'.`);
    ruleEvaluations.push({ rule: 'EMPLOYMENT_STATUS', passed: false, details: `${empType} != ${product.required_employment_status}` });
  } else {
    ruleEvaluations.push({ rule: 'EMPLOYMENT_STATUS', passed: true, details: `Type: ${empType}` });
  }

  if (empTenure < 6 && empType !== 'UNEMPLOYED') {
    reasonCodes.push('RULE_UNSTABLE_EMPLOYMENT');
    explanations.push(`Current employment tenure (${empTenure}m) is under 6 months.`);
    ruleEvaluations.push({ rule: 'EMPLOYMENT_TENURE', passed: false, details: `${empTenure}m < 6m` });
  } else {
    ruleEvaluations.push({ rule: 'EMPLOYMENT_TENURE', passed: true, details: `${empTenure}m >= 6m` });
  }

  // 6. Documents
  const mandatoryTypes = ['IDENTITY_PROOF', 'INCOME_PROOF', 'BANK_STATEMENTS'];
  const docMap = new Map(documents.map(d => [d.document_type, d.status]));
  const missing = mandatoryTypes.filter(t => !docMap.has(t as any) || docMap.get(t as any) === 'MISSING');
  const rejected = mandatoryTypes.filter(t => docMap.get(t as any) === 'REJECTED');
  const pending = mandatoryTypes.filter(t => docMap.get(t as any) === 'PENDING');

  if (missing.length > 0) {
    reasonCodes.push('RULE_MISSING_DOCUMENTS');
    explanations.push(`Mandatory documents missing: ${missing.join(', ')}.`);
    ruleEvaluations.push({ rule: 'DOCS_PRESENT', passed: false, details: `Missing: ${missing.join(', ')}` });
  }
  if (rejected.length > 0) {
    reasonCodes.push('RULE_REJECTED_DOCUMENTS');
    explanations.push(`Mandatory documents rejected: ${rejected.join(', ')}.`);
    ruleEvaluations.push({ rule: 'DOCS_VERIFIED', passed: false, details: `Rejected: ${rejected.join(', ')}` });
  }
  if (pending.length > 0) {
    reasonCodes.push('RULE_PENDING_DOCUMENTS');
    explanations.push(`Documents awaiting underwriter verification: ${pending.join(', ')}.`);
    ruleEvaluations.push({ rule: 'DOCS_PENDING', passed: false, details: `Pending: ${pending.join(', ')}` });
  }

  // 7. Check deliberate issues
  const hasIncomeConflict = issues.some(i => i.issue_type === 'INCOME_CONFLICT' && i.resolution_status === 'OPEN');
  const hasDuplicateApp = issues.some(i => i.issue_type === 'DUPLICATE_APPLICATION' && i.resolution_status === 'OPEN');

  if (hasIncomeConflict) {
    reasonCodes.push('RULE_INCOME_CONFLICT');
    explanations.push('Stated income conflicts with verified employer/tax document records.');
    ruleEvaluations.push({ rule: 'INCOME_CONSISTENCY', passed: false, details: 'Discrepancy detected' });
  }
  if (hasDuplicateApp) {
    reasonCodes.push('RULE_DUPLICATE_APPLICATION');
    explanations.push('Duplicate concurrent application detected within 30 days.');
    ruleEvaluations.push({ rule: 'DUPLICATE_CHECK', passed: false, details: 'Duplicate submission' });
  }

  // Decision outcome resolution
  const hardRejects = new Set([
    'RULE_PRINCIPAL_BELOW_MIN',
    'RULE_PRINCIPAL_EXCEEDS_MAX',
    'RULE_TENURE_OUT_OF_BOUNDS',
    'RULE_INSUFFICIENT_INCOME',
    'RULE_DTI_EXCEEDED',
    'RULE_NEGATIVE_DISPOSABLE_INCOME',
    'RULE_UNEMPLOYED',
    'RULE_REJECTED_DOCUMENTS'
  ]);

  const manualReviews = new Set([
    'RULE_BORDERLINE_DTI',
    'RULE_UNSTABLE_EMPLOYMENT',
    'RULE_MISSING_DOCUMENTS',
    'RULE_PENDING_DOCUMENTS',
    'RULE_INCOME_CONFLICT',
    'RULE_DUPLICATE_APPLICATION'
  ]);

  let outcome: DecisionOutcome = 'APPROVED';
  let finalExplanation = '';

  const matchedRejects = reasonCodes.filter(r => hardRejects.has(r));
  const matchedReviews = reasonCodes.filter(r => manualReviews.has(r));

  if (matchedRejects.length > 0) {
    outcome = 'REJECTED';
    finalExplanation = `Application rejected due to business constraints: ${explanations.join(' ')}`;
  } else if (matchedReviews.length > 0) {
    outcome = 'MANUAL_REVIEW';
    finalExplanation = `Routed to Underwriter Manual Review: ${explanations.join(' ')}`;
  } else {
    outcome = 'APPROVED';
    reasonCodes.push('RULE_ALL_CRITERIA_SATISFIED');
    finalExplanation = 'Applicant satisfies all credit, affordability, employment, and verification criteria.';
  }

  const inputSnapshot = {
    applicant_id: applicant.id,
    credit_score: applicant.credit_score,
    monthly_income: affordability.monthly_income,
    existing_debt: affordability.existing_monthly_debt,
    proposed_emi: affordability.proposed_emi,
    dti_ratio: affordability.dti_ratio,
    disposable_income: affordability.disposable_income,
    product_code: product.code,
    requested_principal: application.requested_principal,
    requested_tenure_months: application.requested_tenure_months
  };

  return {
    outcome,
    rule_version: '2.1.0-FINTECH',
    reason_codes: reasonCodes,
    explanation: finalExplanation,
    rule_evaluations: ruleEvaluations,
    input_snapshot: inputSnapshot
  };
}

export function generateRepaymentSchedule(
  applicationId: string,
  principal: number,
  annualInterestRate: number,
  tenureMonths: number,
  startDateStr?: string
) {
  if (principal <= 0 || tenureMonths <= 0) throw new Error('Invalid principal or tenure');
  const emi = calculateReducingBalanceEMI(principal, annualInterestRate, tenureMonths);
  const monthlyRate = (annualInterestRate / 100) / 12;

  let currentBalance = principal;
  const installments: RepaymentInstallment[] = [];
  const baseDate = startDateStr ? new Date(startDateStr) : new Date(Date.now() + 30 * 86400000);

  let totalPrincipalPaid = 0;
  let totalInterestPaid = 0;

  for (let i = 1; i <= tenureMonths; i++) {
    const interestComp = Number((currentBalance * monthlyRate).toFixed(2));
    let principalComp = 0;
    let endingBalance = 0;
    let installmentAmount = 0;

    if (i === tenureMonths) {
      principalComp = Number(currentBalance.toFixed(2));
      endingBalance = 0;
      installmentAmount = Number((principalComp + interestComp).toFixed(2));
    } else {
      principalComp = Number((emi - interestComp).toFixed(2));
      if (principalComp > currentBalance) principalComp = Number(currentBalance.toFixed(2));
      endingBalance = Number((currentBalance - principalComp).toFixed(2));
      installmentAmount = Number((principalComp + interestComp).toFixed(2));
    }

    const dueDate = new Date(baseDate.getTime() + (i - 1) * 30 * 86400000).toISOString().split('T')[0];
    totalPrincipalPaid += principalComp;
    totalInterestPaid += interestComp;

    installments.push({
      id: `rep-${applicationId}-${String(i).padStart(3, '0')}`,
      application_id: applicationId,
      installment_number: i,
      due_date: dueDate,
      principal_component: principalComp,
      interest_component: interestComp,
      total_installment: installmentAmount,
      outstanding_principal: endingBalance,
      payment_status: 'PENDING'
    });

    currentBalance = endingBalance;
  }

  totalPrincipalPaid = Number(totalPrincipalPaid.toFixed(2));
  totalInterestPaid = Number(totalInterestPaid.toFixed(2));
  const diff = Math.abs(totalPrincipalPaid - principal);

  return {
    application_id: applicationId,
    total_principal: totalPrincipalPaid,
    total_interest: totalInterestPaid,
    total_repayment: Number((totalPrincipalPaid + totalInterestPaid).toFixed(2)),
    reconciliation_status: diff < 0.05 ? 'RECONCILED' : 'RECONCILIATION_FAILED',
    installments
  };
}

// In-Memory Database Store with LocalStorage synchronization
class LoanFlowDatabase {
  applicants: Map<string, Applicant> = new Map();
  employments: Map<string, Employment> = new Map();
  incomes: Map<string, IncomeRecord> = new Map();
  creditFacilities: Map<string, CreditFacility> = new Map();
  products: Map<string, LoanProduct> = new Map();
  applications: Map<string, LoanApplication> = new Map();
  documents: Map<string, DocumentRecord> = new Map();
  affordabilityChecks: Map<string, AffordabilityCheck> = new Map();
  decisions: Map<string, Decision> = new Map();
  repaymentSchedules: Map<string, RepaymentInstallment[]> = new Map();
  events: LoanEvent[] = [];
  issues: Map<string, IssueRecord> = new Map();
  initialized: boolean = false;
  randomSeed: number = 42;

  constructor() {
    this.init();
  }

  init(forceReseed: boolean = false, seed: number = 42) {
    this.randomSeed = seed;
    const stored = localStorage.getItem(STORAGE_KEY_PREFIX + 'initialized');
    if (stored && !forceReseed) {
      try {
        this.loadFromStorage();
        this.initialized = true;
        return;
      } catch (err) {
        console.warn('Failed to load from storage, reseeding...', err);
      }
    }

    this.seedInitialDataset(seed);
    this.saveToStorage();
    this.initialized = true;
  }

  seed(randomSeed: number = 42, count: number = 100) {
    this.seedInitialDataset(randomSeed);
    this.saveToStorage();
  }

  seedInitialDataset(seed: number = 42) {
    this.applicants.clear();
    this.employments.clear();
    this.incomes.clear();
    this.creditFacilities.clear();
    this.products.clear();
    this.applications.clear();
    this.documents.clear();
    this.affordabilityChecks.clear();
    this.decisions.clear();
    this.repaymentSchedules.clear();
    this.events = [];
    this.issues.clear();

    // 1. Seed Products
    DEFAULT_LOAN_PRODUCTS.forEach(p => this.products.set(p.id, { ...p }));

    // Deterministic Pseudo-Random Generator (Linear Congruential)
    let s = seed;
    const nextRandom = () => {
      s = (s * 9301 + 49297) % 233280;
      return s / 233280;
    };

    const firstNames = ['James', 'Mary', 'Robert', 'Patricia', 'John', 'Jennifer', 'Michael', 'Linda', 'David', 'Elizabeth', 'William', 'Barbara', 'Richard', 'Susan', 'Joseph', 'Sarah', 'Thomas', 'Karen', 'Charles', 'Lisa', 'Daniel', 'Nancy', 'Matthew', 'Betty', 'Anthony', 'Margaret', 'Donald', 'Sandra', 'Steven', 'Ashley', 'Paul', 'Kimberly', 'Andrew', 'Emily', 'Joshua', 'Donna', 'Kevin', 'Michelle', 'Brian', 'Carol', 'George', 'Amanda', 'Edward', 'Melissa'];
    const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez', 'Hernandez', 'Lopez', 'Gonzalez', 'Wilson', 'Anderson', 'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin', 'Lee', 'Perez', 'Thompson', 'White', 'Harris', 'Sanchez', 'Clark', 'Ramirez', 'Lewis', 'Robinson', 'Walker', 'Young', 'Allen', 'King', 'Wright', 'Scott', 'Torres', 'Nguyen', 'Hill', 'Flores'];
    const cities = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix', 'Philadelphia', 'San Antonio', 'San Diego', 'Dallas', 'San Jose', 'Austin', 'Seattle', 'Denver', 'Boston', 'Charlotte'];
    const employers = ['Apex Global Logistics', 'Horizon Financial', 'Vertex Tech Solutions', 'Omni Health Systems', 'Pinnacle Retail Corp', 'Quantum Dynamics', 'Vanguard Engineering', 'Starlight Media', 'Nexus Biotech', 'Sterling Manufacturing'];
    const jobTitles = ['Senior Software Engineer', 'Operations Manager', 'Financial Analyst', 'Registered Nurse', 'Account Executive', 'Marketing Specialist', 'Project Manager', 'HR Generalist', 'Data Analyst', 'Mechanical Engineer'];

    // Generate initial realistic applicant base (120 rich records for fast browser interaction + pagination scale)
    const applicantCount = 120;
    const applicationCount = 90;

    for (let i = 1; i <= applicantCount; i++) {
      const appId = `app-${String(i).padStart(6, '0')}`;
      const fn = firstNames[Math.floor(nextRandom() * firstNames.length)];
      const ln = lastNames[Math.floor(nextRandom() * lastNames.length)];
      const natId = `NAT-${String(1000000 + i)}`;
      const email = `${fn.toLowerCase()}.${ln.toLowerCase()}.${i}@example.com`;
      const phone = `+1-555-${String(Math.floor(nextRandom() * 900) + 100)}-${String(Math.floor(nextRandom() * 9000) + 1000)}`;
      const birthYear = Math.floor(nextRandom() * 35) + 1968;
      const dob = `${birthYear}-${String(Math.floor(nextRandom() * 12) + 1).padStart(2, '0')}-${String(Math.floor(nextRandom() * 28) + 1).padStart(2, '0')}`;
      const city = cities[Math.floor(nextRandom() * cities.length)];
      const address = `${Math.floor(nextRandom() * 9000) + 100} Financial Way, Apt ${Math.floor(nextRandom() * 40) + 1}`;

      const score = Math.floor(nextRandom() * 320) + 530;
      let riskBand: Applicant['risk_band'] = 'MEDIUM';
      if (score >= 750) riskBand = 'LOW';
      else if (score >= 650) riskBand = 'MEDIUM';
      else if (score >= 580) riskBand = 'HIGH';
      else riskBand = 'VERY_HIGH';

      const applicant: Applicant = {
        id: appId,
        first_name: fn,
        last_name: ln,
        national_id: natId,
        email,
        phone,
        date_of_birth: dob,
        address,
        city,
        credit_score: score,
        risk_band: riskBand,
        created_at: new Date(Date.now() - Math.floor(nextRandom() * 180) * 86400000).toISOString()
      };
      this.applicants.set(appId, applicant);

      // Employment
      const isUnemployed = i % 25 === 0;
      const isUnstable = i % 8 === 0;
      const empTenure = isUnemployed ? 0 : isUnstable ? Math.floor(nextRandom() * 4) + 1 : Math.floor(nextRandom() * 60) + 8;
      const empType = isUnemployed ? 'UNEMPLOYED' : (i % 6 === 0 ? 'SELF_EMPLOYED' : (i % 8 === 0 ? 'CONTRACT' : 'PERMANENT'));

      const emp: Employment = {
        id: `emp-${String(i).padStart(6, '0')}`,
        applicant_id: appId,
        employer_name: isUnemployed ? 'N/A' : employers[Math.floor(nextRandom() * employers.length)],
        job_title: isUnemployed ? 'Unemployed' : jobTitles[Math.floor(nextRandom() * jobTitles.length)],
        employment_type: empType as any,
        tenure_months: empTenure,
        is_current: true,
        verified: i % 7 !== 0,
        created_at: applicant.created_at
      };
      this.employments.set(emp.id, emp);

      // Income
      const baseIncome = isUnemployed ? 0 : Number((Math.floor(nextRandom() * 8500) + 3200).toFixed(2));
      const hasIncomeConflict = i % 15 === 0;
      const inc: IncomeRecord = {
        id: `inc-${String(i).padStart(6, '0')}`,
        applicant_id: appId,
        income_source: empType === 'SELF_EMPLOYED' ? 'BUSINESS' : 'PRIMARY_SALARY',
        monthly_amount: baseIncome,
        frequency: 'MONTHLY',
        verification_status: hasIncomeConflict ? 'CONFLICT' : (i % 5 === 0 ? 'PENDING' : 'VERIFIED'),
        created_at: applicant.created_at
      };
      this.incomes.set(inc.id, inc);

      // Credit Facilities
      const isHighDebt = i % 10 === 0;
      const numFac = Math.floor(nextRandom() * 3) + 1;
      for (let f = 1; f <= numFac; f++) {
        const facType = f === 1 ? 'CREDIT_CARD' : (f === 2 ? 'AUTO_LOAN' : 'PERSONAL_LOAN');
        const installment = isHighDebt ? Number((baseIncome * 0.42).toFixed(2)) : Number((Math.floor(nextRandom() * 450) + 120).toFixed(2));
        const balance = Number((installment * (Math.floor(nextRandom() * 24) + 6)).toFixed(2));
        const fac: CreditFacility = {
          id: `fac-${String(i).padStart(6, '0')}-${f}`,
          applicant_id: appId,
          lender_name: ['Chase', 'Bank of America', 'Wells Fargo', 'Citibank', 'Capital One'][Math.floor(nextRandom() * 5)],
          facility_type: facType as any,
          credit_limit: Number((balance * 1.5).toFixed(2)),
          outstanding_balance: balance,
          monthly_installment: installment,
          status: 'ACTIVE',
          created_at: applicant.created_at
        };
        this.creditFacilities.set(fac.id, fac);
      }
    }

    // 2. Seed Applications
    const prodArray = Array.from(this.products.values());

    for (let j = 1; j <= applicationCount; j++) {
      const appUuid = `loan-${String(j).padStart(6, '0')}`;
      const appNum = `LN-2026-${String(j).padStart(6, '0')}`;
      const isDuplicate = j % 30 === 0;
      const applicantId = isDuplicate ? `app-${String(Math.max(1, j - 1)).padStart(6, '0')}` : `app-${String(j).padStart(6, '0')}`;
      const applicant = this.applicants.get(applicantId) || Array.from(this.applicants.values())[0];
      const product = prodArray[j % prodArray.length];

      const isOutOfRangeTerm = j % 22 === 0;
      const requestedTenure = isOutOfRangeTerm ? product.max_tenure_months + 24 : Math.round((product.min_tenure_months + product.max_tenure_months) / 2);

      let requestedPrincipal = 25000;
      if (product.code === 'MORT_LOAN_01') requestedPrincipal = Math.floor(nextRandom() * 300000) + 280000;
      else if (product.code === 'AUTO_LOAN_01') requestedPrincipal = Math.floor(nextRandom() * 35000) + 20000;
      else if (product.code === 'SME_MICRO_01') requestedPrincipal = Math.floor(nextRandom() * 80000) + 30000;
      else requestedPrincipal = Math.floor(nextRandom() * 22000) + 8000;

      // Deliberate scenarios
      const isMissingIncomeProof = j % 18 === 0;
      const isDecisionBeforeVerification = j % 25 === 0;

      // Gather financials
      const incList = Array.from(this.incomes.values()).filter(i => i.applicant_id === applicantId);
      const mIncome = incList.reduce((sum, i) => sum + i.monthly_amount, 0);
      const facList = Array.from(this.creditFacilities.values()).filter(f => f.applicant_id === applicantId && f.status === 'ACTIVE');
      const mDebt = facList.reduce((sum, f) => sum + f.monthly_installment, 0);

      const afford = calculateAffordability(
        mIncome,
        mDebt,
        requestedPrincipal,
        product.annual_interest_rate,
        requestedTenure,
        product.max_dti_ratio
      );

      const affordRecord: AffordabilityCheck = {
        id: `aff-${String(j).padStart(6, '0')}`,
        application_id: appUuid,
        monthly_income: afford.monthly_income,
        existing_monthly_debt: afford.existing_monthly_debt,
        proposed_emi: afford.proposed_emi,
        dti_ratio: afford.dti_ratio,
        disposable_income: afford.disposable_income,
        interest_rate_used: product.annual_interest_rate,
        tenure_months_used: requestedTenure,
        principal_used: requestedPrincipal,
        is_affordable: afford.is_affordable,
        notes: afford.formula_explanation,
        created_at: new Date(Date.now() - (90 - j) * 86400000).toISOString()
      };
      this.affordabilityChecks.set(affordRecord.id, affordRecord);

      // Documents
      const docTypes: DocumentRecord['document_type'][] = ['IDENTITY_PROOF', 'INCOME_PROOF', 'BANK_STATEMENTS', 'EMPLOYMENT_PROOF'];
      const currentDocs: DocumentRecord[] = [];
      docTypes.forEach((dt, dtIdx) => {
        let docStatus: DocumentRecord['status'] = 'VERIFIED';
        if (isMissingIncomeProof && dt === 'INCOME_PROOF') docStatus = 'MISSING';
        else if (isDecisionBeforeVerification) docStatus = 'PENDING';

        const doc: DocumentRecord = {
          id: `doc-${appUuid}-${dtIdx + 1}`,
          application_id: appUuid,
          document_type: dt,
          document_name: `${dt.replace('_', ' ')} - ${applicant.last_name}`,
          status: docStatus,
          verified_by: docStatus === 'VERIFIED' ? 'Underwriter Agent' : undefined,
          verified_at: docStatus === 'VERIFIED' ? new Date().toISOString() : undefined,
          created_at: affordRecord.created_at
        };
        this.documents.set(doc.id, doc);
        currentDocs.push(doc);
      });

      // Issues
      const currentIssues: IssueRecord[] = [];
      if (isMissingIncomeProof) {
        const iss: IssueRecord = {
          id: `iss-${appUuid}-1`,
          applicant_id: applicantId,
          application_id: appUuid,
          issue_type: 'MISSING_INCOME_PROOF',
          severity: 'HIGH',
          description: 'Mandatory income proof missing before underwriter sign-off.',
          ground_truth_label: 'MISSING_DOC',
          resolution_status: 'OPEN',
          created_at: affordRecord.created_at
        };
        this.issues.set(iss.id, iss);
        currentIssues.push(iss);
      }

      if (isDuplicate) {
        const iss: IssueRecord = {
          id: `iss-${appUuid}-2`,
          applicant_id: applicantId,
          application_id: appUuid,
          issue_type: 'DUPLICATE_APPLICATION',
          severity: 'MEDIUM',
          description: 'Concurrent application submitted within 30 days for same applicant.',
          ground_truth_label: 'DUPLICATE_SUBMISSION',
          resolution_status: 'OPEN',
          created_at: affordRecord.created_at
        };
        this.issues.set(iss.id, iss);
        currentIssues.push(iss);
      }

      const empList = Array.from(this.employments.values()).filter(e => e.applicant_id === applicantId);
      const decRes = evaluateLoanDecision(
        applicant,
        product,
        { requested_principal: requestedPrincipal, requested_tenure_months: requestedTenure },
        afford,
        currentDocs,
        currentIssues,
        empList
      );

      let appStatus: ApplicationStatus = 'APPROVED';
      if (decRes.outcome === 'APPROVED') {
        appStatus = j % 3 === 0 ? 'DISBURSED' : 'APPROVED';
      } else if (decRes.outcome === 'REJECTED') {
        appStatus = 'REJECTED';
      } else {
        appStatus = 'MANUAL_REVIEW';
      }

      const application: LoanApplication = {
        id: appUuid,
        application_number: appNum,
        applicant_id: applicantId,
        product_id: product.id,
        requested_principal: requestedPrincipal,
        requested_tenure_months: requestedTenure,
        purpose: j % 2 === 0 ? 'Debt Consolidation' : 'Asset Purchase',
        status: appStatus,
        submitted_at: new Date(Date.now() - (95 - j) * 86400000).toISOString(),
        decided_at: new Date(Date.now() - (93 - j) * 86400000).toISOString(),
        disbursed_at: appStatus === 'DISBURSED' ? new Date(Date.now() - (90 - j) * 86400000).toISOString() : undefined,
        created_at: affordRecord.created_at
      };
      this.applications.set(appUuid, application);

      const decision: Decision = {
        id: `dec-${String(j).padStart(6, '0')}`,
        application_id: appUuid,
        outcome: decRes.outcome,
        rule_version: decRes.rule_version,
        reason_codes: decRes.reason_codes,
        explanation: decRes.explanation,
        input_snapshot: decRes.input_snapshot,
        underwriter_override: false,
        decided_by: 'AUTOMATED_RULE_ENGINE',
        created_at: application.decided_at || application.created_at
      };
      this.decisions.set(decision.id, decision);

      // Repayment schedule for approved/disbursed
      if (appStatus === 'APPROVED' || appStatus === 'DISBURSED') {
        const sched = generateRepaymentSchedule(appUuid, requestedPrincipal, product.annual_interest_rate, requestedTenure);
        this.repaymentSchedules.set(appUuid, sched.installments);
      }

      // Event Logs
      this.events.push({
        id: `evt-${String(j).padStart(6, '0')}-1`,
        application_id: appUuid,
        entity_type: 'APPLICATION',
        entity_id: appUuid,
        event_type: 'SUBMITTED',
        previous_state: 'DRAFT',
        new_state: 'SUBMITTED',
        actor: 'ONLINE_PORTAL',
        description: `Application ${appNum} submitted for ${product.name}.`,
        created_at: application.submitted_at || application.created_at
      });

      this.events.push({
        id: `evt-${String(j).padStart(6, '0')}-2`,
        application_id: appUuid,
        entity_type: 'DECISION',
        entity_id: decision.id,
        event_type: 'DECIDED',
        previous_state: 'SUBMITTED',
        new_state: decRes.outcome,
        actor: 'DECISION_ENGINE',
        description: `Automated rule evaluation produced outcome ${decRes.outcome}.`,
        created_at: decision.created_at
      });
    }

    // Sort events
    this.events.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  saveToStorage() {
    try {
      localStorage.setItem(STORAGE_KEY_PREFIX + 'initialized', 'true');
      localStorage.setItem(STORAGE_KEY_PREFIX + 'products', JSON.stringify(Array.from(this.products.values())));
      localStorage.setItem(STORAGE_KEY_PREFIX + 'applicants', JSON.stringify(Array.from(this.applicants.values())));
      localStorage.setItem(STORAGE_KEY_PREFIX + 'employments', JSON.stringify(Array.from(this.employments.values())));
      localStorage.setItem(STORAGE_KEY_PREFIX + 'incomes', JSON.stringify(Array.from(this.incomes.values())));
      localStorage.setItem(STORAGE_KEY_PREFIX + 'creditFacilities', JSON.stringify(Array.from(this.creditFacilities.values())));
      localStorage.setItem(STORAGE_KEY_PREFIX + 'applications', JSON.stringify(Array.from(this.applications.values())));
      localStorage.setItem(STORAGE_KEY_PREFIX + 'documents', JSON.stringify(Array.from(this.documents.values())));
      localStorage.setItem(STORAGE_KEY_PREFIX + 'affordability', JSON.stringify(Array.from(this.affordabilityChecks.values())));
      localStorage.setItem(STORAGE_KEY_PREFIX + 'decisions', JSON.stringify(Array.from(this.decisions.values())));
      localStorage.setItem(STORAGE_KEY_PREFIX + 'issues', JSON.stringify(Array.from(this.issues.values())));
      localStorage.setItem(STORAGE_KEY_PREFIX + 'events', JSON.stringify(this.events.slice(0, 300)));
    } catch (e) {
      console.warn('LocalStorage save error (likely quota):', e);
    }
  }

  loadFromStorage() {
    const rawProds = localStorage.getItem(STORAGE_KEY_PREFIX + 'products');
    if (rawProds) JSON.parse(rawProds).forEach((p: LoanProduct) => this.products.set(p.id, p));

    const rawApps = localStorage.getItem(STORAGE_KEY_PREFIX + 'applicants');
    if (rawApps) JSON.parse(rawApps).forEach((a: Applicant) => this.applicants.set(a.id, a));

    const rawEmp = localStorage.getItem(STORAGE_KEY_PREFIX + 'employments');
    if (rawEmp) JSON.parse(rawEmp).forEach((e: Employment) => this.employments.set(e.id, e));

    const rawInc = localStorage.getItem(STORAGE_KEY_PREFIX + 'incomes');
    if (rawInc) JSON.parse(rawInc).forEach((i: IncomeRecord) => this.incomes.set(i.id, i));

    const rawFac = localStorage.getItem(STORAGE_KEY_PREFIX + 'creditFacilities');
    if (rawFac) JSON.parse(rawFac).forEach((f: CreditFacility) => this.creditFacilities.set(f.id, f));

    const rawLoans = localStorage.getItem(STORAGE_KEY_PREFIX + 'applications');
    if (rawLoans) JSON.parse(rawLoans).forEach((l: LoanApplication) => this.applications.set(l.id, l));

    const rawDocs = localStorage.getItem(STORAGE_KEY_PREFIX + 'documents');
    if (rawDocs) JSON.parse(rawDocs).forEach((d: DocumentRecord) => this.documents.set(d.id, d));

    const rawAff = localStorage.getItem(STORAGE_KEY_PREFIX + 'affordability');
    if (rawAff) JSON.parse(rawAff).forEach((af: AffordabilityCheck) => this.affordabilityChecks.set(af.id, af));

    const rawDec = localStorage.getItem(STORAGE_KEY_PREFIX + 'decisions');
    if (rawDec) JSON.parse(rawDec).forEach((dc: Decision) => this.decisions.set(dc.id, dc));

    const rawIss = localStorage.getItem(STORAGE_KEY_PREFIX + 'issues');
    if (rawIss) JSON.parse(rawIss).forEach((is: IssueRecord) => this.issues.set(is.id, is));

    const rawEvt = localStorage.getItem(STORAGE_KEY_PREFIX + 'events');
    if (rawEvt) this.events = JSON.parse(rawEvt);
  }

  // Dashboard Aggregates
  getDashboardSummary(): DashboardSummary {
    const apps = Array.from(this.applications.values());
    const applicants = Array.from(this.applicants.values());

    const approvedApps = apps.filter(a => a.status === 'APPROVED' || a.status === 'DISBURSED');
    const rejectedApps = apps.filter(a => a.status === 'REJECTED');
    const manualReviewApps = apps.filter(a => a.status === 'MANUAL_REVIEW');

    const totalRequested = apps.reduce((s, a) => s + a.requested_principal, 0);
    const totalApproved = approvedApps.reduce((s, a) => s + a.requested_principal, 0);

    const affList = Array.from(this.affordabilityChecks.values());
    const avgDti = affList.length > 0 ? affList.reduce((s, a) => s + a.dti_ratio, 0) / affList.length : 32.4;

    const pendingDocs = Array.from(this.documents.values()).filter(d => d.status === 'PENDING').length;
    const openExceptions = Array.from(this.issues.values()).filter(i => i.resolution_status === 'OPEN').length;

    const statusDist: Record<string, number> = {};
    apps.forEach(a => {
      statusDist[a.status] = (statusDist[a.status] || 0) + 1;
    });

    const prodDist: Record<string, number> = {};
    apps.forEach(a => {
      const prod = this.products.get(a.product_id);
      const name = prod ? prod.name : 'Other';
      prodDist[name] = (prodDist[name] || 0) + 1;
    });

    const riskDist: Record<string, number> = {};
    applicants.forEach(a => {
      riskDist[a.risk_band] = (riskDist[a.risk_band] || 0) + 1;
    });

    return {
      total_applicants: applicants.length,
      total_loan_applications: apps.length,
      approved_applications: approvedApps.length,
      rejected_applications: rejectedApps.length,
      manual_review_applications: manualReviewApps.length,
      total_loan_amount_requested: totalRequested,
      total_approved_loan_amount: totalApproved,
      average_dti_ratio: Number(avgDti.toFixed(2)),
      pending_document_verifications: pendingDocs,
      open_exceptions_count: openExceptions,
      status_distribution: statusDist,
      product_distribution: prodDist,
      risk_distribution: riskDist
    };
  }

  // Create Applicant
  createApplicant(data: Omit<Applicant, 'id' | 'created_at'>): Applicant {
    const newId = `app-${String(this.applicants.size + 1).padStart(6, '0')}`;
    const newApplicant: Applicant = {
      ...data,
      id: newId,
      created_at: new Date().toISOString()
    };
    this.applicants.set(newId, newApplicant);

    this.logEvent({
      entity_type: 'APPLICANT',
      entity_id: newId,
      event_type: 'CREATED',
      new_state: 'ACTIVE',
      actor: 'UNDERWRITER',
      description: `Applicant ${data.first_name} ${data.last_name} created.`
    });

    this.saveToStorage();
    return newApplicant;
  }

  // Create Application
  createApplication(applicantId: string, productId: string, principal: number, tenure: number, purpose: string): LoanApplication {
    const applicant = this.applicants.get(applicantId);
    if (!applicant) throw new Error('Applicant not found');
    const product = this.products.get(productId);
    if (!product) throw new Error('Product not found');

    const count = this.applications.size + 1;
    const appId = `loan-${String(count).padStart(6, '0')}`;
    const appNum = `LN-2026-${String(count).padStart(6, '0')}`;

    const newApp: LoanApplication = {
      id: appId,
      application_number: appNum,
      applicant_id: applicantId,
      product_id: productId,
      requested_principal: principal,
      requested_tenure_months: tenure,
      purpose,
      status: 'DRAFT',
      created_at: new Date().toISOString()
    };
    this.applications.set(appId, newApp);

    // Attach required documents
    const docTypes: DocumentRecord['document_type'][] = ['IDENTITY_PROOF', 'INCOME_PROOF', 'BANK_STATEMENTS', 'EMPLOYMENT_PROOF'];
    docTypes.forEach((dt, idx) => {
      const doc: DocumentRecord = {
        id: `doc-${appId}-${idx + 1}`,
        application_id: appId,
        document_type: dt,
        document_name: `${dt.replace('_', ' ')} - ${applicant.last_name}`,
        status: 'PENDING',
        created_at: newApp.created_at
      };
      this.documents.set(doc.id, doc);
    });

    this.logEvent({
      application_id: appId,
      entity_type: 'APPLICATION',
      entity_id: appId,
      event_type: 'CREATED',
      new_state: 'DRAFT',
      actor: 'ORIGINATION_OFFICER',
      description: `Loan application ${appNum} drafted for ${product.name}.`
    });

    this.saveToStorage();
    return newApp;
  }

  // Submit Application
  submitApplication(appId: string): LoanApplication {
    const app = this.applications.get(appId);
    if (!app) throw new Error('Application not found');
    if (app.status !== 'DRAFT') throw new Error(`Cannot submit application from ${app.status}`);

    app.status = 'SUBMITTED';
    app.submitted_at = new Date().toISOString();

    this.logEvent({
      application_id: appId,
      entity_type: 'APPLICATION',
      entity_id: appId,
      event_type: 'SUBMITTED',
      previous_state: 'DRAFT',
      new_state: 'SUBMITTED',
      actor: 'ORIGINATION_OFFICER',
      description: `Application ${app.application_number} submitted for underwriting review.`
    });

    this.saveToStorage();
    return app;
  }

  // Run Affordability & Decision
  evaluateApplication(appId: string): { affordability: AffordabilityCheck; decision: Decision } {
    const app = this.applications.get(appId);
    if (!app) throw new Error('Application not found');
    const applicant = this.applicants.get(app.applicant_id);
    if (!applicant) throw new Error('Applicant not found');
    const product = this.products.get(app.product_id);
    if (!product) throw new Error('Product not found');

    const incList = Array.from(this.incomes.values()).filter(i => i.applicant_id === applicant.id);
    const mIncome = incList.reduce((sum, i) => sum + i.monthly_amount, 0);
    const facList = Array.from(this.creditFacilities.values()).filter(f => f.applicant_id === applicant.id && f.status === 'ACTIVE');
    const mDebt = facList.reduce((sum, f) => sum + f.monthly_installment, 0);

    const afford = calculateAffordability(
      mIncome,
      mDebt,
      app.requested_principal,
      product.annual_interest_rate,
      app.requested_tenure_months,
      product.max_dti_ratio
    );

    const affRecord: AffordabilityCheck = {
      id: `aff-${appId}`,
      application_id: appId,
      monthly_income: afford.monthly_income,
      existing_monthly_debt: afford.existing_monthly_debt,
      proposed_emi: afford.proposed_emi,
      dti_ratio: afford.dti_ratio,
      disposable_income: afford.disposable_income,
      interest_rate_used: product.annual_interest_rate,
      tenure_months_used: app.requested_tenure_months,
      principal_used: app.requested_principal,
      is_affordable: afford.is_affordable,
      notes: afford.formula_explanation,
      created_at: new Date().toISOString()
    };
    this.affordabilityChecks.set(affRecord.id, affRecord);

    const docs = Array.from(this.documents.values()).filter(d => d.application_id === appId);
    const issues = Array.from(this.issues.values()).filter(i => i.application_id === appId);
    const employments = Array.from(this.employments.values()).filter(e => e.applicant_id === applicant.id);

    const decRes = evaluateLoanDecision(
      applicant,
      product,
      { requested_principal: app.requested_principal, requested_tenure_months: app.requested_tenure_months },
      afford,
      docs,
      issues,
      employments
    );

    const decRecord: Decision = {
      id: `dec-${appId}`,
      application_id: appId,
      outcome: decRes.outcome,
      rule_version: decRes.rule_version,
      reason_codes: decRes.reason_codes,
      explanation: decRes.explanation,
      input_snapshot: decRes.input_snapshot,
      underwriter_override: false,
      decided_by: 'AUTOMATED_RULE_ENGINE',
      created_at: new Date().toISOString()
    };
    this.decisions.set(decRecord.id, decRecord);

    const oldStatus = app.status;
    app.status = decRes.outcome;
    app.decided_at = decRecord.created_at;

    // Generate schedule if approved
    if (app.status === 'APPROVED') {
      const sched = generateRepaymentSchedule(app.id, app.requested_principal, product.annual_interest_rate, app.requested_tenure_months);
      this.repaymentSchedules.set(app.id, sched.installments);
    }

    this.logEvent({
      application_id: appId,
      entity_type: 'DECISION',
      entity_id: decRecord.id,
      event_type: 'DECIDED',
      previous_state: oldStatus,
      new_state: decRes.outcome,
      actor: 'DECISION_ENGINE',
      description: `Evaluation finished with ${decRes.outcome}. ${decRes.explanation}`
    });

    this.saveToStorage();
    return { affordability: affRecord, decision: decRecord };
  }

  // Underwriter Override
  overrideDecision(appId: string, outcome: DecisionOutcome, reason: string): Decision {
    const app = this.applications.get(appId);
    if (!app) throw new Error('Application not found');
    const dec = Array.from(this.decisions.values()).find(d => d.application_id === appId);
    if (!dec) throw new Error('No prior decision exists to override');

    const oldOutcome = dec.outcome;
    dec.outcome = outcome;
    dec.underwriter_override = true;
    dec.override_reason = reason;
    dec.decided_by = 'UNDERWRITER_OVERRIDE';

    app.status = outcome;

    if (outcome === 'APPROVED' && !this.repaymentSchedules.has(appId)) {
      const prod = this.products.get(app.product_id);
      if (prod) {
        const sched = generateRepaymentSchedule(app.id, app.requested_principal, prod.annual_interest_rate, app.requested_tenure_months);
        this.repaymentSchedules.set(app.id, sched.installments);
      }
    }

    this.logEvent({
      application_id: appId,
      entity_type: 'DECISION',
      entity_id: dec.id,
      event_type: 'OVERRIDDEN',
      previous_state: oldOutcome,
      new_state: outcome,
      actor: 'SENIOR_UNDERWRITER',
      description: `Manual override to ${outcome}. Reason: ${reason}`
    });

    this.saveToStorage();
    return dec;
  }

  // Update Document Status
  updateDocumentStatus(docId: string, status: DocumentRecord['status'], rejectionReason?: string): DocumentRecord {
    const doc = this.documents.get(docId);
    if (!doc) throw new Error('Document not found');

    const oldStatus = doc.status;
    doc.status = status;
    doc.rejection_reason = rejectionReason;
    doc.verified_by = 'Underwriter';
    if (status === 'VERIFIED') doc.verified_at = new Date().toISOString();

    this.logEvent({
      application_id: doc.application_id,
      entity_type: 'DOCUMENT',
      entity_id: doc.id,
      event_type: status === 'VERIFIED' ? 'VERIFIED' : 'STATUS_CHANGED',
      previous_state: oldStatus,
      new_state: status,
      actor: 'UNDERWRITER',
      description: `Document ${doc.document_name} updated to ${status}.`
    });

    this.saveToStorage();
    return doc;
  }

  // Resolve Exception
  resolveIssue(issueId: string, resolutionStatus: IssueRecord['resolution_status'], notes: string): IssueRecord {
    const issue = this.issues.get(issueId);
    if (!issue) throw new Error('Issue not found');

    const oldStatus = issue.resolution_status;
    issue.resolution_status = resolutionStatus;
    issue.resolution_notes = notes;
    issue.resolved_by = 'Compliance Manager';
    issue.resolved_at = new Date().toISOString();

    this.logEvent({
      application_id: issue.application_id,
      entity_type: 'EXCEPTION',
      entity_id: issue.id,
      event_type: 'RESOLVED',
      previous_state: oldStatus,
      new_state: resolutionStatus,
      actor: 'COMPLIANCE_OFFICER',
      description: `Issue ${issue.issue_type} resolved as ${resolutionStatus}. Notes: ${notes}`
    });

    this.saveToStorage();
    return issue;
  }

  // Save / Update Product
  saveProduct(prod: LoanProduct): LoanProduct {
    this.products.set(prod.id, prod);
    this.saveToStorage();
    return prod;
  }

  private logEvent(event: Omit<LoanEvent, 'id' | 'created_at'>) {
    const newEvent: LoanEvent = {
      ...event,
      id: `evt-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      created_at: new Date().toISOString()
    };
    this.events.unshift(newEvent);
  }
}

export const dbStore = new LoanFlowDatabase();
