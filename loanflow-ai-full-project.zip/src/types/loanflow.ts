export type RiskBand = 'LOW' | 'MEDIUM' | 'HIGH' | 'VERY_HIGH';

export type EmploymentType = 'PERMANENT' | 'CONTRACT' | 'SELF_EMPLOYED' | 'UNEMPLOYED';

export type IncomeSource = 'PRIMARY_SALARY' | 'SECONDARY_JOB' | 'INVESTMENT' | 'BUSINESS' | 'RENTAL';

export type VerificationStatus = 'PENDING' | 'VERIFIED' | 'REJECTED' | 'CONFLICT';

export type FacilityType = 'CREDIT_CARD' | 'MORTGAGE' | 'AUTO_LOAN' | 'PERSONAL_LOAN';

export type ApplicationStatus =
  | 'DRAFT'
  | 'SUBMITTED'
  | 'UNDER_REVIEW'
  | 'APPROVED'
  | 'REJECTED'
  | 'MANUAL_REVIEW'
  | 'DISBURSED'
  | 'CLOSED';

export type DecisionOutcome = 'APPROVED' | 'REJECTED' | 'MANUAL_REVIEW';

export type DocumentType =
  | 'IDENTITY_PROOF'
  | 'ADDRESS_PROOF'
  | 'INCOME_PROOF'
  | 'EMPLOYMENT_PROOF'
  | 'BANK_STATEMENTS';

export type DocumentStatus = 'PENDING' | 'VERIFIED' | 'REJECTED' | 'MISSING';

export type IssueType =
  | 'MISSING_INCOME_PROOF'
  | 'DUPLICATE_APPLICATION'
  | 'HIGH_DEBT_BURDEN'
  | 'UNSTABLE_EMPLOYMENT'
  | 'INCOME_CONFLICT'
  | 'INVALID_LOAN_TERM'
  | 'RECONCILIATION_FAILURE'
  | 'RULE_VIOLATION';

export type IssueSeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type ResolutionStatus = 'OPEN' | 'IN_PROGRESS' | 'RESOLVED' | 'WAIVED';
export type IssueStatus = ResolutionStatus;

export interface Applicant {
  id: string;
  first_name: string;
  last_name: string;
  national_id: string;
  email: string;
  phone: string;
  date_of_birth: string;
  address: string;
  city: string;
  credit_score: number;
  risk_band: RiskBand;
  created_at: string;
  updated_at?: string;
}

export interface Employment {
  id: string;
  applicant_id: string;
  employer_name: string;
  job_title: string;
  employment_type: EmploymentType;
  tenure_months: number;
  is_current: boolean;
  verified: boolean;
  created_at: string;
}

export interface IncomeRecord {
  id: string;
  applicant_id: string;
  income_source: IncomeSource;
  monthly_amount: number;
  frequency: string;
  verification_status: VerificationStatus;
  created_at: string;
}

export interface CreditFacility {
  id: string;
  applicant_id: string;
  lender_name: string;
  facility_type: FacilityType;
  credit_limit: number;
  outstanding_balance: number;
  monthly_installment: number;
  status: 'ACTIVE' | 'CLOSED' | 'DEFAULTED';
  created_at: string;
}

export interface LoanProduct {
  id: string;
  code: string;
  name: string;
  description: string;
  min_principal: number;
  max_principal: number;
  min_tenure_months: number;
  max_tenure_months: number;
  annual_interest_rate: number; // e.g. 8.75%
  min_income_requirement: number;
  min_income?: number;
  max_dti_ratio: number;
  required_employment_status: string;
  required_employment?: string;
  required_documents?: string[];
  status: 'ACTIVE' | 'INACTIVE';
  created_at: string;
}

export interface LoanApplication {
  id: string;
  application_number: string;
  applicant_id: string;
  product_id: string;
  requested_principal: number;
  requested_tenure_months: number;
  purpose: string;
  loan_purpose?: string;
  status: ApplicationStatus;
  submitted_at?: string;
  decided_at?: string;
  disbursed_at?: string;
  closed_at?: string;
  created_at: string;
  updated_at?: string;
}

export interface DocumentRecord {
  id: string;
  application_id: string;
  document_type: DocumentType;
  document_name: string;
  file_path?: string;
  status: DocumentStatus;
  rejection_reason?: string;
  verification_notes?: string;
  verified_by?: string;
  verified_at?: string;
  created_at: string;
}

export interface AffordabilityCheck {
  id: string;
  application_id: string;
  monthly_income: number;
  existing_monthly_debt: number;
  proposed_emi: number;
  dti_ratio: number;
  disposable_income: number;
  interest_rate_used: number;
  tenure_months_used: number;
  principal_used: number;
  is_affordable: boolean;
  notes?: string;
  created_at: string;
}

export interface Decision {
  id: string;
  application_id: string;
  outcome: DecisionOutcome;
  rule_version: string;
  reason_codes: string[];
  explanation: string;
  input_snapshot: Record<string, any>;
  underwriter_override: boolean;
  override_reason?: string;
  decided_by: string;
  created_at: string;
}

export interface RepaymentInstallment {
  id: string;
  application_id: string;
  installment_number: number;
  due_date: string;
  principal_component: number;
  interest_component: number;
  total_installment: number;
  outstanding_principal: number;
  payment_status: 'PENDING' | 'PAID' | 'OVERDUE';
}

export interface LoanEvent {
  id: string;
  application_id?: string;
  entity_type: string;
  entity_id: string;
  event_type: string;
  previous_state?: string;
  new_state?: string;
  actor: string;
  description: string;
  created_at: string;
}

export interface IssueRecord {
  id: string;
  applicant_id?: string;
  application_id?: string;
  issue_type: IssueType;
  severity: IssueSeverity;
  description: string;
  ground_truth_label?: string;
  resolution_status: ResolutionStatus;
  resolution_notes?: string;
  resolution_remarks?: string;
  resolved_by?: string;
  resolved_at?: string;
  created_at: string;
}

export interface DashboardSummary {
  total_applicants: number;
  total_loan_applications: number;
  approved_applications: number;
  rejected_applications: number;
  manual_review_applications: number;
  total_loan_amount_requested: number;
  total_approved_loan_amount: number;
  average_dti_ratio: number;
  pending_document_verifications: number;
  open_exceptions_count: number;
  status_distribution: Record<string, number>;
  product_distribution: Record<string, number>;
  risk_distribution: Record<string, number>;
}
